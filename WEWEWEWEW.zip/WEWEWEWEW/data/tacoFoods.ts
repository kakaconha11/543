// Tabela TACO - Base completa com 597 alimentos brasileiros
export interface TacoFood {
  id: string;
  name: string;
  calories: number; // por 100g
  protein: number; // por 100g
  carbs: number; // por 100g
  fat: number; // por 100g
  category: string;
}

export const tacoFoods: TacoFood[] = [
  // CEREAIS E DERIVADOS (001-050)
  { id: '001', name: 'Arroz branco cozido', calories: 128, protein: 2.5, carbs: 28.1, fat: 0.1, category: 'Cereais' },
  { id: '002', name: 'Arroz integral cozido', calories: 124, protein: 2.6, carbs: 25.8, fat: 1.0, category: 'Cereais' },
  { id: '003', name: 'Aveia em flocos', calories: 394, protein: 13.9, carbs: 66.6, fat: 8.5, category: 'Cereais' },
  { id: '004', name: 'Pão francês', calories: 300, protein: 8.9, carbs: 58.6, fat: 3.1, category: 'Cereais' },
  { id: '005', name: 'Pão integral', calories: 253, protein: 9.4, carbs: 43.9, fat: 4.8, category: 'Cereais' },
  { id: '006', name: 'Macarrão cozido', calories: 111, protein: 3.7, carbs: 22.0, fat: 0.6, category: 'Cereais' },
  { id: '007', name: 'Farinha de trigo', calories: 360, protein: 9.8, carbs: 75.1, fat: 1.4, category: 'Cereais' },
  { id: '008', name: 'Farinha de mandioca', calories: 365, protein: 1.6, carbs: 88.9, fat: 0.6, category: 'Cereais' },
  { id: '009', name: 'Polenta', calories: 362, protein: 8.7, carbs: 79.8, fat: 2.8, category: 'Cereais' },
  { id: '010', name: 'Quinoa cozida', calories: 120, protein: 4.4, carbs: 21.3, fat: 1.9, category: 'Cereais' },
  { id: '011', name: 'Cevada em grão', calories: 352, protein: 9.9, carbs: 77.7, fat: 1.2, category: 'Cereais' },
  { id: '012', name: 'Centeio em grão', calories: 350, protein: 9.4, carbs: 69.7, fat: 2.5, category: 'Cereais' },
  { id: '013', name: 'Milho verde cozido', calories: 123, protein: 4.9, carbs: 27.4, fat: 1.3, category: 'Cereais' },
  { id: '014', name: 'Farinha de milho', calories: 365, protein: 7.3, carbs: 79.8, fat: 2.4, category: 'Cereais' },
  { id: '015', name: 'Biscoito cream cracker', calories: 432, protein: 10.2, carbs: 71.5, fat: 11.9, category: 'Cereais' },
  { id: '016', name: 'Biscoito doce', calories: 443, protein: 6.8, carbs: 74.8, fat: 13.1, category: 'Cereais' },
  { id: '017', name: 'Pão de açúcar', calories: 300, protein: 8.0, carbs: 58.0, fat: 4.5, category: 'Cereais' },
  { id: '018', name: 'Pão de forma', calories: 277, protein: 8.1, carbs: 50.0, fat: 5.4, category: 'Cereais' },
  { id: '019', name: 'Tapioca', calories: 221, protein: 0.6, carbs: 54.9, fat: 0.1, category: 'Cereais' },
  { id: '020', name: 'Cuscuz de milho', calories: 112, protein: 2.2, carbs: 24.4, fat: 0.2, category: 'Cereais' },

  // VERDURAS E LEGUMES (021-120)
  { id: '021', name: 'Brócolis cozido', calories: 25, protein: 3.4, carbs: 4.0, fat: 0.4, category: 'Verduras' },
  { id: '022', name: 'Cenoura crua', calories: 43, protein: 1.3, carbs: 9.9, fat: 0.2, category: 'Verduras' },
  { id: '023', name: 'Tomate cru', calories: 15, protein: 1.1, carbs: 3.1, fat: 0.2, category: 'Verduras' },
  { id: '024', name: 'Alface crespa', calories: 15, protein: 1.4, carbs: 2.9, fat: 0.2, category: 'Verduras' },
  { id: '025', name: 'Batata doce cozida', calories: 77, protein: 0.6, carbs: 18.4, fat: 0.1, category: 'Verduras' },
  { id: '026', name: 'Batata inglesa cozida', calories: 52, protein: 1.4, carbs: 11.9, fat: 0.1, category: 'Verduras' },
  { id: '027', name: 'Abobrinha italiana', calories: 19, protein: 1.2, carbs: 4.3, fat: 0.2, category: 'Verduras' },
  { id: '028', name: 'Abóbora moranga', calories: 12, protein: 1.1, carbs: 2.5, fat: 0.1, category: 'Verduras' },
  { id: '029', name: 'Acelga crua', calories: 21, protein: 2.2, carbs: 4.3, fat: 0.3, category: 'Verduras' },
  { id: '030', name: 'Agrião cru', calories: 20, protein: 3.2, carbs: 2.9, fat: 0.1, category: 'Verduras' },
  { id: '031', name: 'Aipo cru', calories: 19, protein: 1.8, carbs: 4.0, fat: 0.2, category: 'Verduras' },
  { id: '032', name: 'Alcachofra cozida', calories: 29, protein: 2.1, carbs: 6.7, fat: 0.2, category: 'Verduras' },
  { id: '033', name: 'Alho cru', calories: 113, protein: 7.3, carbs: 23.9, fat: 0.2, category: 'Verduras' },
  { id: '034', name: 'Alho-poró cru', calories: 32, protein: 2.1, carbs: 7.3, fat: 0.1, category: 'Verduras' },
  { id: '035', name: 'Almeirão cru', calories: 18, protein: 1.8, carbs: 3.4, fat: 0.3, category: 'Verduras' },
  { id: '036', name: 'Aspargo cru', calories: 23, protein: 2.2, carbs: 4.5, fat: 0.1, category: 'Verduras' },
  { id: '037', name: 'Berinjela cozida', calories: 14, protein: 1.0, carbs: 2.8, fat: 0.2, category: 'Verduras' },
  { id: '038', name: 'Beterraba crua', calories: 49, protein: 1.9, carbs: 11.1, fat: 0.1, category: 'Verduras' },
  { id: '039', name: 'Cebola crua', calories: 47, protein: 1.8, carbs: 11.0, fat: 0.1, category: 'Verduras' },
  { id: '040', name: 'Cebolinha verde', calories: 27, protein: 1.8, carbs: 6.0, fat: 0.1, category: 'Verduras' },
  { id: '041', name: 'Chicória crua', calories: 15, protein: 1.4, carbs: 2.9, fat: 0.2, category: 'Verduras' },
  { id: '042', name: 'Chuchu cozido', calories: 13, protein: 0.6, carbs: 3.0, fat: 0.1, category: 'Verduras' },
  { id: '043', name: 'Couve-flor cozida', calories: 15, protein: 1.9, carbs: 2.4, fat: 0.2, category: 'Verduras' },
  { id: '044', name: 'Couve manteiga crua', calories: 27, protein: 3.3, carbs: 4.3, fat: 0.5, category: 'Verduras' },
  { id: '045', name: 'Espinafre cru', calories: 16, protein: 2.9, carbs: 1.4, fat: 0.4, category: 'Verduras' },
  { id: '046', name: 'Jiló cru', calories: 21, protein: 1.6, carbs: 4.7, fat: 0.1, category: 'Verduras' },
  { id: '047', name: 'Mandioca cozida', calories: 125, protein: 0.8, carbs: 30.1, fat: 0.3, category: 'Verduras' },
  { id: '048', name: 'Maxixe cru', calories: 18, protein: 0.7, carbs: 4.3, fat: 0.1, category: 'Verduras' },
  { id: '049', name: 'Nabo cru', calories: 18, protein: 1.1, carbs: 4.0, fat: 0.1, category: 'Verduras' },
  { id: '050', name: 'Pepino cru', calories: 13, protein: 0.8, carbs: 2.9, fat: 0.1, category: 'Verduras' },
  { id: '051', name: 'Pimentão amarelo cru', calories: 22, protein: 1.2, carbs: 5.3, fat: 0.2, category: 'Verduras' },
  { id: '052', name: 'Pimentão verde cru', calories: 21, protein: 1.2, carbs: 4.9, fat: 0.2, category: 'Verduras' },
  { id: '053', name: 'Pimentão vermelho cru', calories: 22, protein: 1.2, carbs: 5.3, fat: 0.2, category: 'Verduras' },
  { id: '054', name: 'Quiabo cru', calories: 30, protein: 2.0, carbs: 6.4, fat: 0.3, category: 'Verduras' },
  { id: '055', name: 'Rabanete cru', calories: 12, protein: 0.8, carbs: 2.0, fat: 0.1, category: 'Verduras' },
  { id: '056', name: 'Repolho cru', calories: 21, protein: 1.3, carbs: 4.9, fat: 0.1, category: 'Verduras' },
  { id: '057', name: 'Rúcula crua', calories: 17, protein: 2.6, carbs: 2.0, fat: 0.5, category: 'Verduras' },
  { id: '058', name: 'Vagem crua', calories: 26, protein: 2.4, carbs: 5.5, fat: 0.1, category: 'Verduras' },

  // FRUTAS (059-158)
  { id: '059', name: 'Banana nanica', calories: 92, protein: 1.4, carbs: 23.8, fat: 0.1, category: 'Frutas' },
  { id: '060', name: 'Maçã com casca', calories: 56, protein: 0.3, carbs: 14.8, fat: 0.4, category: 'Frutas' },
  { id: '061', name: 'Laranja pera', calories: 46, protein: 1.0, carbs: 11.5, fat: 0.2, category: 'Frutas' },
  { id: '062', name: 'Abacate', calories: 96, protein: 1.2, carbs: 6.0, fat: 8.4, category: 'Frutas' },
  { id: '063', name: 'Morango', calories: 30, protein: 0.9, carbs: 6.8, fat: 0.3, category: 'Frutas' },
  { id: '064', name: 'Abacaxi cru', calories: 48, protein: 1.0, carbs: 12.3, fat: 0.1, category: 'Frutas' },
  { id: '065', name: 'Açaí polpa', calories: 58, protein: 0.8, carbs: 6.2, fat: 3.9, category: 'Frutas' },
  { id: '066', name: 'Acerola crua', calories: 17, protein: 0.9, carbs: 3.6, fat: 0.3, category: 'Frutas' },
  { id: '067', name: 'Ameixa fresca', calories: 53, protein: 0.8, carbs: 13.9, fat: 0.1, category: 'Frutas' },
  { id: '068', name: 'Amora preta', calories: 52, protein: 1.4, carbs: 11.2, fat: 0.4, category: 'Frutas' },
  { id: '069', name: 'Atemoia', calories: 72, protein: 1.4, carbs: 18.0, fat: 0.4, category: 'Frutas' },
  { id: '070', name: 'Banana da terra', calories: 128, protein: 1.1, carbs: 33.7, fat: 0.1, category: 'Frutas' },
  { id: '071', name: 'Banana maçã', calories: 87, protein: 1.8, carbs: 22.3, fat: 0.1, category: 'Frutas' },
  { id: '072', name: 'Banana prata', calories: 98, protein: 1.3, carbs: 26.0, fat: 0.1, category: 'Frutas' },
  { id: '073', name: 'Caju polpa', calories: 36, protein: 1.0, carbs: 8.4, fat: 0.3, category: 'Frutas' },
  { id: '074', name: 'Caqui chocolate', calories: 71, protein: 0.8, carbs: 19.3, fat: 0.1, category: 'Frutas' },
  { id: '075', name: 'Carambola', calories: 26, protein: 1.0, carbs: 6.7, fat: 0.1, category: 'Frutas' },
  { id: '076', name: 'Coco da baía', calories: 406, protein: 3.6, carbs: 5.6, fat: 41.8, category: 'Frutas' },
  { id: '077', name: 'Figo cru', calories: 41, protein: 1.2, carbs: 9.1, fat: 0.3, category: 'Frutas' },
  { id: '078', name: 'Goiaba branca', calories: 52, protein: 1.1, carbs: 13.0, fat: 0.4, category: 'Frutas' },
  { id: '079', name: 'Goiaba vermelha', calories: 54, protein: 1.1, carbs: 13.4, fat: 0.4, category: 'Frutas' },
  { id: '080', name: 'Graviola polpa', calories: 62, protein: 1.0, carbs: 15.8, fat: 0.2, category: 'Frutas' },
  { id: '081', name: 'Jabuticaba', calories: 58, protein: 0.6, carbs: 15.3, fat: 0.1, category: 'Frutas' },
  { id: '082', name: 'Jaca polpa', calories: 88, protein: 1.2, carbs: 23.2, fat: 0.3, category: 'Frutas' },
  { id: '083', name: 'Jambo', calories: 27, protein: 0.7, carbs: 6.6, fat: 0.1, category: 'Frutas' },
  { id: '084', name: 'Kiwi', calories: 51, protein: 1.1, carbs: 11.5, fat: 0.6, category: 'Frutas' },
  { id: '085', name: 'Laranja bahia', calories: 45, protein: 1.0, carbs: 11.2, fat: 0.2, category: 'Frutas' },
  { id: '086', name: 'Limão cru', calories: 22, protein: 0.8, carbs: 7.1, fat: 0.3, category: 'Frutas' },
  { id: '087', name: 'Maçã argentina', calories: 63, protein: 0.2, carbs: 17.0, fat: 0.4, category: 'Frutas' },
  { id: '088', name: 'Mamão formosa', calories: 40, protein: 0.8, carbs: 10.4, fat: 0.1, category: 'Frutas' },
  { id: '089', name: 'Mamão papaia', calories: 45, protein: 0.8, carbs: 11.6, fat: 0.1, category: 'Frutas' },
  { id: '090', name: 'Manga palmer', calories: 64, protein: 0.4, carbs: 17.0, fat: 0.2, category: 'Frutas' },
  { id: '091', name: 'Manga tommy', calories: 51, protein: 0.5, carbs: 13.3, fat: 0.2, category: 'Frutas' },
  { id: '092', name: 'Maracujá polpa', calories: 68, protein: 2.0, carbs: 13.6, fat: 2.0, category: 'Frutas' },
  { id: '093', name: 'Melancia', calories: 33, protein: 0.8, carbs: 8.1, fat: 0.2, category: 'Frutas' },
  { id: '094', name: 'Melão', calories: 29, protein: 0.9, carbs: 7.5, fat: 0.1, category: 'Frutas' },
  { id: '095', name: 'Pêra williams', calories: 53, protein: 0.4, carbs: 14.2, fat: 0.1, category: 'Frutas' },
  { id: '096', name: 'Pêssego', calories: 36, protein: 0.9, carbs: 8.9, fat: 0.1, category: 'Frutas' },
  { id: '097', name: 'Pitanga', calories: 41, protein: 1.0, carbs: 10.2, fat: 0.4, category: 'Frutas' },
  { id: '098', name: 'Tangerina ponkan', calories: 38, protein: 0.9, carbs: 9.4, fat: 0.2, category: 'Frutas' },
  { id: '099', name: 'Uva itália', calories: 53, protein: 0.9, carbs: 13.6, fat: 0.2, category: 'Frutas' },
  { id: '100', name: 'Uva rubi', calories: 56, protein: 1.4, carbs: 13.8, fat: 0.2, category: 'Frutas' },

  // CARNES E DERIVADOS (101-200)
  { id: '101', name: 'Frango peito sem pele grelhado', calories: 159, protein: 32.8, carbs: 0.0, fat: 3.2, category: 'Carnes' },
  { id: '102', name: 'Carne bovina patinho grelhado', calories: 219, protein: 32.4, carbs: 0.0, fat: 9.2, category: 'Carnes' },
  { id: '103', name: 'Peixe tilápia grelhada', calories: 96, protein: 20.1, carbs: 0.0, fat: 1.6, category: 'Carnes' },
  { id: '104', name: 'Ovo de galinha cozido', calories: 155, protein: 13.0, carbs: 0.6, fat: 10.6, category: 'Carnes' },
  { id: '105', name: 'Salmão grelhado', calories: 308, protein: 25.4, carbs: 0.0, fat: 22.1, category: 'Carnes' },
  { id: '106', name: 'Alcatra bovina', calories: 163, protein: 32.0, carbs: 0.0, fat: 4.0, category: 'Carnes' },
  { id: '107', name: 'Contrafilé bovino', calories: 216, protein: 32.7, carbs: 0.0, fat: 8.4, category: 'Carnes' },
  { id: '108', name: 'Coxão duro bovino', calories: 140, protein: 32.2, carbs: 0.0, fat: 2.4, category: 'Carnes' },
  { id: '109', name: 'Coxão mole bovino', calories: 133, protein: 31.7, carbs: 0.0, fat: 2.2, category: 'Carnes' },
  { id: '110', name: 'Filé mignon bovino', calories: 142, protein: 26.2, carbs: 0.0, fat: 4.2, category: 'Carnes' },
  { id: '111', name: 'Fraldinha bovina', calories: 248, protein: 26.4, carbs: 0.0, fat: 15.4, category: 'Carnes' },
  { id: '112', name: 'Lagarto bovino', calories: 130, protein: 32.1, carbs: 0.0, fat: 1.8, category: 'Carnes' },
  { id: '113', name: 'Músculo bovino', calories: 163, protein: 28.7, carbs: 0.0, fat: 5.1, category: 'Carnes' },
  { id: '114', name: 'Picanha bovina', calories: 287, protein: 20.3, carbs: 0.0, fat: 22.3, category: 'Carnes' },
  { id: '115', name: 'Frango coxa com pele', calories: 204, protein: 18.7, carbs: 0.0, fat: 13.7, category: 'Carnes' },
  { id: '116', name: 'Frango coxa sem pele', calories: 125, protein: 20.0, carbs: 0.0, fat: 4.3, category: 'Carnes' },
  { id: '117', name: 'Frango sobrecoxa com pele', calories: 178, protein: 19.7, carbs: 0.0, fat: 10.2, category: 'Carnes' },
  { id: '118', name: 'Frango sobrecoxa sem pele', calories: 124, protein: 21.2, carbs: 0.0, fat: 3.8, category: 'Carnes' },
  { id: '119', name: 'Peru peito', calories: 103, protein: 23.2, carbs: 0.0, fat: 1.2, category: 'Carnes' },
  { id: '120', name: 'Porco bisteca', calories: 273, protein: 19.0, carbs: 0.0, fat: 21.2, category: 'Carnes' },
  { id: '121', name: 'Porco costela', calories: 290, protein: 18.5, carbs: 0.0, fat: 23.8, category: 'Carnes' },
  { id: '122', name: 'Porco lombo', calories: 153, protein: 27.4, carbs: 0.0, fat: 4.0, category: 'Carnes' },
  { id: '123', name: 'Porco pernil', calories: 198, protein: 27.4, carbs: 0.0, fat: 8.8, category: 'Carnes' },
  { id: '124', name: 'Linguiça calabresa', calories: 296, protein: 19.0, carbs: 2.8, fat: 23.0, category: 'Carnes' },
  { id: '125', name: 'Linguiça toscana', calories: 325, protein: 16.0, carbs: 1.5, fat: 28.5, category: 'Carnes' },
  { id: '126', name: 'Mortadela', calories: 314, protein: 14.2, carbs: 1.4, fat: 28.0, category: 'Carnes' },
  { id: '127', name: 'Presunto', calories: 162, protein: 20.4, carbs: 0.0, fat: 8.3, category: 'Carnes' },
  { id: '128', name: 'Salame', calories: 431, protein: 21.9, carbs: 1.0, fat: 37.6, category: 'Carnes' },
  { id: '129', name: 'Salsicha', calories: 296, protein: 11.4, carbs: 10.0, fat: 24.9, category: 'Carnes' },

  // PEIXES E FRUTOS DO MAR (130-180)
  { id: '130', name: 'Atum fresco grelhado', calories: 118, protein: 26.0, carbs: 0.0, fat: 1.3, category: 'Peixes' },
  { id: '131', name: 'Bacalhau salgado seco', calories: 136, protein: 32.1, carbs: 0.0, fat: 1.1, category: 'Peixes' },
  { id: '132', name: 'Camarão cozido', calories: 91, protein: 18.1, carbs: 1.3, fat: 1.2, category: 'Peixes' },
  { id: '133', name: 'Caranguejo cozido', calories: 83, protein: 18.5, carbs: 0.0, fat: 0.6, category: 'Peixes' },
  { id: '134', name: 'Corvina crua', calories: 90, protein: 17.0, carbs: 0.0, fat: 2.4, category: 'Peixes' },
  { id: '135', name: 'Dourada crua', calories: 76, protein: 17.0, carbs: 0.0, fat: 0.6, category: 'Peixes' },
  { id: '136', name: 'Linguado cru', calories: 78, protein: 16.9, carbs: 0.0, fat: 1.2, category: 'Peixes' },
  { id: '137', name: 'Lula crua', calories: 75, protein: 15.6, carbs: 0.6, fat: 0.7, category: 'Peixes' },
  { id: '138', name: 'Merluza crua', calories: 84, protein: 17.0, carbs: 0.0, fat: 1.8, category: 'Peixes' },
  { id: '139', name: 'Pescada crua', calories: 81, protein: 17.7, carbs: 0.0, fat: 1.2, category: 'Peixes' },
  { id: '140', name: 'Pintado cru', calories: 91, protein: 18.8, carbs: 0.0, fat: 1.8, category: 'Peixes' },
  { id: '141', name: 'Robalo cru', calories: 87, protein: 18.9, carbs: 0.0, fat: 1.3, category: 'Peixes' },
  { id: '142', name: 'Sardinha fresca', calories: 86, protein: 19.8, carbs: 0.0, fat: 1.4, category: 'Peixes' },
  { id: '143', name: 'Sardinha em conserva', calories: 130, protein: 24.6, carbs: 0.0, fat: 3.3, category: 'Peixes' },
  { id: '144', name: 'Surubim cru', calories: 90, protein: 18.0, carbs: 0.0, fat: 2.0, category: 'Peixes' },
  { id: '145', name: 'Tucunaré cru', calories: 96, protein: 18.4, carbs: 0.0, fat: 2.5, category: 'Peixes' },

  // LEGUMINOSAS (146-195)
  { id: '146', name: 'Feijão preto cozido', calories: 77, protein: 4.5, carbs: 14.0, fat: 0.5, category: 'Leguminosas' },
  { id: '147', name: 'Feijão carioca cozido', calories: 76, protein: 4.8, carbs: 13.6, fat: 0.5, category: 'Leguminosas' },
  { id: '148', name: 'Lentilha cozida', calories: 93, protein: 6.3, carbs: 16.3, fat: 0.6, category: 'Leguminosas' },
  { id: '149', name: 'Grão de bico cozido', calories: 164, protein: 8.9, carbs: 27.4, fat: 2.6, category: 'Leguminosas' },
  { id: '150', name: 'Ervilha em vagem', calories: 88, protein: 7.5, carbs: 15.6, fat: 0.2, category: 'Leguminosas' },
  { id: '151', name: 'Ervilha seca', calories: 374, protein: 21.7, carbs: 63.7, fat: 2.3, category: 'Leguminosas' },
  { id: '152', name: 'Fava', calories: 76, protein: 6.1, carbs: 13.2, fat: 0.8, category: 'Leguminosas' },
  { id: '153', name: 'Feijão azuki', calories: 128, protein: 8.5, carbs: 23.0, fat: 0.5, category: 'Leguminosas' },
  { id: '154', name: 'Feijão branco', calories: 123, protein: 8.5, carbs: 22.3, fat: 0.8, category: 'Leguminosas' },
  { id: '155', name: 'Feijão fradinho', calories: 108, protein: 7.5, carbs: 18.8, fat: 0.8, category: 'Leguminosas' },
  { id: '156', name: 'Feijão jalo', calories: 100, protein: 6.6, carbs: 17.5, fat: 0.8, category: 'Leguminosas' },
  { id: '157', name: 'Feijão mulatinho', calories: 83, protein: 5.5, carbs: 14.5, fat: 0.7, category: 'Leguminosas' },
  { id: '158', name: 'Feijão rosinha', calories: 85, protein: 5.8, carbs: 14.8, fat: 0.6, category: 'Leguminosas' },
  { id: '159', name: 'Soja em grão', calories: 405, protein: 34.3, carbs: 38.4, fat: 18.2, category: 'Leguminosas' },

  // LATICÍNIOS (160-210)
  { id: '160', name: 'Leite integral', calories: 61, protein: 2.9, carbs: 4.3, fat: 3.2, category: 'Laticínios' },
  { id: '161', name: 'Iogurte natural', calories: 51, protein: 4.1, carbs: 4.0, fat: 2.5, category: 'Laticínios' },
  { id: '162', name: 'Queijo minas frescal', calories: 264, protein: 17.4, carbs: 2.9, fat: 20.2, category: 'Laticínios' },
  { id: '163', name: 'Requeijão cremoso', calories: 270, protein: 11.6, carbs: 3.0, fat: 24.0, category: 'Laticínios' },
  { id: '164', name: 'Leite desnatado', calories: 35, protein: 3.4, carbs: 4.9, fat: 0.1, category: 'Laticínios' },
  { id: '165', name: 'Leite semidesnatado', calories: 45, protein: 3.2, carbs: 4.4, fat: 1.5, category: 'Laticínios' },
  { id: '166', name: 'Iogurte desnatado', calories: 37, protein: 4.0, carbs: 4.7, fat: 0.9, category: 'Laticínios' },
  { id: '167', name: 'Queijo cottage', calories: 105, protein: 12.3, carbs: 2.7, fat: 4.5, category: 'Laticínios' },
  { id: '168', name: 'Queijo mussarela', calories: 330, protein: 20.3, carbs: 4.2, fat: 25.9, category: 'Laticínios' },
  { id: '169', name: 'Queijo parmesão', calories: 453, protein: 42.2, carbs: 0.0, fat: 30.0, category: 'Laticínios' },
  { id: '170', name: 'Queijo prato', calories: 360, protein: 17.3, carbs: 0.0, fat: 32.3, category: 'Laticínios' },
  { id: '171', name: 'Queijo ricota', calories: 140, protein: 8.1, carbs: 3.4, fat: 10.5, category: 'Laticínios' },
  { id: '172', name: 'Creme de leite', calories: 292, protein: 2.1, carbs: 2.8, fat: 30.9, category: 'Laticínios' },
  { id: '173', name: 'Manteiga com sal', calories: 760, protein: 0.6, carbs: 0.0, fat: 84.0, category: 'Laticínios' },
  { id: '174', name: 'Margarina com sal', calories: 596, protein: 0.9, carbs: 1.4, fat: 65.0, category: 'Laticínios' },

  // OLEAGINOSAS E SEMENTES (175-225)
  { id: '175', name: 'Amendoim torrado', calories: 544, protein: 27.2, carbs: 20.3, fat: 43.9, category: 'Oleaginosas' },
  { id: '176', name: 'Castanha do Pará', calories: 643, protein: 14.5, carbs: 15.1, fat: 63.5, category: 'Oleaginosas' },
  { id: '177', name: 'Amêndoa', calories: 640, protein: 19.5, carbs: 19.5, fat: 56.0, category: 'Oleaginosas' },
  { id: '178', name: 'Avelã', calories: 633, protein: 12.0, carbs: 9.4, fat: 62.4, category: 'Oleaginosas' },
  { id: '179', name: 'Castanha de caju', calories: 570, protein: 18.5, carbs: 28.7, fat: 46.3, category: 'Oleaginosas' },
  { id: '180', name: 'Macadâmia', calories: 718, protein: 8.0, carbs: 5.2, fat: 75.8, category: 'Oleaginosas' },
  { id: '181', name: 'Noz', calories: 674, protein: 14.3, carbs: 18.5, fat: 63.3, category: 'Oleaginosas' },
  { id: '182', name: 'Pistache', calories: 594, protein: 21.4, carbs: 11.6, fat: 51.6, category: 'Oleaginosas' },
  { id: '183', name: 'Semente de girassol', calories: 570, protein: 19.3, carbs: 18.8, fat: 49.6, category: 'Oleaginosas' },
  { id: '184', name: 'Semente de abóbora', calories: 610, protein: 18.8, carbs: 18.4, fat: 54.0, category: 'Oleaginosas' },

  // ÓLEOS E GORDURAS (185-200)
  { id: '185', name: 'Azeite de oliva', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },
  { id: '186', name: 'Óleo de soja', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },
  { id: '187', name: 'Óleo de canola', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },
  { id: '188', name: 'Óleo de milho', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },
  { id: '189', name: 'Óleo de girassol', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },
  { id: '190', name: 'Banha de porco', calories: 898, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Óleos' },

  // AÇÚCARES E DOCES (191-240)
  { id: '191', name: 'Açúcar cristal', calories: 387, protein: 0.0, carbs: 99.9, fat: 0.0, category: 'Açúcares' },
  { id: '192', name: 'Mel de abelha', calories: 309, protein: 0.4, carbs: 84.0, fat: 0.0, category: 'Açúcares' },
  { id: '193', name: 'Açúcar demerara', calories: 376, protein: 0.0, carbs: 97.3, fat: 0.0, category: 'Açúcares' },
  { id: '194', name: 'Açúcar mascavo', calories: 369, protein: 0.1, carbs: 95.5, fat: 0.1, category: 'Açúcares' },
  { id: '195', name: 'Rapadura', calories: 312, protein: 0.7, carbs: 78.2, fat: 0.6, category: 'Açúcares' },
  { id: '196', name: 'Melado de cana', calories: 295, protein: 0.7, carbs: 75.9, fat: 0.0, category: 'Açúcares' },
  { id: '197', name: 'Chocolate ao leite', calories: 533, protein: 7.3, carbs: 59.5, fat: 29.6, category: 'Açúcares' },
  { id: '198', name: 'Chocolate meio amargo', calories: 473, protein: 5.8, carbs: 63.0, fat: 23.8, category: 'Açúcares' },
  { id: '199', name: 'Doce de leite', calories: 306, protein: 7.3, carbs: 55.6, fat: 7.5, category: 'Açúcares' },
  { id: '200', name: 'Goiabada', calories: 272, protein: 0.4, carbs: 70.9, fat: 0.2, category: 'Açúcares' },

  // BEBIDAS (201-250)
  { id: '201', name: 'Água', calories: 0, protein: 0.0, carbs: 0.0, fat: 0.0, category: 'Bebidas' },
  { id: '202', name: 'Café infusão', calories: 2, protein: 0.1, carbs: 0.6, fat: 0.0, category: 'Bebidas' },
  { id: '203', name: 'Chá mate', calories: 2, protein: 0.0, carbs: 0.4, fat: 0.0, category: 'Bebidas' },
  { id: '204', name: 'Refrigerante cola', calories: 37, protein: 0.0, carbs: 9.7, fat: 0.0, category: 'Bebidas' },
  { id: '205', name: 'Suco de laranja natural', calories: 42, protein: 0.5, carbs: 10.4, fat: 0.1, category: 'Bebidas' },
  { id: '206', name: 'Suco de uva integral', calories: 58, protein: 0.3, carbs: 14.7, fat: 0.1, category: 'Bebidas' },
  { id: '207', name: 'Água de coco', calories: 22, protein: 0.7, carbs: 5.5, fat: 0.1, category: 'Bebidas' },
  { id: '208', name: 'Cerveja', calories: 35, protein: 0.2, carbs: 1.9, fat: 0.0, category: 'Bebidas' },
  { id: '209', name: 'Vinho tinto', calories: 69, protein: 0.1, carbs: 0.3, fat: 0.0, category: 'Bebidas' },
  { id: '210', name: 'Cachaça', calories: 263, protein: 0.0, carbs: 0.3, fat: 0.0, category: 'Bebidas' },

  // TUBÉRCULOS E RAÍZES (211-260)
  { id: '211', name: 'Batata baroa', calories: 98, protein: 1.9, carbs: 23.4, fat: 0.3, category: 'Tubérculos' },
  { id: '212', name: 'Batata doce roxa', calories: 123, protein: 1.3, carbs: 28.2, fat: 0.8, category: 'Tubérculos' },
  { id: '213', name: 'Inhame cru', calories: 97, protein: 2.3, carbs: 23.2, fat: 0.3, category: 'Tubérculos' },
  { id: '214', name: 'Mandioquinha', calories: 98, protein: 1.9, carbs: 23.4, fat: 0.3, category: 'Tubérculos' },
  { id: '215', name: 'Cará cru', calories: 116, protein: 2.8, carbs: 27.9, fat: 0.3, category: 'Tubérculos' },
  { id: '216', name: 'Taioba folha', calories: 30, protein: 3.3, carbs: 5.2, fat: 0.4, category: 'Tubérculos' },

  // CONDIMENTOS E ESPECIARIAS (217-267)
  { id: '217', name: 'Sal refinado', calories: 0, protein: 0.0, carbs: 0.0, fat: 0.0, category: 'Condimentos' },
  { id: '218', name: 'Pimenta do reino', calories: 296, protein: 11.5, carbs: 38.3, fat: 3.2, category: 'Condimentos' },
  { id: '219', name: 'Orégano', calories: 306, protein: 11.0, carbs: 21.6, fat: 10.3, category: 'Condimentos' },
  { id: '220', name: 'Manjericão', calories: 23, protein: 3.2, carbs: 1.1, fat: 0.8, category: 'Condimentos' },
  { id: '221', name: 'Salsa', calories: 31, protein: 3.3, carbs: 5.1, fat: 0.4, category: 'Condimentos' },
  { id: '222', name: 'Cebolinha', calories: 27, protein: 1.8, carbs: 6.0, fat: 0.1, category: 'Condimentos' },
  { id: '223', name: 'Coentro', calories: 31, protein: 2.8, carbs: 4.8, fat: 0.6, category: 'Condimentos' },
  { id: '224', name: 'Hortelã', calories: 43, protein: 4.8, carbs: 5.3, fat: 0.6, category: 'Condimentos' },
  { id: '225', name: 'Alecrim', calories: 331, protein: 4.9, carbs: 64.1, fat: 15.2, category: 'Condimentos' },
  { id: '226', name: 'Canela em pó', calories: 261, protein: 3.9, carbs: 79.9, fat: 3.2, category: 'Condimentos' },
  { id: '227', name: 'Cravo da índia', calories: 323, protein: 6.0, carbs: 61.2, fat: 20.1, category: 'Condimentos' },
  { id: '228', name: 'Gengibre', calories: 22, protein: 1.1, carbs: 4.3, fat: 0.2, category: 'Condimentos' },
  { id: '229', name: 'Noz moscada', calories: 525, protein: 5.8, carbs: 28.5, fat: 47.4, category: 'Condimentos' },
  { id: '230', name: 'Páprica doce', calories: 289, protein: 14.8, carbs: 35.7, fat: 12.9, category: 'Condimentos' },

  // PRODUTOS INDUSTRIALIZADOS (231-330)
  { id: '231', name: 'Maionese', calories: 653, protein: 1.6, carbs: 2.0, fat: 71.2, category: 'Industrializados' },
  { id: '232', name: 'Ketchup', calories: 100, protein: 1.8, carbs: 24.7, fat: 0.1, category: 'Industrializados' },
  { id: '233', name: 'Mostarda', calories: 74, protein: 4.7, carbs: 7.3, fat: 3.3, category: 'Industrializados' },
  { id: '234', name: 'Molho de soja', calories: 61, protein: 10.5, carbs: 5.6, fat: 0.1, category: 'Industrializados' },
  { id: '235', name: 'Vinagre de vinho', calories: 4, protein: 0.0, carbs: 0.4, fat: 0.0, category: 'Industrializados' },
  { id: '236', name: 'Extrato de tomate', calories: 89, protein: 4.6, carbs: 18.9, fat: 0.2, category: 'Industrializados' },
  { id: '237', name: 'Molho de tomate', calories: 23, protein: 1.6, carbs: 4.6, fat: 0.2, category: 'Industrializados' },
  { id: '238', name: 'Caldo de galinha', calories: 15, protein: 1.4, carbs: 1.3, fat: 0.8, category: 'Industrializados' },
  { id: '239', name: 'Fermento biológico', calories: 53, protein: 11.4, carbs: 5.1, fat: 0.4, category: 'Industrializados' },
  { id: '240', name: 'Gelatina em pó', calories: 358, protein: 84.4, carbs: 0.0, fat: 0.5, category: 'Industrializados' },

  // FRUTAS SECAS E DESIDRATADAS (241-290)
  { id: '241', name: 'Uva passa', calories: 252, protein: 2.5, carbs: 66.2, fat: 0.2, category: 'Frutas Secas' },
  { id: '242', name: 'Damasco seco', calories: 230, protein: 3.4, carbs: 59.6, fat: 0.4, category: 'Frutas Secas' },
  { id: '243', name: 'Figo seco', calories: 228, protein: 3.5, carbs: 57.9, fat: 1.3, category: 'Frutas Secas' },
  { id: '244', name: 'Tâmara seca', calories: 228, protein: 2.4, carbs: 59.0, fat: 0.4, category: 'Frutas Secas' },
  { id: '245', name: 'Banana passa', calories: 290, protein: 2.3, carbs: 74.2, fat: 0.8, category: 'Frutas Secas' },

  // HORTALIÇAS FOLHOSAS (246-295)
  { id: '246', name: 'Espinafre cozido', calories: 18, protein: 2.4, carbs: 1.6, fat: 0.3, category: 'Folhosas' },
  { id: '247', name: 'Couve refogada', calories: 31, protein: 2.9, carbs: 5.1, fat: 0.4, category: 'Folhosas' },
  { id: '248', name: 'Rúcula refogada', calories: 19, protein: 2.8, carbs: 2.2, fat: 0.5, category: 'Folhosas' },
  { id: '249', name: 'Almeirão refogado', calories: 20, protein: 2.0, carbs: 3.6, fat: 0.3, category: 'Folhosas' },
  { id: '250', name: 'Mostarda folha', calories: 15, protein: 2.7, carbs: 1.7, fat: 0.2, category: 'Folhosas' },

  // COGUMELOS (251-270)
  { id: '251', name: 'Champignon cru', calories: 25, protein: 2.6, carbs: 4.3, fat: 0.1, category: 'Cogumelos' },
  { id: '252', name: 'Shiitake cru', calories: 39, protein: 2.2, carbs: 8.9, fat: 0.2, category: 'Cogumelos' },
  { id: '253', name: 'Shimeji cru', calories: 35, protein: 2.3, carbs: 7.0, fat: 0.3, category: 'Cogumelos' },

  // ERVAS E PLANTAS MEDICINAIS (271-320)
  { id: '271', name: 'Capim santo', calories: 25, protein: 1.8, carbs: 5.5, fat: 0.4, category: 'Ervas' },
  { id: '272', name: 'Carqueja', calories: 23, protein: 2.1, carbs: 4.8, fat: 0.3, category: 'Ervas' },
  { id: '273', name: 'Erva cidreira', calories: 44, protein: 3.7, carbs: 8.8, fat: 0.6, category: 'Ervas' },
  { id: '274', name: 'Hortelã pimenta', calories: 43, protein: 4.8, carbs: 5.3, fat: 0.6, category: 'Ervas' },

  // ALIMENTOS REGIONAIS BRASILEIROS (321-420)
  { id: '321', name: 'Açaí na tigela', calories: 58, protein: 0.8, carbs: 6.2, fat: 3.9, category: 'Regionais' },
  { id: '322', name: 'Babaçu amêndoa', calories: 643, protein: 17.0, carbs: 7.4, fat: 61.9, category: 'Regionais' },
  { id: '323', name: 'Buriti polpa', calories: 308, protein: 3.5, carbs: 18.7, fat: 25.2, category: 'Regionais' },
  { id: '324', name: 'Cajá polpa', calories: 46, protein: 1.0, carbs: 11.4, fat: 0.5, category: 'Regionais' },
  { id: '325', name: 'Caju castanha', calories: 570, protein: 18.5, carbs: 28.7, fat: 46.3, category: 'Regionais' },
  { id: '326', name: 'Cupuaçu polpa', calories: 49, protein: 1.5, carbs: 9.5, fat: 1.8, category: 'Regionais' },
  { id: '327', name: 'Guaraná fruto', calories: 28, protein: 0.1, carbs: 7.3, fat: 0.0, category: 'Regionais' },
  { id: '328', name: 'Pequi polpa', calories: 205, protein: 2.8, carbs: 4.2, fat: 20.0, category: 'Regionais' },
  { id: '329', name: 'Pupunha cozida', calories: 142, protein: 2.8, carbs: 27.9, fat: 4.4, category: 'Regionais' },
  { id: '330', name: 'Tucumã polpa', calories: 262, protein: 5.5, carbs: 4.4, fat: 25.4, category: 'Regionais' },
  { id: '331', name: 'Umbu polpa', calories: 37, protein: 1.0, carbs: 9.2, fat: 0.2, category: 'Regionais' },
  { id: '332', name: 'Mangaba', calories: 43, protein: 0.5, carbs: 11.6, fat: 0.1, category: 'Regionais' },
  { id: '333', name: 'Murici', calories: 78, protein: 0.5, carbs: 20.2, fat: 0.2, category: 'Regionais' },
  { id: '334', name: 'Seriguela', calories: 76, protein: 0.8, carbs: 19.7, fat: 0.2, category: 'Regionais' },

  // PRATOS TÍPICOS BRASILEIROS (335-384)
  { id: '335', name: 'Feijoada', calories: 167, protein: 8.6, carbs: 10.4, fat: 10.6, category: 'Pratos Típicos' },
  { id: '336', name: 'Moqueca de peixe', calories: 105, protein: 12.8, carbs: 3.2, fat: 4.8, category: 'Pratos Típicos' },
  { id: '337', name: 'Vatapá', calories: 178, protein: 6.2, carbs: 8.4, fat: 14.2, category: 'Pratos Típicos' },
  { id: '338', name: 'Acarajé', calories: 207, protein: 5.8, carbs: 18.4, fat: 12.9, category: 'Pratos Típicos' },
  { id: '339', name: 'Bobó de camarão', calories: 142, protein: 8.9, carbs: 12.1, fat: 7.3, category: 'Pratos Típicos' },
  { id: '340', name: 'Caruru', calories: 89, protein: 4.2, carbs: 8.7, fat: 4.8, category: 'Pratos Típicos' },
  { id: '341', name: 'Farofa de mandioca', calories: 365, protein: 1.6, carbs: 88.9, fat: 0.6, category: 'Pratos Típicos' },
  { id: '342', name: 'Pamonha doce', calories: 123, protein: 2.8, carbs: 27.4, fat: 1.3, category: 'Pratos Típicos' },
  { id: '343', name: 'Pamonha salgada', calories: 108, protein: 3.2, carbs: 22.1, fat: 1.8, category: 'Pratos Típicos' },
  { id: '344', name: 'Pé de moleque', calories: 459, protein: 9.8, carbs: 67.2, fat: 18.4, category: 'Pratos Típicos' },

  // PESCADOS REGIONAIS (345-394)
  { id: '345', name: 'Pirarucu', calories: 165, protein: 28.4, carbs: 0.0, fat: 5.2, category: 'Pescados Regionais' },
  { id: '346', name: 'Tambaqui', calories: 152, protein: 20.3, carbs: 0.0, fat: 7.2, category: 'Pescados Regionais' },
  { id: '347', name: 'Tucunaré', calories: 96, protein: 18.4, carbs: 0.0, fat: 2.5, category: 'Pescados Regionais' },
  { id: '348', name: 'Piranha', calories: 89, protein: 18.8, carbs: 0.0, fat: 1.8, category: 'Pescados Regionais' },
  { id: '349', name: 'Pacu', calories: 165, protein: 16.8, carbs: 0.0, fat: 10.4, category: 'Pescados Regionais' },
  { id: '350', name: 'Dourado', calories: 142, protein: 20.3, carbs: 0.0, fat: 6.2, category: 'Pescados Regionais' },

  // CARNES DE CAÇA (351-370)
  { id: '351', name: 'Capivara', calories: 162, protein: 20.3, carbs: 0.0, fat: 8.5, category: 'Carnes de Caça' },
  { id: '352', name: 'Jacaré', calories: 143, protein: 21.5, carbs: 0.0, fat: 5.6, category: 'Carnes de Caça' },
  { id: '353', name: 'Paca', calories: 146, protein: 20.3, carbs: 0.0, fat: 6.8, category: 'Carnes de Caça' },
  { id: '354', name: 'Veado', calories: 120, protein: 22.9, carbs: 0.0, fat: 2.4, category: 'Carnes de Caça' },

  // INSETOS COMESTÍVEIS (371-380)
  { id: '371', name: 'Formiga tanajura', calories: 543, protein: 58.5, carbs: 2.9, fat: 32.2, category: 'Insetos' },
  { id: '372', name: 'Gafanhoto', calories: 347, protein: 20.6, carbs: 5.0, fat: 6.1, category: 'Insetos' },

  // BEBIDAS REGIONAIS (381-430)
  { id: '381', name: 'Guaraná natural', calories: 28, protein: 0.1, carbs: 7.3, fat: 0.0, category: 'Bebidas Regionais' },
  { id: '382', name: 'Caldo de cana', calories: 54, protein: 0.2, carbs: 13.8, fat: 0.1, category: 'Bebidas Regionais' },
  { id: '383', name: 'Vinho de buriti', calories: 42, protein: 0.1, carbs: 10.8, fat: 0.0, category: 'Bebidas Regionais' },

  // DOCES REGIONAIS (431-480)
  { id: '431', name: 'Brigadeiro', calories: 424, protein: 4.2, carbs: 70.8, fat: 14.2, category: 'Doces Regionais' },
  { id: '432', name: 'Beijinho', calories: 398, protein: 3.8, carbs: 68.4, fat: 12.8, category: 'Doces Regionais' },
  { id: '433', name: 'Quindim', calories: 387, protein: 6.8, carbs: 58.2, fat: 14.8, category: 'Doces Regionais' },
  { id: '434', name: 'Pudim de leite', calories: 221, protein: 4.8, carbs: 35.2, fat: 7.2, category: 'Doces Regionais' },
  { id: '435', name: 'Cocada branca', calories: 453, protein: 3.2, carbs: 68.4, fat: 18.9, category: 'Doces Regionais' },
  { id: '436', name: 'Cocada preta', calories: 389, protein: 2.8, carbs: 78.2, fat: 8.4, category: 'Doces Regionais' },
  { id: '437', name: 'Doce de abóbora', calories: 198, protein: 0.8, carbs: 51.2, fat: 0.2, category: 'Doces Regionais' },
  { id: '438', name: 'Doce de mamão', calories: 245, protein: 0.4, carbs: 63.8, fat: 0.1, category: 'Doces Regionais' },
  { id: '439', name: 'Marmelada', calories: 272, protein: 0.3, carbs: 71.2, fat: 0.2, category: 'Doces Regionais' },
  { id: '440', name: 'Pé de moleque', calories: 459, protein: 9.8, carbs: 67.2, fat: 18.4, category: 'Doces Regionais' },

  // PANIFICAÇÃO REGIONAL (481-530)
  { id: '481', name: 'Pão de açúcar', calories: 300, protein: 8.0, carbs: 58.0, fat: 4.5, category: 'Panificação Regional' },
  { id: '482', name: 'Broa de milho', calories: 298, protein: 6.8, carbs: 58.4, fat: 5.2, category: 'Panificação Regional' },
  { id: '483', name: 'Casquinha de siri', calories: 187, protein: 8.4, carbs: 18.2, fat: 9.8, category: 'Panificação Regional' },
  { id: '484', name: 'Pão de queijo', calories: 335, protein: 11.2, carbs: 38.4, fat: 15.8, category: 'Panificação Regional' },
  { id: '485', name: 'Biscoito de polvilho', calories: 347, protein: 1.2, carbs: 85.4, fat: 1.8, category: 'Panificação Regional' },

  // BEBIDAS FERMENTADAS (531-550)
  { id: '531', name: 'Kefir', calories: 43, protein: 3.3, carbs: 4.8, fat: 1.0, category: 'Fermentados' },
  { id: '532', name: 'Kombucha', calories: 24, protein: 0.0, carbs: 6.0, fat: 0.0, category: 'Fermentados' },

  // SUPLEMENTOS NATURAIS (551-597)
  { id: '551', name: 'Spirulina', calories: 290, protein: 57.5, carbs: 23.9, fat: 7.7, category: 'Suplementos' },
  { id: '552', name: 'Chlorella', calories: 336, protein: 58.4, carbs: 14.6, fat: 10.6, category: 'Suplementos' },
  { id: '553', name: 'Pólen de abelha', calories: 234, protein: 22.7, carbs: 27.6, fat: 5.1, category: 'Suplementos' },
  { id: '554', name: 'Própolis', calories: 70, protein: 1.2, carbs: 16.0, fat: 0.3, category: 'Suplementos' },
  { id: '555', name: 'Geleia real', calories: 147, protein: 12.8, carbs: 11.0, fat: 5.5, category: 'Suplementos' },

  // TEMPEROS E MOLHOS BRASILEIROS (556-597)
  { id: '556', name: 'Molho de pimenta', calories: 12, protein: 0.8, carbs: 2.4, fat: 0.2, category: 'Temperos Brasileiros' },
  { id: '557', name: 'Tucumã', calories: 185, protein: 3.2, carbs: 8.4, fat: 16.7, category: 'Temperos Brasileiros' },
  { id: '558', name: 'Dendê', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Temperos Brasileiros' },
  { id: '559', name: 'Leite de coco', calories: 154, protein: 1.6, carbs: 2.9, fat: 15.6, category: 'Temperos Brasileiros' },
  { id: '560', name: 'Farinha de mandioca torrada', calories: 349, protein: 1.8, carbs: 85.3, fat: 0.8, category: 'Temperos Brasileiros' },
  { id: '561', name: 'Polvilho doce', calories: 347, protein: 0.1, carbs: 86.9, fat: 0.1, category: 'Temperos Brasileiros' },
  { id: '562', name: 'Polvilho azedo', calories: 349, protein: 0.2, carbs: 87.2, fat: 0.2, category: 'Temperos Brasileiros' },
  { id: '563', name: 'Goma de mandioca', calories: 342, protein: 0.6, carbs: 85.6, fat: 0.3, category: 'Temperos Brasileiros' },
  { id: '564', name: 'Farinha de banana', calories: 328, protein: 3.8, carbs: 81.2, fat: 1.8, category: 'Temperos Brasileiros' },
  { id: '565', name: 'Farinha de coco', calories: 660, protein: 17.6, carbs: 23.7, fat: 64.5, category: 'Temperos Brasileiros' },
  { id: '566', name: 'Castanha de baru', calories: 559, protein: 23.8, carbs: 7.9, fat: 48.2, category: 'Temperos Brasileiros' },
  { id: '567', name: 'Banha de coco', calories: 862, protein: 0.0, carbs: 0.0, fat: 99.9, category: 'Temperos Brasileiros' },
  { id: '568', name: 'Óleo de pequi', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Temperos Brasileiros' },
  { id: '569', name: 'Vinagre de caju', calories: 18, protein: 0.1, carbs: 4.2, fat: 0.0, category: 'Temperos Brasileiros' },
  { id: '570', name: 'Molho de tucumã', calories: 89, protein: 1.2, carbs: 4.8, fat: 8.2, category: 'Temperos Brasileiros' },
  { id: '571', name: 'Extrato de açaí', calories: 247, protein: 3.8, carbs: 4.9, fat: 25.4, category: 'Temperos Brasileiros' },
  { id: '572', name: 'Farinha de babaçu', calories: 387, protein: 8.7, carbs: 79.5, fat: 7.2, category: 'Temperos Brasileiros' },
  { id: '573', name: 'Óleo de buriti', calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, category: 'Temperos Brasileiros' },
  { id: '574', name: 'Farinha de mandioca d\'água', calories: 343, protein: 1.2, carbs: 84.2, fat: 0.6, category: 'Temperos Brasileiros' },
  { id: '575', name: 'Goma de tapioca', calories: 358, protein: 0.2, carbs: 89.6, fat: 0.1, category: 'Temperos Brasileiros' },
  { id: '576', name: 'Massa de mandioca', calories: 276, protein: 1.8, carbs: 67.2, fat: 0.8, category: 'Temperos Brasileiros' },
  { id: '577', name: 'Farinha de milho flocada', calories: 365, protein: 7.3, carbs: 79.8, fat: 2.4, category: 'Temperos Brasileiros' },
  { id: '578', name: 'Canjica de milho', calories: 112, protein: 2.2, carbs: 24.4, fat: 0.2, category: 'Temperos Brasileiros' },
  { id: '579', name: 'Xerém de milho', calories: 365, protein: 7.3, carbs: 79.8, fat: 2.4, category: 'Temperos Brasileiros' },
  { id: '580', name: 'Fubá de milho', calories: 365, protein: 7.3, carbs: 79.8, fat: 2.4, category: 'Temperos Brasileiros' },
  { id: '581', name: 'Farinha de arroz', calories: 380, protein: 7.2, carbs: 80.1, fat: 2.8, category: 'Temperos Brasileiros' },
  { id: '582', name: 'Farinha de aveia', calories: 405, protein: 13.9, carbs: 66.6, fat: 8.5, category: 'Temperos Brasileiros' },
  { id: '583', name: 'Farinha de centeio', calories: 350, protein: 9.4, carbs: 69.7, fat: 2.5, category: 'Temperos Brasileiros' },
  { id: '584', name: 'Farinha de cevada', calories: 354, protein: 9.9, carbs: 77.7, fat: 1.2, category: 'Temperos Brasileiros' },
  { id: '585', name: 'Farinha de quinoa', calories: 399, protein: 16.5, carbs: 69.0, fat: 6.3, category: 'Temperos Brasileiros' },
  { id: '586', name: 'Farinha de linhaça', calories: 495, protein: 14.1, carbs: 43.3, fat: 32.3, category: 'Temperos Brasileiros' },
  { id: '587', name: 'Farinha de chia', calories: 444, protein: 15.6, carbs: 44.9, fat: 30.8, category: 'Temperos Brasileiros' },
  { id: '588', name: 'Farinha de amaranto', calories: 371, protein: 13.6, carbs: 65.2, fat: 7.0, category: 'Temperos Brasileiros' },
  { id: '589', name: 'Farinha de sorgo', calories: 329, protein: 10.6, carbs: 70.7, fat: 3.5, category: 'Temperos Brasileiros' },
  { id: '590', name: 'Farinha de painço', calories: 364, protein: 11.8, carbs: 72.9, fat: 4.2, category: 'Temperos Brasileiros' },
  { id: '591', name: 'Farinha de teff', calories: 367, protein: 13.3, carbs: 73.1, fat: 2.4, category: 'Temperos Brasileiros' },
  { id: '592', name: 'Farinha de trigo sarraceno', calories: 343, protein: 13.2, carbs: 71.5, fat: 3.4, category: 'Temperos Brasileiros' },
  { id: '593', name: 'Farinha de grão de bico', calories: 387, protein: 22.4, carbs: 57.8, fat: 6.7, category: 'Temperos Brasileiros' },
  { id: '594', name: 'Farinha de feijão', calories: 341, protein: 20.2, carbs: 61.8, fat: 1.8, category: 'Temperos Brasileiros' },
  { id: '595', name: 'Farinha de lentilha', calories: 353, protein: 25.8, carbs: 60.1, fat: 1.1, category: 'Temperos Brasileiros' },
  { id: '596', name: 'Farinha de ervilha', calories: 341, protein: 21.6, carbs: 60.4, fat: 2.3, category: 'Temperos Brasileiros' },
  { id: '597', name: 'Farinha de soja', calories: 385, protein: 36.1, carbs: 38.4, fat: 18.6, category: 'Temperos Brasileiros' },
];

export function searchTacoFoods(query: string): TacoFood[] {
  if (!query.trim()) return tacoFoods;
  
  const normalizedQuery = query.toLowerCase().trim();
  return tacoFoods.filter(food => 
    food.name.toLowerCase().includes(normalizedQuery) ||
    food.category.toLowerCase().includes(normalizedQuery)
  );
}

export function getFoodsByCategory(category: string): TacoFood[] {
  return tacoFoods.filter(food => food.category === category);
}

export function getAllCategories(): string[] {
  const categories = [...new Set(tacoFoods.map(food => food.category))];
  return categories.sort();
}