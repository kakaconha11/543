import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

interface TimePickerProps {
  selectedHour: string;
  selectedMinute: string;
  onHourChange: (hour: string) => void;
  onMinuteChange: (minute: string) => void;
}

const hours = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0'));
const minutes = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

export default function TimePicker({ 
  selectedHour, 
  selectedMinute, 
  onHourChange, 
  onMinuteChange 
}: TimePickerProps) {
  const ITEM_HEIGHT = 40;

  const renderScrollableColumn = (
    items: string[],
    selectedValue: string,
    onValueChange: (value: string) => void,
    testID: string
  ) => {
    return (
      <View style={styles.columnContainer}>
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          snapToInterval={ITEM_HEIGHT}
          decelerationRate="fast"
          onMomentumScrollEnd={(event) => {
            const index = Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT);
            const clampedIndex = Math.max(0, Math.min(index, items.length - 1));
            onValueChange(items[clampedIndex]);
          }}
        >
          {/* Padding items at start */}
          <View style={{ height: ITEM_HEIGHT }} />
          
          {items.map((item, index) => {
            const isSelected = item === selectedValue;
            return (
              <TouchableOpacity
                key={`${testID}-${item}`}
                style={[
                  styles.scrollItem,
                  isSelected && styles.selectedScrollItem
                ]}
                onPress={() => onValueChange(item)}
              >
                <Text style={[
                  styles.scrollItemText,
                  isSelected && styles.selectedScrollItemText
                ]}>
                  {item}
                </Text>
              </TouchableOpacity>
            );
          })}
          
          {/* Padding items at end */}
          <View style={{ height: ITEM_HEIGHT }} />
        </ScrollView>
        
        {/* Selection indicator overlay */}
        <View style={styles.selectionIndicator} />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Time Display Header */}
      <View style={styles.timeDisplayHeader}>
        <Text style={styles.inputLabel}>Horário:</Text>
        <Text style={styles.timeDisplay}>{selectedHour}:{selectedMinute}</Text>
      </View>

      {/* Time Picker Wheels */}
      <View style={styles.pickerContainer}>
        {/* Hour Column */}
        {renderScrollableColumn(hours, selectedHour, onHourChange, 'hour')}

        {/* Separator */}
        <View style={styles.separator}>
          <Text style={styles.separatorText}>:</Text>
        </View>

        {/* Minute Column */}
        {renderScrollableColumn(minutes, selectedMinute, onMinuteChange, 'minute')}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  timeDisplayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  timeDisplay: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F0F1A',
  },
  pickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    height: 120,
    paddingHorizontal: 8,
  },
  columnContainer: {
    flex: 1,
    height: 120,
    position: 'relative',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingVertical: 0,
  },
  scrollItem: {
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  selectedScrollItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    marginHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  scrollItemText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#9CA3AF',
  },
  selectedScrollItemText: {
    color: '#000',
    fontWeight: '700',
    fontSize: 18,
  },
  selectionIndicator: {
    position: 'absolute',
    top: 40,
    left: 8,
    right: 8,
    height: 40,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: 'transparent',
    pointerEvents: 'none',
  },
  separator: {
    paddingHorizontal: 8,
    justifyContent: 'center',
    height: 120,
  },
  separatorText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#374151',
  },
});