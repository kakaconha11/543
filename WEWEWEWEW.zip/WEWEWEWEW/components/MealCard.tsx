import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, TextInput, ScrollView, Alert } from 'react-native';
import { Plus, Search, X, ChevronDown, ChevronUp, Trash2 } from 'lucide-react-native';
import { tacoFoods, searchTacoFoods, TacoFood } from '@/data/tacoFoods';

interface Meal {
  id: number;
  name: string;
  description: string;
  calories: number;
  time: string;
  icon: React.ComponentType<any>;
}

interface FoodItem {
  id: string;
  food: TacoFood;
  grams: number;
}

interface MealCardProps {
  meal: Meal;
  onDeleteMeal: (mealId: number) => void;
}

export default function MealCard({ meal, onDeleteMeal }: MealCardProps) {
  const IconComponent = meal.icon;
  
  const [isExpanded, setIsExpanded] = React.useState(false);
  const [showAddFoodModal, setShowAddFoodModal] = React.useState(false);
  const [showEditFoodModal, setShowEditFoodModal] = React.useState(false);
  const [editingFood, setEditingFood] = React.useState<FoodItem | null>(null);
  const [editGrams, setEditGrams] = React.useState('');
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedGrams, setSelectedGrams] = React.useState('100');
  const [foods, setFoods] = React.useState<FoodItem[]>([]);
  
  const filteredFoods = searchTacoFoods(searchQuery);
  const totalCalories = foods.reduce((sum, item) => sum + (item.food.calories * item.grams / 100), 0);
  const totalCarbs = foods.reduce((sum, item) => sum + (item.food.carbs * item.grams / 100), 0);
  const totalFat = foods.reduce((sum, item) => sum + (item.food.fat * item.grams / 100), 0);
  const totalProtein = foods.reduce((sum, item) => sum + (item.food.protein * item.grams / 100), 0);

  // Update parent component with totals when foods change
  React.useEffect(() => {
    if (meal.onUpdateTotals) {
      meal.onUpdateTotals(meal.id, {
        calories: totalCalories,
        carbs: totalCarbs,
        fat: totalFat,
        protein: totalProtein
      });
    }
  }, [totalCalories, totalCarbs, totalFat, totalProtein, meal.id]);
  
  const handleEditFood = (food: FoodItem) => {
    setEditingFood(food);
    setEditGrams(String(food.grams));
    setShowEditFoodModal(true);
  };

  const handleSaveEditFood = () => {
    if (editingFood) {
      const grams = parseInt(editGrams) || 0;
      setFoods(foods.map(f => 
        f.id === editingFood.id ? { ...f, grams } : f
      ));
      setShowEditFoodModal(false);
      setEditingFood(null);
      setEditGrams('');
    }
  };

  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity 
          style={styles.mealHeader}
          onPress={() => setIsExpanded(!isExpanded)}
        >
          <View style={styles.iconContainer}>
            <IconComponent size={24} color="#6B7280" />
          </View>
          
          <View style={styles.content}>
            <View style={styles.mealNameRow}>
              <Text style={styles.mealName}>{meal.name}</Text>
              <Text style={styles.mealTime}>{meal.time}</Text>
            </View>
            {foods.length > 0 && (
              <Text style={styles.mealDescription}>
                {Math.round(totalCalories)} kcal • Carbs: {Math.round(totalCarbs)}g • Lip: {Math.round(totalFat)}g • Ptn: {Math.round(totalProtein)}g
              </Text>
            )}
          </View>
          
          <TouchableOpacity 
            style={styles.expandButton}
            onPress={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? (
              <ChevronUp size={20} color="#6B7280" />
            ) : (
              <ChevronDown size={20} color="#6B7280" />
            )}
          </TouchableOpacity>
        </TouchableOpacity>

        {/* Expanded Content */}
        {isExpanded && (
          <View style={styles.expandedContent}>
            {/* Food List */}
            {foods.map((item) => (
              <TouchableOpacity 
                key={item.id} 
                style={styles.foodItem}
                onPress={() => handleEditFood(item)}
              >
                <View style={styles.foodInfo}>
                  <View style={styles.foodNameRow}>
                    <Text style={styles.foodName}>{item.food.name}</Text>
                    <Text style={styles.foodGrams}>{item.grams}g</Text>
                  </View>
                  <Text style={styles.nutritionInfo}>
                    {Math.round(item.food.calories * item.grams / 100)} kcal • Carbs: {Math.round(item.food.carbs * item.grams / 100)}g • Lip: {Math.round(item.food.fat * item.grams / 100)}g • Ptn: {Math.round(item.food.protein * item.grams / 100)}g
                  </Text>
                </View>
                <TouchableOpacity 
                  style={styles.removeButton}
                  onPress={() => setFoods(foods.filter(f => f.id !== item.id))}
                >
                  <X size={16} color="#EF4444" />
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
            
            {/* Add Food Button */}
            <TouchableOpacity 
              style={styles.addFoodButton}
              onPress={() => setShowAddFoodModal(true)}
            >
              <Plus size={20} color="#0F0F1A" />
              <Text style={styles.addFoodText}>Adicionar Alimento</Text>
            </TouchableOpacity>
            
            {/* Delete Button */}
            <TouchableOpacity 
              style={styles.deleteButton}
              onPress={() => onDeleteMeal(meal.id)}
            >
              <Trash2 size={16} color="#EF4444" />
              <Text style={styles.deleteButtonText}>Excluir Refeição</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Add Food Modal */}
      <Modal
        visible={showAddFoodModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowAddFoodModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Adicionar Alimento</Text>
              <TouchableOpacity 
                onPress={() => {
                  setShowAddFoodModal(false);
                  setSearchQuery('');
                  setSelectedGrams('100');
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            {/* Search and Grams Input */}
            <View style={styles.searchContainer}>
              <View style={styles.searchRow}>
                <View style={styles.searchInputContainer}>
                  <Search size={20} color="#6B7280" />
                  <TextInput
                    style={styles.searchInput}
                    placeholder="Buscar alimentos..."
                    value={searchQuery}
                    onChangeText={setSearchQuery}
                    placeholderTextColor="#9CA3AF"
                  />
                </View>
                <View style={styles.gramsContainer}>
                  <TextInput
                    style={styles.gramsInput}
                    value={selectedGrams}
                    onChangeText={setSelectedGrams}
                    keyboardType="numeric"
                    placeholder="100"
                    placeholderTextColor="#9CA3AF"
                    maxLength={4}
                    textAlign="center"
                  />
                </View>
                <Text style={styles.gramsLabel}>g</Text>
              </View>
            </View>

            {/* Food List */}
            <ScrollView style={styles.foodList} showsVerticalScrollIndicator={false}>
              {filteredFoods.map((food) => {
                const grams = parseInt(selectedGrams) || 100;
                const calories = Math.round(food.calories * grams / 100);
                
                return (
                  <TouchableOpacity
                    key={food.id}
                    style={styles.foodOption}
                    onPress={() => {
                      const newFood: FoodItem = {
                        id: `${food.id}-${Date.now()}`,
                        food,
                        grams,
                      };
                      setFoods([...foods, newFood]);
                      setShowAddFoodModal(false);
                      setSearchQuery('');
                      setSelectedGrams('100');
                    }}
                  >
                    <View style={styles.foodOptionInfo}>
                      <Text style={styles.foodOptionName}>{food.name}</Text>
                      <Text style={styles.foodOptionDetails}>
                        {calories} cal • {food.category}
                      </Text>
                    </View>
                    <View style={styles.addFoodIcon}>
                      <Plus size={16} color="#FFFFFF" />
                    </View>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>
      {/* Edit Food Modal */}
      <Modal
        visible={showEditFoodModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowEditFoodModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.editModalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Editar Alimento</Text>
              <TouchableOpacity 
                onPress={() => {
                  setShowEditFoodModal(false);
                  setEditingFood(null);
                  setEditGrams('');
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            {editingFood && (
              <>
                <View style={styles.editFoodInfo}>
                  <Text style={styles.editFoodName}>{editingFood.food.name}</Text>
                  <Text style={styles.editFoodCategory}>{editingFood.food.category}</Text>
                </View>

                <View style={styles.editGramsContainer}>
                  <Text style={styles.inputLabel}>Quantidade:</Text>
                  <View style={styles.editGramsRow}>
                    <TextInput
                      style={styles.editGramsInput}
                      value={editGrams}
                      onChangeText={setEditGrams}
                      keyboardType="numeric"
                      placeholder="100"
                      placeholderTextColor="#9CA3AF"
                      maxLength={4}
                      selectTextOnFocus={true}
                    />
                    <Text style={styles.gramsLabel}>g</Text>
                  </View>
                </View>

                <View style={styles.caloriePreview}>
                  <Text style={styles.caloriePreviewText}>
                    {Math.round(editingFood.food.calories * (parseInt(editGrams) || 0) / 100)} calorias
                  </Text>
                </View>

                <TouchableOpacity 
                  style={styles.saveButton}
                  onPress={handleSaveEditFood}
                >
                  <Text style={styles.saveButtonText}>Salvar</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
  },
  mealHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  content: {
    flex: 1,
  },
  mealNameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  mealName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    flex: 1,
  },
  mealTime: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  mealDescription: {
    fontSize: 11,
    color: '#6B7280',
    lineHeight: 20,
  },
  expandButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  expandedContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: '#FEF2F2',
    borderRadius: 8,
    gap: 6,
    marginTop: 12,
  },
  deleteButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#EF4444',
  },
  foodItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F9FAFB',
    gap: 8,
  },
  foodInfo: {
    flex: 1,
  },
  foodName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#000',
    flex: 1,
  },
  foodDetails: {
    fontSize: 12,
    color: '#000',
    fontWeight: '600',
    marginBottom: 2,
  },
  nutritionInfo: {
    fontSize: 12,
    color: '#6B7280',
  },
  foodGrams: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
  },
  gramsEditContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minWidth: 60,
  },
  gramsEditInput: {
    fontSize: 14,
    color: '#000',
    textAlign: 'center',
    minWidth: 30,
    fontWeight: '600',
  },
  gramsEditLabel: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
    marginLeft: 2,
  },
  removeButton: {
    padding: 4,
  },
  addFoodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginTop: 8,
    borderRadius: 8,
    backgroundColor: '#0F0F1A',
    gap: 8,
  },
  addFoodText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '95%',
    maxWidth: 500,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  closeButton: {
    padding: 4,
  },
  searchContainer: {
    marginBottom: 16,
  },
  searchRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
  },
  searchInputContainer: {
    flex: 3,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#000',
  },
  gramsContainer: {
    width: 70,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  gramsInput: {
    fontSize: 16,
    color: '#000',
    textAlign: 'center',
    width: '100%',
  },
  gramsLabel: {
    fontSize: 16,
    color: '#6b7280',
    fontWeight: '500',
    marginLeft: 8,
  },
  foodList: {
    maxHeight: 400,
  },
  foodOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  foodOptionInfo: {
    flex: 1,
  },
  foodNameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  foodOptionName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#000',
    marginBottom: 4,
  },
  foodOptionDetails: {
    fontSize: 14,
    color: '#6B7280',
  },
  addFoodIcon: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: '#0F0F1A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  editModalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    maxWidth: 400,
  },
  editFoodInfo: {
    marginBottom: 20,
    alignItems: 'center',
  },
  editFoodName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
    textAlign: 'center',
  },
  editFoodCategory: {
    fontSize: 14,
    color: '#6B7280',
  },
  editGramsContainer: {
    marginBottom: 16,
  },
  editGramsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  editGramsInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 18,
    color: '#000',
    backgroundColor: '#F9FAFB',
    textAlign: 'center',
    minWidth: 80,
    fontWeight: '600',
  },
  caloriePreview: {
    alignItems: 'center',
    marginBottom: 20,
  },
  caloriePreviewText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F0F1A',
  },
  saveButton: {
    width: '100%',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#0F0F1A',
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  addMoreSection: {
    marginTop: 24,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  addMoreTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  editFoodList: {
    maxHeight: 200,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
    textAlign: 'center',
  },
});