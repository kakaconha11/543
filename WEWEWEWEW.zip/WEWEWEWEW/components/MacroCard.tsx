import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, { useAnimatedStyle } from 'react-native-reanimated';

interface MacroCardProps {
  title: string;
  consumed: number;
  target: number;
  color: string;
  progressColor: string;
  progress: Animated.SharedValue<number>;
}

export default function MacroCard({ title, consumed, target, color, progressColor, progress }: MacroCardProps) {
  const progressBarStyle = useAnimatedStyle(() => ({
    width: `${Math.min(progress.value * 100, 100)}%`,
  }));

  const dotStyle = useAnimatedStyle(() => ({
    left: `${Math.min(progress.value * 100, 100)}%`,
    transform: [{ translateX: -4 }],
  }));

  return (
    <View style={[styles.container, { backgroundColor: color }]}>
      <View style={styles.header}>
        <Text style={styles.title}>{title}</Text>
      </View>
      
      <View style={styles.progressBarContainer}>
        <View style={styles.progressBarBackground}>
          <Animated.View style={[styles.progressBarFill, { backgroundColor: progressColor }, progressBarStyle]} />
          <Animated.View style={[styles.progressDot, { backgroundColor: progressColor }, dotStyle]} />
        </View>
      </View>

      <View style={styles.spacer} />
      
      <View style={styles.valuesContainer}>
        <Text style={styles.valueText}>{consumed}</Text>
        <Text style={styles.valueText}>{target}g</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderRadius: 16,
    padding: 12,
    minHeight: 100,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    justifyContent: 'center',
  },
  title: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  progressBarContainer: {
    width: '100%',
    marginBottom: 16,
    alignItems: 'center',
  },
  progressBarBackground: {
    height: 12,
    backgroundColor: '#F2F2F2',
    borderRadius: 6,
    position: 'relative',
    width: '90%',
  },
  progressBarFill: {
    position: 'absolute',
    left: 0,
    top: 0,
    height: 12,
    borderRadius: 6,
  },
  progressDot: {
    position: 'absolute', 
    top: -3,
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 3,
    borderColor: '#000',
  },
  spacer: {
    flex: 1,
  },
  valuesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    alignItems: 'center',
  },
  valueText: {
    fontSize: 12,
    fontWeight: '400',
    color: '#6B7280',
  },
});