import React from 'react';
import { View, Text } from 'react-native';
import Animated, { useAnimatedProps, useAnimatedStyle } from 'react-native-reanimated';
import { Circle, Svg, Path } from 'react-native-svg';
import { Flame } from 'lucide-react-native';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

interface CircularProgressProps {
  size: number;
  strokeWidth: number;
  progress: Animated.SharedValue<number>;
  backgroundColor: string;
  progressColor: string;
  secondaryColor: string;
  calories: { consumed: number; target: number };
}

export default function CircularProgress({
  size,
  strokeWidth,
  progress,
  backgroundColor,
  progressColor,
  secondaryColor,
  calories,
}: CircularProgressProps) {
  const radius = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;

  const primaryAnimatedProps = useAnimatedProps(() => {
    const strokeDashoffset = circumference * (1 - progress.value);
    return {
      strokeDashoffset,
    };
  });

  const dotAnimatedStyle = useAnimatedStyle(() => {
    const angle = Math.PI * 0.75 + progress.value * 2 * Math.PI; // Start from bottom left, go clockwise
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    
    return {
      transform: [
        { translateX: x },
        { translateY: y },
      ],
    };
  });

  return (
    <View style={{ width: size, height: size, alignItems: 'center' }}>
      <Svg width={size} height={size}>
        {/* Background Circle */}
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={backgroundColor}
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        
        {/* Progress Circle */}
        <AnimatedCircle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={progressColor}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={circumference}
          strokeLinecap="round"
          animatedProps={primaryAnimatedProps}
          transform={`rotate(135 ${size / 2} ${size / 2})`}
        />
      </Svg>
      
      {/* Progress Dot */}
      <Animated.View
        style={[
          {
            position: 'absolute',
            top: size / 2 - 12,
            left: size / 2 - 12,
            width: 24,
            height: 24,
            borderRadius: 12,
            backgroundColor: '#000',
          },
          dotAnimatedStyle,
        ]}
      />
      
      {/* Center Content */}
      <View style={{
        position: 'absolute',
        top: size / 2 - 64,
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        {/* Target icon */}
        <View style={{
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: '#0F0F1A',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 12,
        }}>
          <Flame size={32} color="#FFFFFF" />
        </View>
        <Text style={{
          fontSize: 32,
          fontWeight: '700',
          color: '#000',
          marginBottom: 4,
        }}>
          {calories.consumed} Kcal
        </Text>
        <Text style={{
          fontSize: 14,
          color: '#6B7280',
          fontWeight: '500',
        }}>
          de {calories.target.toLocaleString()}
        </Text>
      </View>
    </View>
  );
}