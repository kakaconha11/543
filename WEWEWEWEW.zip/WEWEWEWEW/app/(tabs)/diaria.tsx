
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Dimensions,
} from 'react-native';
import { 
  ChevronLeft,
  ChevronRight,
  Scale,
  Utensils,
  Droplets,
  Footprints,
  Moon,
  Trophy,
  ChevronDown,
  Crown,
  Ruler,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface DayData {
  day: string;
  date: number;
  isToday: boolean;
  hasProgress: boolean;
}

// Generate current week dynamically based on today's date
const generateCurrentWeek = (): DayData[] => {
  const today = new Date();
  const currentDay = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const mondayOffset = currentDay === 0 ? -6 : 1 - currentDay; // Adjust to start from Monday
  const weekDays = [];
  
  const dayNames = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
  
  // Calculate days of current week (Monday to Sunday)
  for (let i = 0; i < 7; i++) {
    const dayDate = new Date(today);
    dayDate.setDate(today.getDate() + mondayOffset + i);
    const isToday = dayDate.getDate() === today.getDate() && 
                   dayDate.getMonth() === today.getMonth() && 
                   dayDate.getFullYear() === today.getFullYear();
    
    weekDays.push({
      day: isToday ? 'Hoje' : dayNames[i],
      date: dayDate.getDate(),
      isToday: isToday,
      hasProgress: isToday // Only today has progress for now
    });
  }
  
  return weekDays;
};

const currentMonth: DayData[] = generateCurrentWeek();

export default function DiariaScreen() {
  const [fastingTime, setFastingTime] = useState({ hours: 3, minutes: 26, seconds: 2 });
  const [fastingProgress, setFastingProgress] = useState(24);
  const [calories, setCalories] = useState(2279);
  const [waterIntake, setWaterIntake] = useState(0);
  const [steps, setSteps] = useState(0);

  // Fasting timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setFastingTime(prev => {
        let newSeconds = prev.seconds + 1;
        let newMinutes = prev.minutes;
        let newHours = prev.hours;

        if (newSeconds >= 60) {
          newSeconds = 0;
          newMinutes += 1;
        }
        if (newMinutes >= 60) {
          newMinutes = 0;
          newHours += 1;
        }

        return { hours: newHours, minutes: newMinutes, seconds: newSeconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (hours: number, minutes: number, seconds: number) => {
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.premiumBadge}>
          <Text style={styles.premiumText}>Seja Premium</Text>
        </View>
        <Text style={styles.headerTitle}>Diariamente</Text>
        <View style={styles.headerRight}>
          <ChevronDown size={20} color="#10B981" />
        </View>
      </View>

      {/* Week Calendar */}
      <View style={styles.weekContainer}>
        <View style={styles.weekRow}>
          {currentMonth.map((day, index) => (
            <View key={index} style={styles.dayContainer}>
              <Text style={[
                styles.dayLabel,
                day.isToday && styles.todayLabel
              ]}>
                {day.isToday ? 'Hoje' : day.day}
              </Text>
              <View style={[
                styles.dateContainer,
                day.isToday && styles.todayContainer
              ]}>
                <Text style={[
                  styles.dateText,
                  day.isToday && styles.todayText
                ]}>
                  {day.date}
                </Text>
              </View>
              {day.hasProgress && (
                <View style={styles.progressIndicator} />
              )}
            </View>
          ))}
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Food Diary Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleContainer}>
              <Utensils size={20} color="#F59E0B" />
              <Text style={styles.cardTitle}>Diário alimentar</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </View>
          
          <View style={styles.caloriesContainer}>
            <View style={styles.caloriesCircleContainer}>
              <View style={styles.caloriesCircleOuter}>
                <View style={[styles.caloriesCircleFill, { 
                  transform: [{ rotate: `${(calories / 2340) * 360}deg` }]
                }]} />
                <View style={styles.caloriesCircleInner}>
                  <Text style={styles.caloriesNumber}>{calories}</Text>
                  <Text style={styles.caloriesLabel}>kcal restantes</Text>
                </View>
              </View>
            </View>
            
            <View style={styles.macrosContainer}>
              <View style={styles.macroRow}>
                <View style={styles.macroHeader}>
                  <Crown size={12} color="#F59E0B" />
                  <Text style={styles.macroLabel}>Carboidratos</Text>
                </View>
                <View style={styles.progressBarContainer}>
                  <View style={styles.progressBarBackground}>
                    <View style={[styles.progressBarFill, { width: '18%', backgroundColor: '#F59E0B' }]} />
                  </View>
                </View>
              </View>
              <View style={styles.macroRow}>
                <View style={styles.macroHeader}>
                  <Crown size={12} color="#F59E0B" />
                  <Text style={styles.macroLabel}>Proteína</Text>
                </View>
                <View style={styles.progressBarContainer}>
                  <View style={styles.progressBarBackground}>
                    <View style={[styles.progressBarFill, { width: '21%', backgroundColor: '#F59E0B' }]} />
                  </View>
                </View>
              </View>
              <View style={styles.macroRow}>
                <View style={styles.macroHeader}>
                  <Crown size={12} color="#F59E0B" />
                  <Text style={styles.macroLabel}>Gordura</Text>
                </View>
                <View style={styles.progressBarContainer}>
                  <View style={styles.progressBarBackground}>
                    <View style={[styles.progressBarFill, { width: '15%', backgroundColor: '#F59E0B' }]} />
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Fasting Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleContainer}>
              <View style={styles.fastingIcon}>
                <Moon size={16} color="#10B981" />
              </View>
              <Text style={styles.cardTitle}>Jejum</Text>
            </View>
            <View style={styles.fastingProgress}>
              <Text style={styles.progressPercentage}>{fastingProgress}%</Text>
              <ChevronRight size={20} color="#9CA3AF" />
            </View>
          </View>
          
          <View style={styles.fastingContent}>
            <Text style={styles.fastingSubtitle}>Tempo decorrido</Text>
            <Text style={styles.fastingTimer}>
              {formatTime(fastingTime.hours, fastingTime.minutes, fastingTime.seconds)}
            </Text>
          </View>
        </View>

        {/* Challenge Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleContainer}>
              <Trophy size={20} color="#F59E0B" />
              <Text style={styles.cardTitle}>Desafio</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </View>
          
          <View style={styles.challengeContent}>
            <View style={styles.challengeBadge}>
              <Text style={styles.challengeDays}>14D</Text>
              <Text style={styles.challengeHours}>100h</Text>
            </View>
            <View style={styles.challengeDetails}>
              <Text style={styles.challengeTitle}>Jejum de 100 Horas em</Text>
              <Text style={styles.challengeSubtitle}>2 Semanas</Text>
              <Text style={styles.challengeProgress}>0/100 horas</Text>
            </View>
          </View>
        </View>

        {/* Water Card */}
        <View style={styles.waterCardContainer}>
          <View style={[styles.activityCard, styles.waterCard]}>
            <View style={styles.activityHeader}>
              <Droplets size={20} color="#3B82F6" />
              <Text style={styles.activityTitle}>Beber</Text>
              <ChevronRight size={16} color="#9CA3AF" />
            </View>
            <Text style={styles.activityValue}>{waterIntake} / 2000 ml</Text>
            <View style={styles.waterProgress}>
              <View style={[styles.waterBar, { width: `${(waterIntake / 2000) * 100}%` }]} />
            </View>
          </View>
        </View>

        {/* Weight Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleContainer}>
              <Scale size={20} color="#F59E0B" />
              <Text style={styles.cardTitle}>Peso</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </View>
          
          <View style={styles.weightContent}>
            <Text style={styles.weightDescription}>
              Insira seu peso para nos ajudar a acompanhar melhor sua saúde.
            </Text>
            <TouchableOpacity style={styles.weightButton}>
              <Text style={styles.weightButtonText}>Acompanhar agora</Text>
            </TouchableOpacity>
            
            {/* Measurements Card inside Weight Card */}
            <View style={styles.measurementsCard}>
              <View style={styles.measurementsHeader}>
                <View style={styles.measurementsIconContainer}>
                  <Ruler size={16} color="#F59E0B" />
                </View>
                <Text style={styles.measurementsTitle}>Busto / Cintura / Quadril / ...</Text>
                <ChevronRight size={20} color="#9CA3AF" />
              </View>
            </View>
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  premiumBadge: {
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  premiumText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  headerRight: {
    width: 24,
    alignItems: 'center',
  },
  weekContainer: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  weekRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  dayContainer: {
    alignItems: 'center',
    minWidth: 40,
  },
  dayLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 8,
    fontWeight: '500',
  },
  todayLabel: {
    color: '#000',
    fontWeight: '600',
  },
  dateContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  todayContainer: {
    backgroundColor: '#000',
  },
  dateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  todayText: {
    color: '#FFFFFF',
  },
  progressIndicator: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#10B981',
    marginTop: 4,
  },
  scrollView: {
    flex: 1,
  },
  card: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
  },
  caloriesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  caloriesCircleContainer: {
    width: 120,
    height: 120,
  },
  caloriesCircleOuter: {
    width: 120,
    height: 120,
    borderRadius: 60,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  caloriesCircleFill: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 6,
    borderColor: '#F3F4F6',
    borderTopColor: '#F59E0B',
    borderRightColor: '#F59E0B',
    borderBottomColor: '#F3F4F6',
    borderLeftColor: '#F3F4F6',
    transformOrigin: 'center',
    backgroundColor: 'transparent',
  },
  caloriesCircleInner: {
    width: 108,
    height: 108,
    borderRadius: 54,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
  },
  caloriesNumber: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1F2937',
  },
  caloriesLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  macrosContainer: {
    flex: 1,
    gap: 16,
  },
  macroRow: {
    flexDirection: 'column',
    gap: 4,
  },
  macroHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  
  macroLabel: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
    flex: 1,
  },
  progressBarContainer: {
    width: '100%',
    marginTop: 2,
  },
  progressBarBackground: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  fastingIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fastingProgress: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  progressPercentage: {
    fontSize: 14,
    fontWeight: '600',
    color: '#EF4444',
  },
  fastingContent: {
    alignItems: 'center',
  },
  fastingSubtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 8,
  },
  fastingTimer: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1F2937',
  },
  challengeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  challengeBadge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#F59E0B',
    alignItems: 'center',
    justifyContent: 'center',
  },
  challengeDays: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  challengeHours: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  challengeDetails: {
    flex: 1,
  },
  challengeTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  challengeSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  challengeProgress: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
  },
  waterCardContainer: {
    marginHorizontal: 16,
    marginVertical: 8,
  },
  activityCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  waterCard: {
    backgroundColor: '#EFF6FF',
  },
  
  activityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 12,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
    flex: 1,
  },
  activityValue: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 8,
  },
  waterProgress: {
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
  },
  waterBar: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 2,
  },
  
  weightContent: {
    alignItems: 'center',
  },
  weightDescription: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 20,
  },
  weightButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 32,
  },
  weightButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  bottomPadding: {
    height: 40,
  },
  measurementsCard: {
    backgroundColor: '#FEF3E2',
    marginTop: 16,
    borderRadius: 16,
    padding: 16,
  },
  measurementsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  measurementsIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  measurementsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F59E0B',
    flex: 1,
  },
});
