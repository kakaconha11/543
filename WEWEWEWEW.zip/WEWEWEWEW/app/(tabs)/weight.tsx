import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Dimensions,
  Modal,
  TextInput,
} from 'react-native';
import { ChevronLeft, ChevronRight, Settings, Edit3, RotateCcw, X } from 'lucide-react-native';

const { width } = Dimensions.get('window');

// Function to determine BMI category and color
const getBMICategory = (bmi: number): string => {
  if (bmi < 15.0) return 'Severamente abaixo do peso';
  if (bmi < 16.0) return 'Muito abaixo do peso';
  if (bmi < 18.5) return 'Abaixo do peso';
  if (bmi < 25.0) return 'Saudável';
  if (bmi < 30.0) return 'Sobrepeso';
  if (bmi < 35.0) return 'Obesidade moderada';
  if (bmi < 40.0) return 'Obesidade alta';
  return 'Obesidade muito alta';
};

// Function to get BMI category color
const getBMICategoryColor = (bmi: number): string => {
  if (bmi < 15.0) return '#3B82F6'; // Severamente abaixo do peso
  if (bmi < 16.0) return '#06B6D4'; // Muito abaixo do peso
  if (bmi < 18.5) return '#06B6D4'; // Abaixo do peso
  if (bmi < 25.0) return '#22C55E'; // Saudável
  if (bmi < 30.0) return '#EAB308'; // Sobrepeso
  if (bmi < 35.0) return '#F97316'; // Obesidade moderada
  if (bmi < 40.0) return '#EF4444'; // Obesidade alta
  return '#DC2626'; // Obesidade muito alta
};


// Function to get BMI indicator position percentage
const getBMIPosition = (bmi: number): number => {
  if (bmi < 15) return 0;
  if (bmi < 16) return 12.5;
  if (bmi < 18.5) return 25;
  if (bmi < 25) return 37.5;
  if (bmi < 30) return 50;
  if (bmi < 35) return 62.5;
  if (bmi < 40) return 75;
  return 87.5;
};

// Array of motivational messages
const motivationalMessages = [
  'Roma não foi construída em um dia.\nContinue e você verá resultados!',
  'Cada pequeno passo conta.\nVocê está no caminho certo!',
  'Seja paciente consigo mesmo.\nO progresso leva tempo!',
  'Consistência é a chave do sucesso.\nContinue firme!',
  'Seus esforços de hoje são\nos resultados de amanhã!',
  'Acredite no processo.\nVocê é mais forte do que imagina!',
  'Grandes mudanças começam\ncom pequenas ações!',
  'Não desista agora.\nVocê já chegou longe demais!',
  'O importante não é a velocidade,\nmas a constância!',
  'Cada dia é uma nova\noportunidade de crescer!'
];

// Function to get random motivational message
const getRandomMotivationalMessage = () => {
  const randomIndex = Math.floor(Math.random() * motivationalMessages.length);
  return motivationalMessages[randomIndex];
};

// Measurement definitions for different genders
const femaleMeasurements = [
  { key: 'bust', label: 'Busto', color: '#F97316' },
  { key: 'waist', label: 'Cintura', color: '#3B82F6' },
  { key: 'hips', label: 'Quadril', color: '#EF4444' },
  { key: 'thigh', label: 'Coxa', color: '#8B5CF6' },
  { key: 'arm', label: 'Braço', color: '#22C55E' },
  { key: 'neck', label: 'Pescoço', color: '#F59E0B' },
];

const maleMeasurements = [
  { key: 'chest', label: 'Peitoral', color: '#F97316' },
  { key: 'waist', label: 'Cintura', color: '#3B82F6' },
  { key: 'shoulders', label: 'Ombros', color: '#EF4444' },
  { key: 'thigh', label: 'Coxa', color: '#8B5CF6' },
  { key: 'arm', label: 'Braço', color: '#22C55E' },
  { key: 'neck', label: 'Pescoço', color: '#F59E0B' },
];

// Function to get measurements based on gender
const getMeasurementsForGender = (gender: 'male' | 'female') => {
  return gender === 'female' ? femaleMeasurements : maleMeasurements;
};

// Measurement guides
const measurementGuides = {
  female: {
    bust: 'Meça ao redor da parte mais larga do busto, mantendo a fita paralela ao chão.',
    waist: 'Meça na parte mais estreita do torso, geralmente acima do umbigo.',
    hips: 'Meça na parte mais larga dos quadris, ao redor das nádegas.',
    thigh: 'Meça na parte mais larga da coxa, logo abaixo da virilha.',
    arm: 'Meça na parte mais larga do braço, com o músculo relaxado.',
    neck: 'Meça ao redor da base do pescoço, logo abaixo da maçã de Adão.'
  },
  male: {
    chest: 'Meça ao redor da parte mais larga do peitoral, mantendo a fita paralela ao chão.',
    waist: 'Meça na altura do umbigo, mantendo a fita paralela ao chão.',
    shoulders: 'Meça de uma extremidade do ombro à outra, passando pelas costas.',
    thigh: 'Meça na parte mais larga da coxa, logo abaixo da virilha.',
    arm: 'Meça na parte mais larga do braço, com o músculo flexionado.',
    neck: 'Meça ao redor da base do pescoço, logo abaixo da maçã de Adão.'
  }
};

export default function WeightScreen() {
  const [selectedTab, setSelectedTab] = useState<'peso' | 'medicao'>('peso');
  const [selectedPeriod, setSelectedPeriod] = useState<'Dia' | 'Semana' | 'Mês'>('Dia');
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [showBMIModal, setShowBMIModal] = useState(false);
  const [unitSystem, setUnitSystem] = useState<'metric' | 'imperial'>('metric');
  const [weightInput, setWeightInput] = useState('');
  const [heightInput, setHeightInput] = useState('');
  const [heightFeet, setHeightFeet] = useState('');
  const [heightInches, setHeightInches] = useState('');
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalWeightInput, setGoalWeightInput] = useState('');
  const [goalUnitSystem, setGoalUnitSystem] = useState<'metric' | 'imperial'>('metric');
  const [savedGoalWeight, setSavedGoalWeight] = useState('');
  const [savedGoalUnit, setSavedGoalUnit] = useState<'metric' | 'imperial'>('metric');
  const [currentWeight, setCurrentWeight] = useState(''); // State to track if weight is entered
  const [currentHeight, setCurrentHeight] = useState('');
  const [currentWeightUnit, setCurrentWeightUnit] = useState<'metric' | 'imperial'>('metric');
  const [currentHeightUnit, setCurrentHeightUnit] = useState<'metric' | 'imperial'>('metric');
  const [calculatedBMI, setCalculatedBMI] = useState<number | null>(null);
  
  // New measurement states
  const [selectedGender, setSelectedGender] = useState<'male' | 'female'>('female');
  const [showMeasurementModal, setShowMeasurementModal] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [selectedMeasurement, setSelectedMeasurement] = useState<string | null>(null);
  const [measurementInput, setMeasurementInput] = useState('');
  const [measurements, setMeasurements] = useState<{[key: string]: string}>({});
  const [selectedChartPeriod, setSelectedChartPeriod] = useState<'Quinzena' | 'Mês' | 'Ano'>('Mês');
  const [measurementDate, setMeasurementDate] = useState(new Date().toISOString().split('T')[0]);
  const [measurementHistory, setMeasurementHistory] = useState<{
    [key: string]: { value: string; date: string; id: string }[]
  }>({});
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [selectedMeasurementForHistory, setSelectedMeasurementForHistory] = useState<string | null>(null);
  const [showDatePickerModal, setShowDatePickerModal] = useState(false);
  const [editingHistoryId, setEditingHistoryId] = useState<string | null>(null);
  const [measurementUnitSystem, setMeasurementUnitSystem] = useState<'metric' | 'imperial'>('metric');
  const [savedEvaluations, setSavedEvaluations] = useState<{
    id: string;
    date: string;
    measurements: {[key: string]: string};
    gender: 'male' | 'female';
  }[]>([]);

  const weightData = [
    { day: 28, weight: null },
    { day: 29, weight: null },
    { day: 30, weight: null },
    { day: 31, weight: null },
    { day: 1, weight: null },
    { day: 2, weight: null },
    { day: 3, weight: null },
  ];

  const handleSaveGoalWeight = () => {
    if (goalWeightInput.trim()) {
      setSavedGoalWeight(goalWeightInput);
      setSavedGoalUnit(goalUnitSystem);
      setShowGoalModal(false);
      setGoalWeightInput('');
    }
  };

  const handleSaveMeasurement = () => {
    if (measurementInput.trim() && selectedMeasurement && measurementDate) {
      const measurementId = editingHistoryId || Date.now().toString();
      
      // Convert measurement to cm for storage (if imperial)
      let valueInCm = measurementInput;
      if (measurementUnitSystem === 'imperial') {
        const inches = parseFloat(measurementInput);
        valueInCm = (inches * 2.54).toFixed(1); // Convert inches to cm
      }
      
      // Update current measurement display (store in cm)
      setMeasurements(prev => ({
        ...prev,
        [selectedMeasurement]: valueInCm
      }));

      // Add to history (store in cm)
      setMeasurementHistory(prev => {
        const currentHistory = prev[selectedMeasurement] || [];
        let updatedHistory;
        
        if (editingHistoryId) {
          // Update existing measurement
          updatedHistory = currentHistory.map(item => 
            item.id === editingHistoryId 
              ? { ...item, value: valueInCm, date: measurementDate }
              : item
          );
        } else {
          // Add new measurement
          updatedHistory = [...currentHistory, {
            value: valueInCm,
            date: measurementDate,
            id: measurementId
          }].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        }

        return {
          ...prev,
          [selectedMeasurement]: updatedHistory
        };
      });

      setShowMeasurementModal(false);
      setMeasurementInput('');
      setSelectedMeasurement(null);
      setEditingHistoryId(null);
      setMeasurementDate(new Date().toISOString().split('T')[0]);
    } else {
      alert('Por favor, preencha todos os campos.');
    }
  };

  const handleDeleteMeasurement = (measurementKey: string, measurementId: string) => {
    setMeasurementHistory(prev => {
      const currentHistory = prev[measurementKey] || [];
      const updatedHistory = currentHistory.filter(item => item.id !== measurementId);
      
      // Update current measurement display with the latest measurement
      if (updatedHistory.length > 0) {
        setMeasurements(prevMeasurements => ({
          ...prevMeasurements,
          [measurementKey]: updatedHistory[0].value
        }));
      } else {
        setMeasurements(prevMeasurements => {
          const newMeasurements = { ...prevMeasurements };
          delete newMeasurements[measurementKey];
          return newMeasurements;
        });
      }
      
      return {
        ...prev,
        [measurementKey]: updatedHistory
      };
    });
  };

  const handleSaveEvaluation = () => {
    if (Object.keys(measurements).length === 0) {
      alert('Adicione pelo menos uma medida antes de salvar a avaliação.');
      return;
    }

    const evaluationId = Date.now().toString();
    const newEvaluation = {
      id: evaluationId,
      date: new Date().toISOString(),
      measurements: { ...measurements },
      gender: selectedGender
    };

    // Add to saved evaluations
    setSavedEvaluations(prev => [newEvaluation, ...prev]);

    // Clear current measurements for new evaluation
    setMeasurements({});
    
    alert('Avaliação salva com sucesso! Pronta para nova avaliação.');
  };

  const handleEditMeasurement = (measurementKey: string, measurementId: string) => {
    const history = measurementHistory[measurementKey] || [];
    const measurementToEdit = history.find(item => item.id === measurementId);
    
    if (measurementToEdit) {
      setSelectedMeasurement(measurementKey);
      setMeasurementInput(measurementToEdit.value);
      setMeasurementDate(measurementToEdit.date);
      setEditingHistoryId(measurementId);
      setShowHistoryModal(false);
      setShowMeasurementModal(true);
    }
  };

  // Calculate progress percentage for meta bar
  const calculateMetaProgress = () => {
    if (!currentWeight || !savedGoalWeight) return 0;

    const currentWeightNum = parseFloat(currentWeight);
    const goalWeightNum = parseFloat(savedGoalWeight);

    // Convert to same units for comparison
    let currentInKg = currentWeightNum;
    let goalInKg = goalWeightNum;

    if (currentWeightUnit === 'imperial') {
      currentInKg = currentWeightNum * 0.453592;
    }
    if (savedGoalUnit === 'imperial') {
      goalInKg = goalWeightNum * 0.453592;
    }

    // Use current weight as initial weight for now
    // This will be the starting point (0% progress)
    const initialWeight = currentInKg;
    
    // Calculate the total distance from initial to goal
    const totalDistance = Math.abs(goalInKg - initialWeight);
    
    // If no distance (same weight), return 0
    if (totalDistance === 0) return 0;
    
    // Calculate how much progress has been made
    // For weight loss: progress = (initial - current) / (initial - goal)
    // For weight gain: progress = (current - initial) / (goal - initial)
    let progress = 0;
    
    if (goalInKg < initialWeight) {
      // Weight loss goal
      progress = ((initialWeight - currentInKg) / (initialWeight - goalInKg)) * 100;
    } else if (goalInKg > initialWeight) {
      // Weight gain goal
      progress = ((currentInKg - initialWeight) / (goalInKg - initialWeight)) * 100;
    }
    
    // Ensure progress is between 0 and 100
    return Math.min(Math.max(0, progress), 100);
  };

  const handleExcluir = () => {
    setWeightInput('');
    setHeightInput('');
    setHeightFeet('');
    setHeightInches('');
    setCurrentWeight(''); // Reset current weight to trigger button text change
    setCurrentHeight('');
    setCalculatedBMI(null);
    setShowWeightModal(false);
  };

  const handleSaveWeight = () => {
    // Basic validation
    if (weightInput.trim() && (unitSystem === 'metric' ? heightInput.trim() : (heightFeet.trim() && heightInches.trim()))) {

      // Store current values with their units
      setCurrentWeight(weightInput);
      setCurrentWeightUnit(unitSystem);
      setCurrentHeightUnit(unitSystem);

      // Calculate height in cm for BMI calculation
      let heightInCm: number;
      if (unitSystem === 'metric') {
        heightInCm = parseFloat(heightInput.replace(',', '.'));
        setCurrentHeight(heightInput);
      } else {
        const feet = parseFloat(heightFeet);
        const inches = parseFloat(heightInches);
        heightInCm = (feet * 12 + inches) * 2.54; // Convert to cm
        setCurrentHeight(`${heightFeet}'${heightInches}"`);
      }

      // Calculate weight in kg for BMI calculation
      let weightInKg: number;
      if (unitSystem === 'metric') {
        weightInKg = parseFloat(weightInput.replace(',', '.'));
      } else {
        weightInKg = parseFloat(weightInput.replace(',', '.')) * 0.453592; // Convert lb to kg
      }

      // Calculate BMI
      if (heightInCm > 0 && weightInKg > 0) {
        const heightInM = heightInCm / 100;
        const bmi = weightInKg / (heightInM * heightInM);
        setCalculatedBMI(bmi);
      }

      setShowWeightModal(false);
    } else {
      alert('Por favor, preencha todos os campos.');
    }
  };

  const bmiCategories = [
    {
      name: 'Severamente abaixo do peso',
      range: '< 15.0',
      color: '#3B82F6',
      isActive: false
    },
    {
      name: 'Muito abaixo do peso',
      range: '15.0 - 15.9',
      color: '#06B6D4',
      isActive: false
    },
    {
      name: 'Abaixo do peso',
      range: '16.0 - 18.4',
      color: '#10B981',
      isActive: true
    },
    {
      name: 'Saudável',
      range: '18.5 - 24.9',
      color: '#10B981',
      isActive: false
    },
    {
      name: 'Sobrepeso',
      range: '25.0 - 29.9',
      color: '#EAB308',
      isActive: false
    },
    {
      name: 'Obesidade moderada',
      range: '30.0 - 34.9',
      color: '#F97316',
      isActive: false
    },
    {
      name: 'Obesidade alta',
      range: '35.0 - 39.9',
      color: '#EF4444',
      isActive: false
    },
    {
      name: 'Obesidade muito alta',
      range: '≥ 40.0',
      color: '#DC2626',
      isActive: false
    }
  ];

  const renderBMIIndicator = () => {
    const colors = ['#3B82F6', '#06B6D4', '#06B6D4', '#22C55E', '#EAB308', '#F97316', '#EF4444', '#DC2626'];

    return (
      <View style={styles.bmiIndicatorContainer}>
        <View style={[styles.bmiIndicator, { left: `${calculatedBMI ? getBMIPosition(calculatedBMI) : 15}%` }]}>
          <View style={styles.bmiTriangle} />
        </View>
        <View style={styles.bmiColorBar}>
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[0], flex: 1 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[1], flex: 1 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[2], flex: 2 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[3], flex: 6 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[4], flex: 5 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[5], flex: 5 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[6], flex: 5 }]} />
          <View style={[styles.bmiColorSegment, { backgroundColor: colors[7], flex: 3 }]} />
        </View>
        <View style={styles.bmiLabels}>
          <Text style={styles.bmiLabel}>15</Text>
          <Text style={styles.bmiLabel}>16</Text>
          <Text style={styles.bmiLabel}>18.5</Text>
          <Text style={styles.bmiLabel}>25</Text>
          <Text style={styles.bmiLabel}>30</Text>
          <Text style={styles.bmiLabel}>35</Text>
          <Text style={styles.bmiLabel}>40</Text>
        </View>
      </View>
    );
  };

  const renderCalendar = () => {
    const today = new Date();
    const currentDate = today.getDate();
    
    // Get current week days starting from Monday
    const currentDay = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const mondayOffset = currentDay === 0 ? -6 : 1 - currentDay; // Adjust to start from Monday
    const weekDays = [];
    
    // Calculate days of current week (Monday to Sunday)
    for (let i = 0; i < 7; i++) {
      const dayDate = new Date(today);
      dayDate.setDate(today.getDate() + mondayOffset + i);
      weekDays.push({
        day: dayDate.getDate(),
        isToday: dayDate.getDate() === currentDate && dayDate.getMonth() === today.getMonth()
      });
    }

    const dayNames = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
    
    // Find today's position and update day names accordingly
    const todayIndex = weekDays.findIndex(day => day.isToday);
    if (todayIndex !== -1) {
      dayNames[todayIndex] = 'Hoje';
    }

    return (
      <View style={styles.calendarContainer}>
        {/* Day headers */}
        <View style={styles.dayHeadersRow}>
          {dayNames.map((dayName, index) => (
            <Text key={index} style={[
              styles.dayHeader,
              dayName === 'Hoje' && styles.todayHeader
            ]}>
              {dayName}
            </Text>
          ))}
        </View>

        {/* Calendar week */}
        <View style={styles.calendarWeek}>
          {weekDays.map((dayData, index) => (
            <View key={index} style={styles.calendarDay}>
              <View style={[
                styles.dayCircle,
                dayData.isToday && styles.todayCircle
              ]}>
                <Text style={[
                  styles.dayText,
                  dayData.isToday && styles.todayText
                ]}>
                  {dayData.day}
                </Text>
              </View>
              {dayData.isToday && (
                <View style={styles.todayIndicator} />
              )}
            </View>
          ))}
        </View>
      </View>
    );
  };

  const renderCurrentWeight = () => {
    return (
      <View style={styles.currentWeightContainer}>
        <View style={styles.weightDisplayLarge}>
          <Text style={styles.weightValueLarge}>0.0</Text>
          <Text style={styles.weightUnitLarge}>kg</Text>
        </View>
        <Text style={styles.weightStatusText}>Peso atual</Text>
      </View>
    );
  };

  const renderPesoTab = () => (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      {/* Mais recente section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Mais recente</Text>

        <View style={styles.currentWeightSection}>
          <Text style={styles.currentWeightValue}>
            {currentWeight ? `${currentWeight} ` : '0.0 '}
            <Text style={styles.currentWeightUnit}>
              {currentWeight ? (currentWeightUnit === 'metric' ? 'kg' : 'lb') : 'kg'}
            </Text>
          </Text>
        </View>

        <Text style={styles.weightMessage}>
          {getRandomMotivationalMessage()}
        </Text>

        <TouchableOpacity
          style={styles.updateButton}
          onPress={() => setShowWeightModal(true)}
        >
          <Text style={styles.updateButtonText}>
            {currentWeight ? 'Atualizar' : 'Acompanhar agora'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Meta section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Meta</Text>
          <TouchableOpacity onPress={() => setShowGoalModal(true)}>
            <Edit3 size={20} color="#F59E0B" />
          </TouchableOpacity>
        </View>

        <View style={styles.metaProgressContainer}>
          <View style={styles.metaProgressBar}>
            <View style={[styles.metaProgress, { width: `${calculateMetaProgress()}%` }]} />
          </View>
        </View>

        <View style={styles.metaIndicator}>
          <View style={styles.metaBadge}>
            <Text style={styles.metaBadgeText}>
              {savedGoalWeight ? `${savedGoalWeight} ${savedGoalUnit === 'metric' ? 'kg' : 'lb'}` : '-- kg'}
            </Text>
          </View>
        </View>

        <View style={styles.metaLabels}>
          <View style={styles.metaItem}>
            <Text style={styles.metaValue}>
              {currentWeight ? `${currentWeight} ${currentWeightUnit === 'metric' ? 'kg' : 'lb'}` : '0.0 kg'}
            </Text>
            <Text style={styles.metaLabel}>Inicial</Text>
          </View>
          <ChevronRight size={20} color="#F59E0B" />
          <View style={styles.metaItem}>
            <Text style={styles.metaValue}>
              {savedGoalWeight ? `${savedGoalWeight} ${savedGoalUnit === 'metric' ? 'kg' : 'lb'}` : '-- kg'}
            </Text>
            <Text style={styles.metaLabel}>Meta</Text>
          </View>
        </View>
      </View>

      {/* IMC section */}
      <TouchableOpacity
        style={styles.section}
        onPress={() => setShowBMIModal(true)}
      >
        <View style={styles.imcHeader}>
          <Text style={styles.imcTitle}>IMC(kg/m²)</Text>
          <ChevronRight size={20} color="#9CA3AF" />
        </View>

        <View style={styles.imcContent}>
          <View style={styles.imcValueContainer}>
            <Text style={styles.imcValue}>
              {calculatedBMI ? calculatedBMI.toFixed(1) : '0.0'}
            </Text>
            <Text style={[
              styles.imcCategory,
              { color: calculatedBMI ? getBMICategoryColor(calculatedBMI) : '#9CA3AF' }
            ]}>
              {calculatedBMI ? getBMICategory(calculatedBMI) : 'Sem dados'}
            </Text>
          </View>
        </View>

        {renderBMIIndicator()}
      </TouchableOpacity>

      {/* Histórico section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Histórico</Text>
          <Text style={styles.monthLabel}>Dezembro</Text>
        </View>

        {/* Calendar */}
        {renderCalendar()}

        {/* Peso Atual Section */}
        <View style={styles.pesoHistorySection}>
          <Text style={styles.pesoHistoryTitle}>Medida do Peso</Text>
          <View style={styles.pesoMeasurementContainer}>
            <Text style={styles.pesoMeasurementValue}>
              {currentWeight ? `${currentWeight}` : '0.0'}
            </Text>
            <Text style={styles.pesoMeasurementUnit}>
              {currentWeight ? (currentWeightUnit === 'metric' ? 'kg' : 'lb') : 'kg'}
            </Text>
          </View>
          <Text style={styles.pesoMeasurementDate}>
            Última medição: {new Date().toLocaleDateString('pt-BR')}
          </Text>
        </View>
      </View>

      <View style={styles.bottomPadding} />
    </ScrollView>
  );

  const renderMedicaoTab = () => (
    <ScrollView style={styles.tabContent} showsVerticalScrollIndicator={false}>
      {/* Gender Selection */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Selecione o gênero</Text>
        <View style={styles.genderSelection}>
          <TouchableOpacity
            style={[
              styles.genderOption,
              selectedGender === 'female' && styles.genderOptionActive
            ]}
            onPress={() => setSelectedGender('female')}
          >
            <Text style={[
              styles.genderOptionText,
              selectedGender === 'female' && styles.genderOptionTextActive
            ]}>
              👩 Feminino
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.genderOption,
              selectedGender === 'male' && styles.genderOptionActive
            ]}
            onPress={() => setSelectedGender('male')}
          >
            <Text style={[
              styles.genderOptionText,
              selectedGender === 'male' && styles.genderOptionTextActive
            ]}>
              👨 Masculino
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Measurements Overview */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Medidas Corporais</Text>
          <TouchableOpacity
            style={styles.addMeasurementButton}
            onPress={() => setShowMeasurementModal(true)}
          >
            <Text style={styles.addMeasurementButtonText}>Personalizar</Text>
          </TouchableOpacity>
        </View>

        {/* Calendar for Current Evaluation */}
        <View style={styles.evaluationCalendarContainer}>
          <Text style={styles.evaluationCalendarTitle}>Avaliação Atual</Text>
          {renderCalendar()}
        </View>

        {/* Current Measurements Grid */}
        <View style={styles.measurementsOverview}>
          {getMeasurementsForGender(selectedGender).map((measurement, index) => {
            const latestMeasurement = measurementHistory[measurement.key]?.[0];
            const hasHistory = measurementHistory[measurement.key]?.length > 0;
            
            // Convert cm to display unit
            const getDisplayValue = (valueInCm: string) => {
              if (!valueInCm) return '--';
              const cmValue = parseFloat(valueInCm);
              if (measurementUnitSystem === 'imperial') {
                const inches = (cmValue / 2.54).toFixed(1);
                return `${inches} in`;
              }
              return `${valueInCm} cm`;
            };
            
            return (
              <View key={index} style={styles.measurementCard}>
                <View style={styles.measurementCardHeader}>
                  <View style={[styles.measurementCardIndicator, { backgroundColor: measurement.color }]} />
                  <View style={styles.measurementCardActions}>
                    <TouchableOpacity
                      style={styles.measurementCardButton}
                      onPress={() => {
                        setSelectedMeasurement(measurement.key);
                        setMeasurementInput('');
                        setMeasurementDate(new Date().toISOString().split('T')[0]);
                        setEditingHistoryId(null);
                        setShowMeasurementModal(true);
                      }}
                    >
                      <Edit3 size={16} color="#F59E0B" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <Text style={styles.measurementCardLabel}>{measurement.label}</Text>
                <Text style={styles.measurementCardValue}>
                  {getDisplayValue(measurements[measurement.key])}
                </Text>
                
                {latestMeasurement && (
                  <Text style={styles.measurementCardDate}>
                    {new Date(latestMeasurement.date).toLocaleDateString('pt-BR')}
                  </Text>
                )}
              </View>
            );
          })}
        </View>

        {/* Save Evaluation Button */}
        <TouchableOpacity 
          style={styles.saveEvaluationButton}
          onPress={handleSaveEvaluation}
        >
          <Text style={styles.saveEvaluationButtonText}>Salvar Avaliação</Text>
        </TouchableOpacity>
      </View>

      {/* Progress Chart */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Progresso</Text>

        {/* Chart Period Selector */}
        <View style={styles.chartPeriodSelectorContainer}>
          <View style={styles.chartPeriodSelector}>
            {['Quinzena', 'Mês', 'Ano'].map((period) => (
              <TouchableOpacity
                key={period}
                style={[
                  styles.chartPeriodButton,
                  selectedChartPeriod === period && styles.chartPeriodButtonActive
                ]}
                onPress={() => setSelectedChartPeriod(period)}
              >
                <Text style={[
                  styles.chartPeriodButtonText,
                  selectedChartPeriod === period && styles.chartPeriodButtonTextActive
                ]}>
                  {period}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Chart Container */}
        <View style={styles.chartContainer}>
          <Text style={styles.chartTitle}>Evolução das Medidas - {selectedChartPeriod}</Text>
          <View style={styles.chartArea}>
            {/* Chart Grid Lines */}
            <View style={styles.chartGrid}>
              {[0, 1, 2, 3, 4].map((line) => (
                <View key={line} style={styles.chartGridLine} />
              ))}
            </View>
            
            {/* Chart Data Lines */}
            <View style={styles.chartDataContainer}>
              {getMeasurementsForGender(selectedGender).map((measurement, index) => (
                <View
                  key={index}
                  style={[
                    styles.chartLine,
                    { backgroundColor: measurement.color, left: `${10 + index * 20}%` }
                  ]}
                />
              ))}
            </View>
            
            {/* Chart Legend */}
            <View style={styles.chartLegend}>
              {getMeasurementsForGender(selectedGender).map((measurement, index) => (
                <View key={index} style={styles.chartLegendItem}>
                  <View style={[styles.chartLegendDot, { backgroundColor: measurement.color }]} />
                  <Text style={styles.chartLegendText}>{measurement.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      </View>

      {/* History Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Histórico</Text>
          <TouchableOpacity
            style={styles.historyButton}
            onPress={() => setShowHistoryModal(true)}
          >
            <Text style={styles.historyButtonText}>Ver Mais</Text>
          </TouchableOpacity>
        </View>

        {/* Saved Evaluations List */}
        <View style={styles.evaluationsList}>
          {savedEvaluations.length > 0 ? (
            savedEvaluations.slice(0, 3).map((evaluation) => (
              <View key={evaluation.id} style={styles.evaluationItem}>
                <View style={styles.evaluationItemHeader}>
                  <Text style={styles.evaluationItemDate}>
                    {new Date(evaluation.date).toLocaleDateString('pt-BR')}
                  </Text>
                  <Text style={styles.evaluationItemTime}>
                    {new Date(evaluation.date).toLocaleTimeString('pt-BR', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </Text>
                </View>
                <View style={styles.evaluationItemMeasurements}>
                  {Object.entries(evaluation.measurements).slice(0, 3).map(([key, value]) => {
                    const measurement = getMeasurementsForGender(selectedGender).find(m => m.key === key);
                    if (!measurement) return null;
                    
                    const displayValue = measurementUnitSystem === 'metric' 
                      ? `${value} cm`
                      : `${(parseFloat(value) / 2.54).toFixed(1)} in`;
                    
                    return (
                      <View key={key} style={styles.evaluationMeasurementItem}>
                        <View style={[styles.evaluationMeasurementDot, { backgroundColor: measurement.color }]} />
                        <Text style={styles.evaluationMeasurementText}>
                          {measurement.label}: {displayValue}
                        </Text>
                      </View>
                    );
                  })}
                  {Object.keys(evaluation.measurements).length > 3 && (
                    <Text style={styles.evaluationMoreText}>
                      +{Object.keys(evaluation.measurements).length - 3} mais...
                    </Text>
                  )}
                </View>
              </View>
            ))
          ) : (
            <View style={styles.historyEmpty}>
              <Text style={styles.historyEmptyText}>Nenhuma avaliação salva ainda</Text>
            </View>
          )}
        </View>
      </View>

      <View style={styles.bottomPadding} />
    </ScrollView>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Informações sobre o corpo</Text>
        <TouchableOpacity style={styles.settingsButton}>
          <Settings size={24} color="#9CA3AF" />
        </TouchableOpacity>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            selectedTab === 'peso' && styles.activeTab
          ]}
          onPress={() => setSelectedTab('peso')}
        >
          <Text style={[
            styles.tabText,
            selectedTab === 'peso' && styles.activeTabText
          ]}>
            Peso
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tab,
            selectedTab === 'medicao' && styles.activeTab
          ]}
          onPress={() => setSelectedTab('medicao')}
        >
          <Text style={[
            styles.tabText,
            selectedTab === 'medicao' && styles.activeTabText
          ]}>
            Medição
          </Text>
        </TouchableOpacity>
      </View>

      {/* Tab Content */}
      {selectedTab === 'peso' ? renderPesoTab() : renderMedicaoTab()}

      {/* Weight & Height Modal */}
      <Modal
        visible={showWeightModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowWeightModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.weightModal}>
            <View style={styles.weightModalHeader}>
              <Text style={styles.weightModalTitle}>Peso & Altura</Text>
              <TouchableOpacity
                onPress={() => setShowWeightModal(false)}
                style={styles.modalCloseButton}
              >
                <X size={24} color="#9CA3AF" />
              </TouchableOpacity>
            </View>

            <View style={styles.weightModalContent}>
              {/* Weight Input */}
              <View style={styles.weightInputSection}>
                <Text style={styles.weightInputLabel}>Peso :</Text>
                <View style={styles.weightInputContainer}>
                  <TextInput
                    style={styles.weightInputField}
                    value={weightInput}
                    onChangeText={setWeightInput}
                    keyboardType="numeric"
                    placeholder={unitSystem === 'metric' ? '65,0' : '143,3'}
                    placeholderTextColor="#06B6D4"
                  />
                  <Text style={styles.weightUnit}>
                    {unitSystem === 'metric' ? 'kg' : 'lb'}
                  </Text>
                </View>
              </View>

              {/* Height Input */}
              <View style={styles.heightInputSection}>
                <Text style={styles.heightInputLabel}>Altura :</Text>
                <View style={styles.heightInputContainer}>
                  {unitSystem === 'metric' ? (
                    <>
                      <TextInput
                        style={styles.heightInputField}
                        value={heightInput}
                        onChangeText={setHeightInput}
                        keyboardType="numeric"
                        placeholder="180,3"
                        placeholderTextColor="#06B6D4"
                      />
                      <Text style={styles.heightUnit}>cm</Text>
                    </>
                  ) : (
                    <>
                      <TextInput
                        style={styles.heightInputFieldFeet}
                        value={heightFeet}
                        onChangeText={setHeightFeet}
                        keyboardType="numeric"
                        placeholder="5"
                        placeholderTextColor="#06B6D4"
                      />
                      <Text style={styles.heightUnitFeet}>ft</Text>
                      <TextInput
                        style={styles.heightInputFieldInches}
                        value={heightInches}
                        onChangeText={setHeightInches}
                        keyboardType="numeric"
                        placeholder="11"
                        placeholderTextColor="#06B6D4"
                      />
                      <Text style={styles.heightUnitInches}>in</Text>
                    </>
                  )}
                </View>
              </View>

              {/* Unit System Toggle */}
              <View style={styles.unitToggleContainer}>
                <TouchableOpacity
                  style={[
                    styles.unitToggle,
                    styles.unitToggleLeft,
                    unitSystem === 'metric' && styles.unitToggleActive
                  ]}
                  onPress={() => setUnitSystem('metric')}
                >
                  <Text style={[
                    styles.unitToggleText,
                    unitSystem === 'metric' && styles.unitToggleTextActive
                  ]}>
                    cm/kg
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.unitToggle,
                    styles.unitToggleRight,
                    unitSystem === 'imperial' && styles.unitToggleActive
                  ]}
                  onPress={() => setUnitSystem('imperial')}
                >
                  <Text style={[
                    styles.unitToggleText,
                    unitSystem === 'imperial' && styles.unitToggleTextActive
                  ]}>
                    ft/lb
                  </Text>
                </TouchableOpacity>
              </View>

              {/* Action Buttons */}
              <View style={styles.modalActionButtons}>
                <TouchableOpacity style={styles.deleteWeightButton} onPress={handleExcluir}>
                  <Text style={styles.deleteWeightButtonText}>Excluir</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.saveWeightButton} onPress={handleSaveWeight}>
                  <Text style={styles.saveWeightButtonText}>Salvar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>

      {/* BMI Categories Modal */}
      <Modal
        visible={showBMIModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowBMIModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.bmiModal}>
            {/* Header */}
            <View style={styles.bmiModalHeader}>
              <TouchableOpacity
                onPress={() => setShowBMIModal(false)}
                style={styles.modalBackButton}
              >
                <ChevronLeft size={24} color="#000" />
              </TouchableOpacity>
              <Text style={styles.bmiModalTitle}>BMI</Text>
              <View style={styles.modalSpacer} />
            </View>

            <ScrollView style={styles.bmiModalContent} showsVerticalScrollIndicator={false}>
              {/* Current BMI */}
              <View style={styles.currentBMISection}>
                <Text style={styles.currentBMILabel}>Seu IMC é :</Text>
                <View style={styles.currentBMIContainer}>
                  <Text style={styles.currentBMIValue}>
                    {calculatedBMI ? calculatedBMI.toFixed(1) : '0.0'}
                  </Text>
                  <Text style={[
                    styles.currentBMICategory,
                    { color: calculatedBMI ? getBMICategoryColor(calculatedBMI) : '#F97316' }
                  ]}>
                    {calculatedBMI ? getBMICategory(calculatedBMI) : 'Sem dados'}
                  </Text>
                </View>

                {/* BMI Color Bar */}
                <View style={styles.bmiColorBar}>
                  {bmiCategories.map((category, index) => (
                    <View
                      key={index}
                      style={[
                        styles.bmiColorSegment,
                        { backgroundColor: category.color, flex: 1 }
                      ]}
                    />
                  ))}
                </View>
                <View style={styles.bmiLabels}>
                  <Text style={styles.bmiLabel}>15</Text>
                  <Text style={styles.bmiLabel}>16</Text>
                  <Text style={styles.bmiLabel}>18.5</Text>
                  <Text style={styles.bmiLabel}>25</Text>
                  <Text style={styles.bmiLabel}>30</Text>
                  <Text style={styles.bmiLabel}>35</Text>
                  <Text style={styles.bmiLabel}>40</Text>
                </View>
              </View>

              {/* Weight and Height Display */}
              <View style={styles.weightHeightDisplay}>
                <View style={styles.weightHeightItem}>
                  <Text style={styles.weightHeightLabel}>Peso</Text>
                  <Text style={styles.weightHeightValue}>
                    {currentWeight ? `${currentWeight} ` : '0.0 '}
                    <Text style={styles.weightHeightUnit}>
                      {currentWeight ? (currentWeightUnit === 'metric' ? 'kg' : 'lb') : 'kg'}
                    </Text>
                  </Text>
                </View>
                <View style={styles.weightHeightItem}>
                  <Text style={styles.weightHeightLabel}>Altura</Text>
                  <Text style={styles.weightHeightValue}>
                    {currentHeight ? `${currentHeight} ` : '0.0 '}
                    <Text style={styles.weightHeightUnit}>
                      {currentHeight ? (currentHeightUnit === 'metric' ? 'cm' : '') : 'cm'}
                    </Text>
                  </Text>
                </View>
              </View>

              {/* BMI Categories List */}
              <View style={styles.bmiCategoriesList}>
                {bmiCategories.map((category, index) => {
                  const isCurrentCategory = calculatedBMI ? getBMICategory(calculatedBMI) === category.name : false;
                  return (
                    <View
                      key={index}
                      style={[
                        styles.bmiCategoryItem,
                        isCurrentCategory && styles.activeBmiCategory
                      ]}
                    >
                      <View style={styles.bmiCategoryLeft}>
                        <View style={[styles.bmiCategoryDot, { backgroundColor: category.color }]} />
                        <Text style={[
                          styles.bmiCategoryName,
                          isCurrentCategory && styles.activeBmiCategoryText
                        ]}>
                          {category.name}
                        </Text>
                      </View>
                      <Text style={[
                        styles.bmiCategoryRange,
                        isCurrentCategory && styles.activeBmiCategoryText
                      ]}>
                        {category.range}
                      </Text>
                    </View>
                  );
                })}
              </View>

              {/* BMI Explanation */}
              <View style={styles.bmiExplanation}>
                <Text style={styles.bmiExplanationText}>
                  O índice de massa corporal (IMC) é uma medida que usa a sua altura e peso para determinar se você tem um peso saudável.
                </Text>
              </View>

              <View style={styles.bottomPadding} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Goal Weight Modal */}
      <Modal
        visible={showGoalModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowGoalModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.goalModal}>
            <View style={styles.goalModalHeader}>
              <Text style={styles.goalModalTitle}>Peso</Text>
              <TouchableOpacity
                onPress={() => setShowGoalModal(false)}
                style={styles.modalCloseButton}
              >
                <X size={24} color="#9CA3AF" />
              </TouchableOpacity>
            </View>

            <View style={styles.goalModalContent}>
              {/* Goal Weight Input */}
              <View style={styles.goalWeightInputSection}>
                <Text style={styles.goalInputLabel}>Peso Meta:</Text>
                <View style={styles.goalWeightInputContainer}>
                  <TextInput
                    style={styles.goalWeightInputField}
                    value={goalWeightInput}
                    onChangeText={setGoalWeightInput}
                    keyboardType="numeric"
                    placeholder={goalUnitSystem === 'metric' ? '85,0' : '187,39'}
                    placeholderTextColor="#1E40AF"
                  />
                  <Text style={styles.goalWeightInputUnit}>
                    {goalUnitSystem === 'metric' ? 'kg' : 'lb'}
                  </Text>
                </View>
              </View>

              {/* Unit System Toggle */}
              <View style={styles.goalUnitToggleContainer}>
                <TouchableOpacity
                  style={[
                    styles.goalUnitToggle,
                    styles.goalUnitToggleLeft,
                    goalUnitSystem === 'metric' && styles.goalUnitToggleActive
                  ]}
                  onPress={() => setGoalUnitSystem('metric')}
                >
                  <Text style={[
                    styles.goalUnitToggleText,
                    goalUnitSystem === 'metric' && styles.goalUnitToggleTextActive
                  ]}>
                    kg
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.goalUnitToggle,
                    styles.goalUnitToggleRight,
                    goalUnitSystem === 'imperial' && styles.goalUnitToggleActive
                  ]}
                  onPress={() => setGoalUnitSystem('imperial')}
                >
                  <Text style={[
                    styles.goalUnitToggleText,
                    goalUnitSystem === 'imperial' && styles.goalUnitToggleTextActive
                  ]}>
                    lb
                  </Text>
                </TouchableOpacity>
              </View>

              {/* Save Button */}
              <TouchableOpacity style={styles.saveGoalButton} onPress={handleSaveGoalWeight}>
                <Text style={styles.saveGoalButtonText}>Salvar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Measurement Input Modal */}
      <Modal
        visible={showMeasurementModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowMeasurementModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.measurementModal}>
            <View style={styles.measurementModalHeader}>
              <Text style={styles.measurementModalTitle}>
                {selectedMeasurement ? 
                  getMeasurementsForGender(selectedGender).find(m => m.key === selectedMeasurement)?.label || 'Medida'
                  : 'Nova Medida'
                }
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowMeasurementModal(false);
                  setSelectedMeasurement(null);
                  setMeasurementInput('');
                }}
                style={styles.modalCloseButton}
              >
                <X size={24} color="#9CA3AF" />
              </TouchableOpacity>
            </View>

            <View style={styles.measurementModalContent}>
              {!selectedMeasurement ? (
                // Measurement selection
                <View style={styles.measurementSelectionContainer}>
                  <Text style={styles.measurementSelectionTitle}>Selecione a medida:</Text>
                  <View style={styles.measurementSelectionGrid}>
                    {getMeasurementsForGender(selectedGender).map((measurement) => (
                      <TouchableOpacity
                        key={measurement.key}
                        style={styles.measurementSelectionItem}
                        onPress={() => {
                          setSelectedMeasurement(measurement.key);
                          setMeasurementInput(measurements[measurement.key] || '');
                        }}
                      >
                        <View style={[styles.measurementSelectionDot, { backgroundColor: measurement.color }]} />
                        <Text style={styles.measurementSelectionLabel}>{measurement.label}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  
                  {/* Create New Measurement Button */}
                  <TouchableOpacity 
                    style={styles.createNewMeasurementButton}
                    onPress={() => {
                      alert('Funcionalidade de criar nova medida será implementada em breve!');
                    }}
                  >
                    <Text style={styles.createNewMeasurementButtonText}>+ Criar Nova Medida</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                // Measurement input
                <View style={styles.measurementInputContainer}>
                  <Text style={styles.measurementInputLabel}>
                    {measurementGuides[selectedGender][selectedMeasurement as keyof typeof measurementGuides.female]}
                  </Text>
                  
                  <View style={styles.measurementInputSection}>
                    <TextInput
                      style={styles.measurementInputField}
                      value={measurementInput}
                      onChangeText={setMeasurementInput}
                      keyboardType="numeric"
                      placeholder="0.0"
                      placeholderTextColor="#3B82F6"
                    />
                    <Text style={styles.measurementUnit}>
                      {measurementUnitSystem === 'metric' ? 'cm' : 'in'}
                    </Text>
                  </View>

                  {/* Unit System Toggle */}
                  <View style={styles.measurementModalUnitToggle}>
                    <TouchableOpacity
                      style={[
                        styles.measurementUnitToggle,
                        styles.measurementUnitToggleLeft,
                        measurementUnitSystem === 'metric' && styles.measurementUnitToggleActive
                      ]}
                      onPress={() => {
                        // Convert current input when switching units
                        if (measurementInput && measurementUnitSystem === 'imperial') {
                          const inches = parseFloat(measurementInput);
                          const cm = (inches * 2.54).toFixed(1);
                          setMeasurementInput(cm);
                        }
                        setMeasurementUnitSystem('metric');
                      }}
                    >
                      <Text style={[
                        styles.measurementUnitToggleText,
                        measurementUnitSystem === 'metric' && styles.measurementUnitToggleTextActive
                      ]}>
                        cm
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[
                        styles.measurementUnitToggle,
                        styles.measurementUnitToggleRight,
                        measurementUnitSystem === 'imperial' && styles.measurementUnitToggleActive
                      ]}
                      onPress={() => {
                        // Convert current input when switching units
                        if (measurementInput && measurementUnitSystem === 'metric') {
                          const cm = parseFloat(measurementInput);
                          const inches = (cm / 2.54).toFixed(1);
                          setMeasurementInput(inches);
                        }
                        setMeasurementUnitSystem('imperial');
                      }}
                    >
                      <Text style={[
                        styles.measurementUnitToggleText,
                        measurementUnitSystem === 'imperial' && styles.measurementUnitToggleTextActive
                      ]}>
                        in
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    style={styles.howToMeasureModalButton}
                    onPress={() => {
                      setShowMeasurementModal(false);
                      setShowGuideModal(true);
                    }}
                  >
                    <Text style={styles.howToMeasureModalText}>Como medir corretamente?</Text>
                    <ChevronRight size={16} color="#F59E0B" />
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.measurementSaveButtonFull}
                    onPress={handleSaveMeasurement}
                  >
                    <Text style={styles.measurementSaveButtonText}>Salvar</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        </View>
      </Modal>

      {/* Measurement Guide Modal */}
      <Modal
        visible={showGuideModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowGuideModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.guideModal}>
            <View style={styles.guideModalHeader}>
              <TouchableOpacity
                onPress={() => setShowGuideModal(false)}
                style={styles.modalBackButton}
              >
                <ChevronLeft size={24} color="#000" />
              </TouchableOpacity>
              <Text style={styles.guideModalTitle}>Como medir</Text>
              <View style={styles.modalSpacer} />
            </View>

            <ScrollView style={styles.guideModalContent} showsVerticalScrollIndicator={false}>
              <Text style={styles.guideIntro}>
                Siga estas orientações para obter medidas precisas:
              </Text>

              {/* General Tips */}
              <View style={styles.guideSection}>
                <Text style={styles.guideSectionTitle}>Dicas Gerais</Text>
                <Text style={styles.guideText}>• Use uma fita métrica flexível</Text>
                <Text style={styles.guideText}>• Mantenha a fita paralela ao chão</Text>
                <Text style={styles.guideText}>• Não aperte muito a fita</Text>
                <Text style={styles.guideText}>• Meça sempre no mesmo horário</Text>
                <Text style={styles.guideText}>• Use roupas justas ou sem roupas</Text>
              </View>

              {/* Gender-specific guides */}
              <View style={styles.guideSection}>
                <Text style={styles.guideSectionTitle}>
                  Medidas para {selectedGender === 'female' ? 'Mulheres' : 'Homens'}
                </Text>
                {getMeasurementsForGender(selectedGender).map((measurement) => (
                  <View key={measurement.key} style={styles.guideItem}>
                    <View style={styles.guideItemHeader}>
                      <View style={[styles.guideItemDot, { backgroundColor: measurement.color }]} />
                      <Text style={styles.guideItemTitle}>{measurement.label}</Text>
                    </View>
                    <Text style={styles.guideItemText}>
                      {measurementGuides[selectedGender][measurement.key as keyof typeof measurementGuides.female]}
                    </Text>
                  </View>
                ))}
              </View>

              <View style={styles.bottomPadding} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Measurement History Modal */}
      <Modal
        visible={showHistoryModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowHistoryModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.historyModal}>
            <View style={styles.historyModalHeader}>
              <TouchableOpacity
                onPress={() => setShowHistoryModal(false)}
                style={styles.modalBackButton}
              >
                <ChevronLeft size={24} color="#000" />
              </TouchableOpacity>
              <Text style={styles.historyModalTitle}>
                Histórico - {selectedMeasurementForHistory ? 
                  getMeasurementsForGender(selectedGender).find(m => m.key === selectedMeasurementForHistory)?.label 
                  : ''
                }
              </Text>
              <View style={styles.modalSpacer} />
            </View>

            <ScrollView style={styles.historyModalContent} showsVerticalScrollIndicator={false}>
              {selectedMeasurementForHistory && measurementHistory[selectedMeasurementForHistory] && 
               measurementHistory[selectedMeasurementForHistory].length > 0 ? (
                <View style={styles.historyList}>
                  {measurementHistory[selectedMeasurementForHistory].map((measurement, index) => (
                    <View key={measurement.id} style={styles.historyItem}>
                      <View style={styles.historyItemContent}>
                        <View style={styles.historyItemLeft}>
                          <Text style={styles.historyItemValue}>
                            {measurementUnitSystem === 'metric' 
                              ? `${measurement.value} cm`
                              : `${(parseFloat(measurement.value) / 2.54).toFixed(1)} in`
                            }
                          </Text>
                          <Text style={styles.historyItemDate}>
                            {new Date(measurement.date).toLocaleDateString('pt-BR')}
                          </Text>
                        </View>
                        <View style={styles.historyItemActions}>
                          <TouchableOpacity
                            style={styles.historyActionButton}
                            onPress={() => handleEditMeasurement(selectedMeasurementForHistory, measurement.id)}
                          >
                            <Edit3 size={16} color="#3B82F6" />
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.historyActionButton}
                            onPress={() => handleDeleteMeasurement(selectedMeasurementForHistory, measurement.id)}
                          >
                            <X size={16} color="#EF4444" />
                          </TouchableOpacity>
                        </View>
                      </View>
                      {index < measurementHistory[selectedMeasurementForHistory].length - 1 && (
                        <View style={styles.historyItemSeparator} />
                      )}
                    </View>
                  ))}
                </View>
              ) : (
                <View style={styles.historyEmpty}>
                  <Text style={styles.historyEmptyText}>Nenhuma medição registrada ainda</Text>
                </View>
              )}

              <View style={styles.bottomPadding} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Date Picker Modal */}
      <Modal
        visible={showDatePickerModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDatePickerModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.datePickerModal}>
            <View style={styles.datePickerHeader}>
              <Text style={styles.datePickerTitle}>Selecionar Data</Text>
              <TouchableOpacity
                onPress={() => setShowDatePickerModal(false)}
                style={styles.modalCloseButton}
              >
                <X size={24} color="#9CA3AF" />
              </TouchableOpacity>
            </View>

            <View style={styles.datePickerContent}>
              <TextInput
                style={styles.datePickerInput}
                value={measurementDate}
                onChangeText={setMeasurementDate}
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#9CA3AF"
              />
              
              <View style={styles.datePickerActions}>
                <TouchableOpacity
                  style={styles.datePickerCancelButton}
                  onPress={() => setShowDatePickerModal(false)}
                >
                  <Text style={styles.datePickerCancelText}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.datePickerConfirmButton}
                  onPress={() => setShowDatePickerModal(false)}
                >
                  <Text style={styles.datePickerConfirmText}>Confirmar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    flex: 1,
    textAlign: 'center',
  },
  settingsButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#E5E7EB',
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#FFFFFF',
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#9CA3AF',
  },
  activeTabText: {
    color: '#000',
    fontWeight: '600',
  },
  tabContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },

  weightIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  currentWeightSection: {
    alignItems: 'flex-start',
    marginVertical: 16,
  },
  currentWeightValue: {
    fontSize: 48,
    fontWeight: '700',
    color: '#1E40AF',
  },
  currentWeightUnit: {
    fontSize: 20,
    fontWeight: '500',
    color: '#1E40AF',
  },
  weightMessage: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  updateButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  updateButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  metaProgressContainer: {
    marginBottom: 16,
  },
  metaProgressBar: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    marginBottom: 8,
    position: 'relative',
  },
  metaProgress: {
    height: 8,
    backgroundColor: '#F59E0B',
    borderRadius: 4,
    width: '0%',
  },
  metaCurrentIndicator: {
    position: 'absolute',
    top: -30,
    left: '0%',
    transform: [{ translateX: -25 }],
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  metaCurrentText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  metaLabels: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  metaItem: {
    alignItems: 'center',
  },
  metaValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  metaLabel: {
    fontSize: 14,
    color: '#6B7280',
  },
  imcHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  imcTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  imcContent: {
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  imcValueContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
  },
  imcValue: {
    fontSize: 48,
    fontWeight: '700',
    color: '#1F2937',
  },
  imcCategory: {
    fontSize: 18,
    color: '#06B6D4',
    fontWeight: '500',
  },
  imcStatus: {
    fontSize: 16,
    color: '#06B6D4',
    fontWeight: '500',
  },
  imcIndicatorArrow: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginBottom: 16,
  },
  triangleDown: {
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderTopWidth: 12,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    // borderTopColor will be set dynamically
  },
  bmiIndicatorContainer: {
    position: 'relative',
    marginTop: 16,
  },
  bmiColorBar: {
    flexDirection: 'row',
    height: 8,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  bmiColorSegment: {
    height: 8,
  },
  bmiLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  bmiLabel: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  bmiIndicator: {
    position: 'absolute',
    top: -12,
    alignItems: 'center',
    zIndex: 10,
  },
  bmiTriangle: {
    width: 0,
    height: 0,
    borderLeftWidth: 5,
    borderRightWidth: 5,
    borderTopWidth: 8,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#000000',
  },
  bmiIndicatorBottom: {
    position: 'absolute',
    bottom: -12,
    alignItems: 'center',
  },
  bmiTriangleBottom: {
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderTopWidth: 8,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#06B6D4',
  },
  metaIndicator: {
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  metaBadge: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  metaBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  periodTabs: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    padding: 4,
    marginBottom: 20,
  },
  periodTab: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  activePeriodTab: {
    backgroundColor: '#FFFFFF',
  },
  periodTabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#9CA3AF',
  },
  activePeriodTabText: {
    color: '#000',
    fontWeight: '600',
  },
  monthLabel: {
    fontSize: 16,
    color: '#9CA3AF',
    fontWeight: '500',
  },
  pesoHistorySection: {
    marginTop: 24,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  pesoHistoryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    marginBottom: 8,
  },
  pesoHistorySubtitle: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  pesoHistoryButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  pesoHistoryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  currentWeightDisplay: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E40AF',
    textAlign: 'center',
    marginTop: 8,
  },
  pesoMeasurementContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'center',
    marginTop: 12,
    marginBottom: 8,
  },
  pesoMeasurementValue: {
    fontSize: 36,
    fontWeight: '700',
    color: '#1E40AF',
  },
  pesoMeasurementUnit: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E40AF',
    marginLeft: 4,
  },
  pesoMeasurementDate: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 4,
  },
  currentWeightContainer: {
    alignItems: 'center',
    paddingVertical: 40,
    marginBottom: 20,
  },
  weightDisplayLarge: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 8,
  },
  weightValueLarge: {
    fontSize: 48,
    fontWeight: '700',
    color: '#000',
  },
  weightUnitLarge: {
    fontSize: 24,
    fontWeight: '600',
    color: '#6B7280',
    marginLeft: 4,
  },
  weightStatusText: {
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '500',
  },
  calendarContainer: {
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  dayHeadersRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    marginBottom: 16,
  },
  dayHeader: {
    fontSize: 12,
    fontWeight: '500',
    color: '#9CA3AF',
    textAlign: 'center',
    flex: 1,
  },
  todayHeader: {
    color: '#F59E0B',
    fontWeight: '600',
  },
  calendarWeek: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  calendarDay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    height: 50,
    paddingTop: 4,
  },
  dayCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  todayCircle: {
    backgroundColor: '#F59E0B',
  },
  dayText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#000',
    textAlign: 'center',
  },
  todayText: {
    color: '#FFFFFF',
    fontWeight: '700',
    textAlign: 'center',
  },
  todayIndicator: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#F59E0B',
    marginTop: 4,
  },
  importButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  importText: {
    fontSize: 14,
    color: '#9CA3AF',
  },

  primaryButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 25,
    paddingVertical: 14,
    paddingHorizontal: 32,
    alignItems: 'center',
    alignSelf: 'center',
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  historyEmpty: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  emptyText: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 12,
  },
  importSection: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  bottomPadding: {
    height: 40,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  weightModal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    width: '85%',
    maxWidth: 400,
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  weightModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 32,
  },
  weightModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  modalCloseButton: {
    padding: 4,
  },
  weightModalContent: {
    gap: 24,
  },
  weightInputSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  weightInputLabel: {
    fontSize: 16,
    color: '#9CA3AF',
    fontWeight: '500',
    flex: 1,
  },
  weightInputContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    flex: 2,
    justifyContent: 'flex-end',
  },
  weightInputField: {
    fontSize: 32,
    fontWeight: '600',
    color: '#06B6D4',
    textAlign: 'center',
    minWidth: 100,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 4,
  },
  weightUnit: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
    marginLeft: 8,
  },
  heightInputSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  heightInputLabel: {
    fontSize: 16,
    color: '#9CA3AF',
    fontWeight: '500',
    flex: 1,
  },
  heightInputContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    flex: 2,
    justifyContent: 'flex-end',
  },
  heightInputField: {
    fontSize: 32,
    fontWeight: '600',
    color: '#06B6D4',
    textAlign: 'center',
    minWidth: 100,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 4,
  },
  heightInputFieldFeet: {
    fontSize: 32,
    fontWeight: '600',
    color: '#06B6D4',
    textAlign: 'center',
    minWidth: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 4,
  },
  heightInputFieldInches: {
    fontSize: 32,
    fontWeight: '600',
    color: '#06B6D4',
    textAlign: 'center',
    minWidth: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 4,
    marginLeft: 16,
  },
  heightUnit: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
    marginLeft: 8,
  },
  heightUnitFeet: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
    marginLeft: 8,
  },
  heightUnitInches: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
    marginLeft: 8,
  },
  unitToggleContainer: {
    flexDirection: 'row',
    alignSelf: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    padding: 2,
    marginVertical: 8,
  },
  unitToggle: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 18,
  },
  unitToggleLeft: {
    borderTopRightRadius: 0,
    borderBottomRightRadius: 0,
  },
  unitToggleRight: {
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
  },
  unitToggleActive: {
    backgroundColor: '#374151',
  },
  unitToggleText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#9CA3AF',
  },
  unitToggleTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  modalActionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  deleteWeightButton: {
    backgroundColor: '#EF4444',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    flex: 1,
  },
  deleteWeightButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  saveWeightButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    flex: 1,
  },
  saveWeightButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  weightChartContainer: {
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  chartMonth: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  weightBadge: {
    backgroundColor: '#000',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  weightBadgeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  chartArea: {
    height: 200,
    position: 'relative',
  },
  chartGrid: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'space-between',
    paddingVertical: 20,
  },
  gridLine: {
    height: 1,
    backgroundColor: '#E5E7EB',
    width: '100%',
  },
  chartLine: {
    position: 'absolute',
    top: 60,
    right: 40,
    bottom: 80,
    width: 2,
    backgroundColor: '#000',
  },
  weightPoint: {
    position: 'absolute',
    bottom: 0,
    right: -4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  chartLabels: {
    position: 'absolute',
    bottom: 10,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  chartLabel: {
    fontSize: 14,
    color: '#9CA3AF',
    fontWeight: '500',
  },
  weightValues: {
    position: 'absolute',
    right: 10,
    top: 20,
    bottom: 40,
    justifyContent: 'space-between',
  },
  weightValue: {
    fontSize: 14,
    color: '#9CA3AF',
    fontWeight: '500',
  },
  // BMI Modal Styles
  bmiModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    flex: 1,
    marginTop: 80,
  },
  bmiModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  modalBackButton: {
    padding: 4,
  },
  bmiModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  modalSpacer: {
    width: 32,
  },
  bmiModalContent: {
    flex: 1,
    paddingHorizontal: 20,
  },
  currentBMISection: {
    paddingVertical: 24,
  },
  currentBMILabel: {
    fontSize: 16,
    color: '#9CA3AF',
    marginBottom: 16,
  },
  currentBMIContainer: {
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  currentBMIValue: {
    fontSize: 48,
    fontWeight: '700',
    color: '#1E40AF',
    marginBottom: 4,
  },
  currentBMICategory: {
    fontSize: 18,
    color: '#F97316',
    fontWeight: '500',
    marginBottom: 8,
  },
  currentBMIArrow: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  weightHeightDisplay: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    alignItems: 'center',
  },
  weightHeightItem: {
    flex: 1,
    alignItems: 'center',
  },
  weightHeightLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  weightHeightValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#000',
  },
  weightHeightUnit: {
    fontSize: 16,
    fontWeight: '500',
    color: '#6B7280',
  },
  editWeightHeight: {
    padding: 8,
  },
  bmiCategoriesList: {
    marginBottom: 24,
  },
  bmiCategoryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    marginBottom: 8,
    borderRadius: 12,
    backgroundColor: 'transparent',
  },
  activeBmiCategory: {
    backgroundColor: '#F97316',
  },
  bmiCategoryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  bmiCategoryDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  bmiCategoryName: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
  },
  activeBmiCategoryText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  bmiCategoryRange: {
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '500',
  },
  bmiExplanation: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  bmiExplanationText: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
  },
  // Goal Modal Styles
  goalModal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    width: '85%',
    maxWidth: 350,
    paddingVertical: 32,
    paddingHorizontal: 24,
  },
  goalModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 40,
  },
  goalModalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1E40AF',
  },
  goalModalContent: {
    alignItems: 'center',
  },
  goalWeightInputSection: {
    marginBottom: 32,
  },
  goalInputLabel: {
    fontSize: 16,
    color: '#9CA3AF',
    fontWeight: '500',
    marginBottom: 16,
    textAlign: 'center',
  },
  goalWeightInputContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'center',
    gap: 8,
  },
  goalWeightInputField: {
    fontSize: 48,
    fontWeight: '600',
    color: '#1E40AF',
    textAlign: 'center',
    width: 120,
    height: 60,
    borderBottomWidth: 2,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 8,
  },
  goalWeightInputUnit: {
    fontSize: 20,
    fontWeight: '500',
    color: '#1E40AF',
  },
  goalUnitToggleContainer: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 25,
    padding: 4,
    marginBottom: 40,
  },
  goalUnitToggle: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 20,
    minWidth: 60,
    alignItems: 'center',
  },
  goalUnitToggleLeft: {
    borderTopRightRadius: 0,
    borderBottomRightRadius: 0,
  },
  goalUnitToggleRight: {
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
  },
  goalUnitToggleActive: {
    backgroundColor: '#1E40AF',
  },
  goalUnitToggleText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#9CA3AF',
  },
  goalUnitToggleTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  saveGoalButton: {
    backgroundColor: '#10B981',
    borderRadius: 25,
    paddingVertical: 16,
    paddingHorizontal: 48,
    width: '100%',
    alignItems: 'center',
  },
  saveGoalButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  // Measurement Tab Styles
  measurementContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 20,
    marginBottom: 24,
  },
  bodyIllustrationContainer: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 20,
  },
  bodyIllustration: {
    alignItems: 'center',
    position: 'relative',
  },
  bodyHead: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E5E7EB',
    marginBottom: 8,
  },
  bodyTorso: {
    width: 60,
    height: 80,
    backgroundColor: '#E5E7EB',
    borderRadius: 30,
    marginBottom: 8,
    position: 'relative',
    alignItems: 'center',
  },
  bodyHips: {
    width: 65,
    height: 40,
    backgroundColor: '#E5E7EB',
    borderRadius: 20,
    marginBottom: 8,
    position: 'relative',
    alignItems: 'center',
  },
  bodyLegs: {
    flexDirection: 'row',
    gap: 8,
  },
  measurementLine: {
    position: 'absolute',
    height: 2,
    backgroundColor: '#F97316',
    width: 80,
  },
  bustLine: {
    top: 20,
    backgroundColor: '#F97316',
  },
  waistLine: {
    top: 50,
    backgroundColor: '#3B82F6',
  },
  hipLine: {
    top: 15,
    backgroundColor: '#F97316',
  },
  thighLine: {
    top: 10,
    backgroundColor: '#8B5CF6',
  },
  measurementsGrid: {
    flex: 1,
    gap: 16,
  },
  measurementRow: {
    flexDirection: 'row',
    gap: 16,
  },
  measurementItem: {
    flex: 1,
    alignItems: 'flex-start',
  },
  measurementDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#F97316',
    marginBottom: 4,
  },
  cinturaColor: {
    backgroundColor: '#3B82F6',
  },
  quadrilColor: {
    backgroundColor: '#F97316',
  },
  coxaColor: {
    backgroundColor: '#8B5CF6',
  },
  measurementLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#000',
    marginBottom: 4,
  },
  measurementValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#9CA3AF',
  },
  howToMeasureButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3E2',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  howToMeasureIcon: {
    fontSize: 24,
  },
  howToMeasureText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#F59E0B',
    flex: 1,
  },
  measurementSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  measurementSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  emptyMeasurementContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  insertDataButton: {
    backgroundColor: '#6366F1',
    borderRadius: 25,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  insertDataButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  emptyMeasurementText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
  
  // New Measurement System Styles
  genderSelection: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  genderOption: {
    flex: 1,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  genderOptionActive: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  genderOptionText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#6B7280',
  },
  genderOptionTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  addMeasurementButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  addMeasurementButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  measurementsOverview: {
    gap: 8,
    marginTop: 16,
  },
  measurementCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 10,
    width: '100%',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minHeight: 45,
  },
  measurementCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  measurementCardActions: {
    flexDirection: 'row',
    gap: 8,
  },
  measurementCardButton: {
    width: 28,
    height: 28,
    backgroundColor: '#F9FAFB',
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  measurementCardHistoryIcon: {
    fontSize: 12,
  },
  measurementCardIndicator: {
    width: 20,
    height: 4,
    borderRadius: 2,
  },
  measurementCardLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 2,
    textAlign: 'left',
    width: '100%',
  },
  measurementCardValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    textAlign: 'left',
    width: '100%',
  },
  measurementCardDate: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
    textAlign: 'left',
    width: '100%',
  },
  chartPeriodSelector: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 2,
  },
  chartPeriodButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  chartPeriodButtonActive: {
    backgroundColor: '#FFFFFF',
  },
  chartPeriodButtonText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#6B7280',
  },
  chartPeriodButtonTextActive: {
    color: '#000',
    fontWeight: '600',
  },
  chartContainer: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 16,
    textAlign: 'center',
  },
  chartArea: {
    height: 200,
    position: 'relative',
    marginBottom: 16,
  },
  chartGrid: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'space-between',
  },
  chartGridLine: {
    height: 1,
    backgroundColor: '#E5E7EB',
    width: '100%',
  },
  chartDataContainer: {
    position: 'absolute',
    top: 20,
    left: 0,
    right: 0,
    bottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
  },
  chartLine: {
    width: 4,
    height: '60%',
    borderRadius: 2,
  },
  chartLegend: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
  },
  chartLegendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  chartLegendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  chartLegendText: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
  },
  
  // Measurement Modal Styles
  measurementModal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    width: '95%',
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  measurementModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  measurementModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  measurementModalContent: {
    minHeight: 200,
  },
  measurementSelectionContainer: {
    gap: 20,
  },
  measurementSelectionTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#374151',
    textAlign: 'center',
  },
  measurementSelectionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  measurementSelectionItem: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    width: '48%',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  measurementSelectionDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 8,
  },
  measurementSelectionLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
  },
  measurementInputContainer: {
    gap: 24,
  },
  measurementInputLabel: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
    textAlign: 'center',
  },
  measurementInputSection: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'center',
    gap: 8,
  },
  measurementInputField: {
    fontSize: 36,
    fontWeight: '600',
    color: '#3B82F6',
    textAlign: 'center',
    minWidth: 120,
    borderBottomWidth: 2,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 8,
  },
  measurementUnit: {
    fontSize: 18,
    fontWeight: '500',
    color: '#374151',
  },
  measurementModalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  measurementBackButton: {
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    flex: 1,
  },
  measurementBackButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  measurementSaveButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    flex: 1,
  },
  measurementSaveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  
  // Guide Modal Styles
  guideModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    flex: 1,
    marginTop: 100,
  },
  guideModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  guideModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  guideModalContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  guideIntro: {
    fontSize: 16,
    color: '#374151',
    marginBottom: 24,
    textAlign: 'center',
    fontWeight: '500',
  },
  guideSection: {
    marginBottom: 32,
  },
  guideSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    marginBottom: 16,
  },
  guideText: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
    lineHeight: 20,
  },
  guideItem: {
    marginBottom: 20,
  },
  guideItemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  guideItemDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  guideItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  guideItemText: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
    paddingLeft: 18,
  },
  
  // Date picker styles
  measurementDateSection: {
    marginTop: 16,
  },
  measurementDateLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
    textAlign: 'center',
  },
  measurementDateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    gap: 8,
  },
  measurementDateText: {
    fontSize: 16,
    color: '#374151',
    fontWeight: '500',
  },
  measurementDateIcon: {
    fontSize: 18,
  },
  
  // Date picker modal styles
  datePickerModal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    width: '85%',
    maxWidth: 350,
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  datePickerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  datePickerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  datePickerContent: {
    gap: 20,
  },
  datePickerInput: {
    fontSize: 16,
    color: '#374151',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    padding: 16,
    textAlign: 'center',
  },
  datePickerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  datePickerCancelButton: {
    flex: 1,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  datePickerCancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  datePickerConfirmButton: {
    flex: 1,
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  datePickerConfirmText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  
  // History modal styles
  historyModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    flex: 1,
    marginTop: 100,
  },
  historyModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  historyModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    flex: 1,
    textAlign: 'center',
  },
  historyModalContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  historyList: {
    gap: 8,
  },
  historyItem: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
  },
  historyItemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  historyItemLeft: {
    flex: 1,
  },
  historyItemValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  historyItemDate: {
    fontSize: 14,
    color: '#6B7280',
  },
  historyItemActions: {
    flexDirection: 'row',
    gap: 8,
  },
  historyActionButton: {
    width: 36,
    height: 36,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  historyItemSeparator: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginTop: 16,
  },
  historyEmpty: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  historyEmptyText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
  },
  
  // Measurement unit toggle styles
  measurementUnitToggleContainer: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 2,
    marginBottom: 16,
    alignSelf: 'center',
  },
  measurementUnitToggle: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 6,
  },
  measurementUnitToggleLeft: {
    borderTopRightRadius: 0,
    borderBottomRightRadius: 0,
  },
  measurementUnitToggleRight: {
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
  },
  measurementUnitToggleActive: {
    backgroundColor: '#3B82F6',
  },
  measurementUnitToggleText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  measurementUnitToggleTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  measurementModalUnitToggle: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 2,
    alignSelf: 'center',
  },
  howToMeasureModalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FEF3E2',
    borderRadius: 8,
    padding: 12,
    gap: 8,
  },
  howToMeasureModalText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#F59E0B',
  },
  
  // New styles for evaluation calendar
  evaluationCalendarContainer: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  evaluationCalendarTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
    textAlign: 'center',
  },
  
  // Progress header actions
  progressHeaderActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  historyButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  historyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  
  // Create new measurement button
  createNewMeasurementButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#10B981',
    borderStyle: 'dashed',
  },
  createNewMeasurementButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10B981',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
  },
  
  // Save evaluation button
  saveEvaluationButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 20,
  },
  saveEvaluationButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  
  // Full width save button for measurement modal
  measurementSaveButtonFull: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    width: '100%',
  },
  
  // Chart period selector container
  chartPeriodSelectorContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  
  // Evaluations list styles
  evaluationsList: {
    gap: 12,
  },
  evaluationItem: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  evaluationItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  evaluationItemDate: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  evaluationItemTime: {
    fontSize: 14,
    color: '#6B7280',
  },
  evaluationItemMeasurements: {
    gap: 6,
  },
  evaluationMeasurementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  evaluationMeasurementDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  evaluationMeasurementText: {
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
  },
  evaluationMoreText: {
    fontSize: 12,
    color: '#6B7280',
    fontStyle: 'italic',
    marginTop: 4,
  },
});