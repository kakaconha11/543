import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Modal,
  TextInput,
  Alert
} from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withSpring,
  withTiming,
  interpolate
} from 'react-native-reanimated';
import { ChevronLeft, Calendar, Plus, Coffee, X } from 'lucide-react-native';
import { Sunrise, Sun, Sunset, Moon, Utensils } from 'lucide-react-native';
import CircularProgress from '@/components/CircularProgress';
import MacroCard from '@/components/MacroCard';
import MealCard from '@/components/MealCard';
import TimePicker from '@/components/TimePicker';

interface MacroData {
  carbs: { consumed: number; target: number };
  fat: { consumed: number; target: number };
  protein: { consumed: number; target: number };
}

interface Meal {
  id: number;
  name: string;
  description: string;
  calories: number;
  time: string;
  icon: React.ComponentType<any>;
  onUpdateTotals?: (mealId: number, totals: { calories: number; carbs: number; fat: number; protein: number }) => void;
}

interface PredefinedMeal {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
}

const predefinedMeals: PredefinedMeal[] = [
  { id: 'breakfast', name: 'Café da Manhã', icon: Sunrise },
  { id: 'morning-snack', name: 'Lanche da Manhã', icon: Coffee },
  { id: 'lunch', name: 'Almoço', icon: Sun },
  { id: 'afternoon-snack', name: 'Lanche da Tarde', icon: Coffee },
  { id: 'pre-workout', name: 'Pré-Treino', icon: Utensils },
  { id: 'post-workout', name: 'Pós-Treino', icon: Utensils },
  { id: 'dinner', name: 'Jantar', icon: Sunset },
  { id: 'supper', name: 'Ceia', icon: Moon },
  { id: 'custom', name: 'Personalizada', icon: Plus },
];

const predefinedTimes = [
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'
];

const hours = Array.from({ length: 18 }, (_, i) => String(i + 6).padStart(2, '0'));
const minutes = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

export default function HomeScreen() {
  const [calorieTarget, setCalorieTarget] = useState(2340);
  const [macroTargets, setMacroTargets] = useState({
    carbs: 285,
    fat: 78,
    protein: 117
  });
  const [showEditGoalsModal, setShowEditGoalsModal] = useState(false);
  const [tempCalorieTarget, setTempCalorieTarget] = useState('2340');
  const [tempCarbsTarget, setTempCarbsTarget] = useState('285');
  const [tempFatTarget, setTempFatTarget] = useState('78');
  const [tempProteinTarget, setTempProteinTarget] = useState('117');
  const [mealTotals, setMealTotals] = useState<Record<number, { calories: number; carbs: number; fat: number; protein: number }>>({});
  const [meals, setMeals] = useState<Meal[]>([
    {
      id: 1,
      name: 'Café da manhã',
      description: 'Breakfast fuels your body and day',
      calories: 420,
      time: '8:00 AM',
      icon: Coffee,
      onUpdateTotals: updateMealTotals,
    }
  ]);
  const [showAddMealModal, setShowAddMealModal] = useState(false);
  const [selectedMealType, setSelectedMealType] = useState<string | null>(null);
  const [newMealName, setNewMealName] = useState('');
  const [selectedHour, setSelectedHour] = useState<string>('12');
  const [selectedMinute, setSelectedMinute] = useState<string>('00');
  const [showTimePicker, setShowTimePicker] = useState(false);

  const handleSaveGoals = () => {
    const calories = parseInt(tempCalorieTarget);
    const carbs = parseInt(tempCarbsTarget);
    const fat = parseInt(tempFatTarget);
    const protein = parseInt(tempProteinTarget);

    // Validações
    if (isNaN(calories) || calories < 800 || calories > 10000) {
      Alert.alert('Erro', 'Meta de calorias deve estar entre 800 e 5000 kcal');
      return;
    }
    if (isNaN(carbs) || carbs < 50 || carbs > 1000) {
      Alert.alert('Erro', 'Meta de carboidratos deve estar entre 50 e 1000g');
      return;
    }
    if (isNaN(fat) || fat < 20 || fat > 1000) {
      Alert.alert('Erro', 'Meta de gordura deve estar entre 20 e 1000g');
      return;
    }
    if (isNaN(protein) || protein < 50 || protein > 1000) {
      Alert.alert('Erro', 'Meta de proteína deve estar entre 50 e 1000g');
      return;
    }

    setCalorieTarget(calories);
    setMacroTargets({ carbs, fat, protein });
    setShowEditGoalsModal(false);
    Alert.alert('Sucesso', 'Metas atualizadas com sucesso!');
  };

  function updateMealTotals(mealId: number, totals: { calories: number; carbs: number; fat: number; protein: number }) {
    setMealTotals(prev => ({
      ...prev,
      [mealId]: totals
    }));
  }

  // Calculate totals from all meals
  const totalCalories = Object.values(mealTotals).reduce((sum, totals) => sum + totals.calories, 0);
  const totalCarbs = Object.values(mealTotals).reduce((sum, totals) => sum + totals.carbs, 0);
  const totalFat = Object.values(mealTotals).reduce((sum, totals) => sum + totals.fat, 0);
  const totalProtein = Object.values(mealTotals).reduce((sum, totals) => sum + totals.protein, 0);

  const progress = useSharedValue(0);
  const carbsProgress = useSharedValue(0);
  const fatProgress = useSharedValue(0);
  const proteinProgress = useSharedValue(0);

  useEffect(() => {
    progress.value = withTiming(Math.min(totalCalories / calorieTarget, 1), {
      duration: 1500,
    });
    carbsProgress.value = withTiming(Math.min(totalCarbs / macroTargets.carbs, 1), {
      duration: 1500,
    });
    fatProgress.value = withTiming(Math.min(totalFat / macroTargets.fat, 1), {
      duration: 1500,
    });
    proteinProgress.value = withTiming(Math.min(totalProtein / macroTargets.protein, 1), {
      duration: 1500,
    });
  }, [totalCalories, totalCarbs, totalFat, totalProtein, calorieTarget, macroTargets]);

  const calories = {
    consumed: Math.round(totalCalories),
    target: calorieTarget
  };

  const macros = {
    carbs: { consumed: Math.round(totalCarbs), target: macroTargets.carbs },
    fat: { consumed: Math.round(totalFat), target: macroTargets.fat },
    protein: { consumed: Math.round(totalProtein), target: macroTargets.protein }
  };

  const handleAddMeal = () => {
    if (selectedMealType && selectedHour && selectedMinute) {
      const selectedPredefined = predefinedMeals.find(m => m.id === selectedMealType);
      const mealName = selectedMealType === 'custom' ? newMealName : selectedPredefined?.name || '';
      
      if (selectedMealType === 'custom' && !newMealName.trim()) {
        Alert.alert('Erro', 'Por favor, digite o nome da refeição personalizada');
        return;
      }

      const newMeal: Meal = {
        id: meals.length + 1,
        name: mealName,
        description: 'Nova refeição adicionada',
        calories: 0,
        time: `${selectedHour}:${selectedMinute}`,
        icon: selectedPredefined?.icon || Plus,
        onUpdateTotals: updateMealTotals,
      };

      setMeals([...meals, newMeal]);
      setSelectedMealType(null);
      setNewMealName('');
      setSelectedHour('08');
      setSelectedMinute('00');
      setShowAddMealModal(false);
    } else {
      Alert.alert('Erro', 'Por favor, selecione o tipo de refeição e o horário');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Hoje</Text>
        <TouchableOpacity style={styles.calendarButton}>
          <Calendar size={24} color="#000" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* Tracker Section */}
        <View style={styles.trackerSection}>
          <View style={styles.trackerContainer}>
            <View style={styles.trackerHeader}>
              <Text style={styles.trackerTitle}>Tracker</Text>
              <View>
                <TouchableOpacity onPress={() => {
                  setTempCalorieTarget(String(calorieTarget));
                  setTempCarbsTarget(String(macroTargets.carbs));
                  setTempFatTarget(String(macroTargets.fat));
                  setTempProteinTarget(String(macroTargets.protein));
                  setShowEditGoalsModal(true);
                }}>
                  <Text style={styles.editButton}>Editar Metas</Text>
                </TouchableOpacity>
              </View>
            </View>
            
            {/* Circular Progress */}
            <View style={styles.progressContainer}>
              <CircularProgress
                size={260}
                strokeWidth={24}
                progress={progress}
                backgroundColor="#E5E7EB"
                progressColor="#B3A1FF"
                secondaryColor="#A855F7"
                calories={calories}
              />
            </View>
          </View>
        </View>

        {/* Macro Cards */}
        <View style={styles.macroContainer}>
          <MacroCard
            title="Carboidrato"
            consumed={macros.carbs.consumed}
            target={macros.carbs.target}
            color="#B2EAB8"
            progressColor="#E6F7E6"
            progress={carbsProgress}
          />
          <MacroCard
            title="Gordura"
            consumed={macros.fat.consumed}
            target={macros.fat.target}
            color="#B8ECF4"
            progressColor="#E7F8FB"
            progress={fatProgress}
          />
          <MacroCard
            title="Proteina"
            consumed={macros.protein.consumed}
            target={macros.protein.target}
            color="#FEC775"
            progressColor="#FCEACE"
            progress={proteinProgress}
          />
        </View>

        {/* Daily Meals */}
        <View style={styles.mealsSection}>
          <View style={styles.mealsSectionHeader}>
            <Text style={styles.mealsTitle}>Refeições diárias</Text>
            <TouchableOpacity onPress={() => setShowAddMealModal(true)}>
              <Text style={styles.addMealText}>+ Adicionar Refeição</Text>
            </TouchableOpacity>
          </View>
          
          {meals.map((meal) => (
            <MealCard 
              key={meal.id} 
              meal={meal} 
              onDeleteMeal={(mealId) => setMeals(meals.filter(m => m.id !== mealId))}
            />
          ))}
        </View>
      </ScrollView>

      {/* Add Meal Modal */}
      <Modal
        visible={showAddMealModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowAddMealModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Adicionar Refeição</Text>
              <TouchableOpacity 
                onPress={() => {
                  setShowAddMealModal(false);
                  setSelectedMealType(null);
                  setNewMealName('');
                  setSelectedHour('08');
                  setSelectedMinute('00');
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            {/* Meal Type Selection */}
            <View style={styles.mealTypeContainer}>
              <Text style={styles.inputLabel}>Tipo de Refeição</Text>
              <View style={styles.mealTypeGrid}>
                {predefinedMeals.map((mealType) => {
                  const IconComponent = mealType.icon;
                  const isSelected = selectedMealType === mealType.id;
                  return (
                    <TouchableOpacity
                      key={mealType.id}
                      style={[
                        styles.mealTypeOption,
                        isSelected && styles.mealTypeOptionSelected
                      ]}
                      onPress={() => setSelectedMealType(mealType.id)}
                    >
                      <IconComponent 
                        size={20} 
                        color={isSelected ? '#0F0F1A' : '#0F0F1A'} 
                      />
                      <Text style={[
                        styles.mealTypeText,
                        isSelected && styles.mealTypeTextSelected
                      ]}>
                        {mealType.name}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            {/* Custom Meal Name Input */}
            {selectedMealType === 'custom' && (
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Nome da Refeição</Text>
                <TextInput
                  style={styles.textInput}
                  value={newMealName}
                  onChangeText={setNewMealName}
                  placeholder="Digite o nome da refeição"
                  placeholderTextColor="#9CA3AF"
                />
              </View>
            )}

            {/* Time Selection */}
            <TimePicker
              selectedHour={selectedHour}
              selectedMinute={selectedMinute}
              onHourChange={setSelectedHour}
              onMinuteChange={setSelectedMinute}
            />

            {/* Single Add Button */}
            <TouchableOpacity 
              style={styles.addButton}
              onPress={handleAddMeal}
            >
              <Text style={styles.addButtonText}>Adicionar Refeição</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Edit Goals Modal */}
      <Modal
        visible={showEditGoalsModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowEditGoalsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.editGoalsModalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Editar Metas</Text>
              <TouchableOpacity 
                onPress={() => {
                  setShowEditGoalsModal(false);
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Calorie Target */}
              <View style={styles.goalInputContainer}>
                <Text style={styles.goalLabel}>Meta de Calorias</Text>
                <View style={styles.goalInputRow}>
                  <TextInput
                    style={styles.goalInput}
                    value={tempCalorieTarget}
                    onChangeText={setTempCalorieTarget}
                    keyboardType="numeric"
                    placeholder="2340"
                    placeholderTextColor="#9CA3AF"
                  />
                  <Text style={styles.goalUnit}>kcal</Text>
                </View>
              </View>

              {/* Carbs Target */}
              <View style={styles.goalInputContainer}>
                <View style={styles.goalLabelRow}>
                  <View style={[styles.colorIndicator, { backgroundColor: '#B2EAB8' }]} />
                  <Text style={styles.goalLabel}>Meta de Carboidratos</Text>
                </View>
                <View style={styles.goalInputRow}>
                  <TextInput
                    style={styles.goalInput}
                    value={tempCarbsTarget}
                    onChangeText={setTempCarbsTarget}
                    keyboardType="numeric"
                    placeholder="285"
                    placeholderTextColor="#9CA3AF"
                  />
                  <Text style={styles.goalUnit}>g</Text>
                </View>
              </View>

              {/* Fat Target */}
              <View style={styles.goalInputContainer}>
                <View style={styles.goalLabelRow}>
                  <View style={[styles.colorIndicator, { backgroundColor: '#B8ECF4' }]} />
                  <Text style={styles.goalLabel}>Meta de Gordura</Text>
                </View>
                <View style={styles.goalInputRow}>
                  <TextInput
                    style={styles.goalInput}
                    value={tempFatTarget}
                    onChangeText={setTempFatTarget}
                    keyboardType="numeric"
                    placeholder="78"
                    placeholderTextColor="#9CA3AF"
                  />
                  <Text style={styles.goalUnit}>g</Text>
                </View>
              </View>

              {/* Protein Target */}
              <View style={styles.goalInputContainer}>
                <View style={styles.goalLabelRow}>
                  <View style={[styles.colorIndicator, { backgroundColor: '#FEC775' }]} />
                  <Text style={styles.goalLabel}>Meta de Proteína</Text>
                </View>
                <View style={styles.goalInputRow}>
                  <TextInput
                    style={styles.goalInput}
                    value={tempProteinTarget}
                    onChangeText={setTempProteinTarget}
                    keyboardType="numeric"
                    placeholder="117"
                    placeholderTextColor="#9CA3AF"
                  />
                  <Text style={styles.goalUnit}>g</Text>
                </View>
              </View>
            </ScrollView>

            {/* Save Button */}
            <TouchableOpacity 
              style={styles.saveGoalsButton}
              onPress={handleSaveGoals}
            >
              <Text style={styles.saveGoalsButtonText}>Salvar Metas</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 0,
    backgroundColor: '#FFFFFF',
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    letterSpacing: -0.5,
  },
  calendarButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
  },
  trackerSection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  trackerContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
  },
  trackerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  trackerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#374151',
  },
  editButton: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  progressContainer: {
    alignItems: 'center',
  },
  macroContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 30,
    justifyContent: 'center',
  },
  mealsSection: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  mealsSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  mealsTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  addMealText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0F0F1A',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    maxWidth: 400,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  closeButton: {
    padding: 4,
  },
  mealTypeContainer: {
    marginBottom: 20,
  },
  mealTypeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  mealTypeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: '#F9FAFB',
    gap: 4,
    width: '48%',
  },
  mealTypeOptionSelected: {
    borderColor: '#B3A1FF',
    backgroundColor: '#F7F5FF',
  },
  mealTypeText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#6B7280',
    flex: 1,
  },
  mealTypeTextSelected: {
    color: '#B3A1FF',
    fontWeight: '600',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',
    backgroundColor: '#F9FAFB',
  },
  timeSelectionContainer: {
    marginBottom: 20,
  },
  addButton: {
    width: '100%',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#0F0F1A',
    alignItems: 'center',
    marginTop: 8,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  editGoalsModalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    maxWidth: 400,
    maxHeight: '80%',
  },
  goalInputContainer: {
    marginBottom: 20,
  },
  goalLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  colorIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  goalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  goalInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  goalInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',
    backgroundColor: '#F9FAFB',
    textAlign: 'center',
    fontWeight: '600',
  },
  goalUnit: {
    fontSize: 16,
    fontWeight: '500',
    color: '#6B7280',
    minWidth: 40,
  },
  saveGoalsButton: {
    width: '100%',
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: '#0F0F1A',
    alignItems: 'center',
    marginTop: 8,
  },
  saveGoalsButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});