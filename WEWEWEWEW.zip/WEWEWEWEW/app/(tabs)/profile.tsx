import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  TextInput,
  Alert,
  Modal,
} from 'react-native';
import { User, Calculator, Info, X, Activity, Target, Award, Settings } from 'lucide-react-native';

interface UserProfile {
  name: string;
  weight: number;
  height: number;
  age: number;
  gender: 'male' | 'female';
  activityLevel: number;
}

interface TMBResult {
  tmb: number;
  get: number;
}

const profileOptions = [
  { id: 1, title: 'Personal Info', icon: User, description: 'Age, height, weight' },
  { id: 2, title: 'Goals', icon: Target, description: 'Daily calorie and macro targets' },
  { id: 4, title: 'Achievements', icon: Award, description: 'Your progress milestones' },
  { id: 5, title: 'Settings', icon: Settings, description: 'App preferences and more' },
];

const activityLevels = [
  { value: 1.2, label: 'Sedentário', description: 'Pouco ou nenhum exercício' },
  { value: 1.375, label: 'Leve', description: 'Exercício leve 1-3 dias/semana' },
  { value: 1.55, label: 'Moderado', description: 'Exercício moderado 3-5 dias/semana' },
  { value: 1.725, label: 'Alto', description: 'Exercício intenso 6-7 dias/semana' },
  { value: 1.9, label: 'Extremo', description: 'Exercício muito intenso, trabalho físico' },
];

export default function ProfileScreen() {
  // User profile data
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'João Silva',
    weight: 75,
    height: 175,
    age: 30,
    gender: 'male',
    activityLevel: 1.55,
  });

  // Modal states
  const [showHarrisBenedictModal, setShowHarrisBenedictModal] = useState(false);
  const [showMifflinModal, setShowMifflinModal] = useState(false);
  const [showOwenModal, setShowOwenModal] = useState(false);

  // Harris-Benedict Calculator States
  const [hbWeight, setHbWeight] = useState('');
  const [hbHeight, setHbHeight] = useState('');
  const [hbAge, setHbAge] = useState('');
  const [hbGender, setHbGender] = useState<'male' | 'female'>('male');
  const [hbActivityLevel, setHbActivityLevel] = useState(1.55);
  const [hbResult, setHbResult] = useState<TMBResult | null>(null);

  // Mifflin-St Jeor Calculator States
  const [mjWeight, setMjWeight] = useState('');
  const [mjHeight, setMjHeight] = useState('');
  const [mjAge, setMjAge] = useState('');
  const [mjGender, setMjGender] = useState<'male' | 'female'>('male');
  const [mjActivityLevel, setMjActivityLevel] = useState(1.55);
  const [mjResult, setMjResult] = useState<TMBResult | null>(null);

  // Owen Calculator States
  const [owWeight, setOwWeight] = useState('');
  const [owHeight, setOwHeight] = useState('');
  const [owAge, setOwAge] = useState('');
  const [owGender, setOwGender] = useState<'male' | 'female'>('male');
  const [owActivityLevel, setOwActivityLevel] = useState(1.55);
  const [owResult, setOwResult] = useState<TMBResult | null>(null);

  // Harris-Benedict Calculation
  const calculateHarrisBenedict = () => {
    const weight = parseFloat(hbWeight);
    const height = parseFloat(hbHeight);
    const age = parseFloat(hbAge);

    if (!weight || !height || !age || weight < 30 || weight > 300 || height < 100 || height > 250 || age < 10 || age > 100) {
      Alert.alert('Erro', 'Por favor, insira valores válidos:\n• Peso: 30-300 kg\n• Altura: 100-250 cm\n• Idade: 10-100 anos');
      return;
    }

    const tmb = hbGender === 'male'
      ? 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
      : 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);

    const get = tmb * hbActivityLevel;

    setHbResult({
      tmb: Math.round(tmb * 10) / 10,
      get: Math.round(get * 10) / 10,
    });
  };

  // Mifflin-St Jeor Calculation
  const calculateMifflinStJeor = () => {
    const weight = parseFloat(mjWeight);
    const height = parseFloat(mjHeight);
    const age = parseFloat(mjAge);

    if (!weight || !height || !age || weight < 30 || weight > 300 || height < 100 || height > 250 || age < 10 || age > 100) {
      Alert.alert('Erro', 'Por favor, insira valores válidos:\n• Peso: 30-300 kg\n• Altura: 100-250 cm\n• Idade: 10-100 anos');
      return;
    }

    const tmb = mjGender === 'male'
      ? (10 * weight) + (6.25 * height) - (5 * age) + 5
      : (10 * weight) + (6.25 * height) - (5 * age) - 161;

    const get = tmb * mjActivityLevel;

    setMjResult({
      tmb: Math.round(tmb * 10) / 10,
      get: Math.round(get * 10) / 10,
    });
  };

  // Owen Calculation
  const calculateOwen = () => {
    const weight = parseFloat(owWeight);

    if (!weight || weight < 30 || weight > 300) {
      Alert.alert('Erro', 'Por favor, insira um peso válido (30-300 kg)');
      return;
    }

    const tmb = owGender === 'male'
      ? 879 + (10.2 * weight)
      : 795 + (7.18 * weight);

    const get = tmb * owActivityLevel;

    setOwResult({
      tmb: Math.round(tmb * 10) / 10,
      get: Math.round(get * 10) / 10,
    });
  };

  const handleOptionPress = (optionId: number) => {
    Alert.alert('Em Desenvolvimento', 'Esta funcionalidade será implementada em breve.');
  };

  const renderGenderSelector = (
    selectedGender: 'male' | 'female',
    onGenderChange: (gender: 'male' | 'female') => void
  ) => (
    <View style={styles.genderContainer}>
      <TouchableOpacity
        style={[
          styles.genderButton,
          selectedGender === 'male' && styles.genderButtonSelected
        ]}
        onPress={() => onGenderChange('male')}
      >
        <Text style={[
          styles.genderText,
          selectedGender === 'male' && styles.genderTextSelected
        ]}>
          Masculino
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          styles.genderButton,
          selectedGender === 'female' && styles.genderButtonSelected
        ]}
        onPress={() => onGenderChange('female')}
      >
        <Text style={[
          styles.genderText,
          selectedGender === 'female' && styles.genderTextSelected
        ]}>
          Feminino
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderActivitySelector = (
    selectedActivity: number,
    onActivityChange: (activity: number) => void
  ) => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View style={styles.activityContainer}>
        {activityLevels.map((level) => (
          <TouchableOpacity
            key={level.value}
            style={[
              styles.activityButton,
              selectedActivity === level.value && styles.activityButtonSelected
            ]}
            onPress={() => onActivityChange(level.value)}
          >
            <Text style={[
              styles.activityText,
              selectedActivity === level.value && styles.activityTextSelected
            ]}>
              {level.label}
            </Text>
            <Text style={[
              styles.activityDescription,
              selectedActivity === level.value && styles.activityDescriptionSelected
            ]}>
              {level.description}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );

  const renderResultCard = (result: TMBResult | null, title: string, color: string) => {
    if (!result) return null;

    return (
      <View style={[styles.resultCard, { borderLeftColor: color }]}>
        <Text style={styles.resultTitle}>Resultados {title}</Text>
        <View style={styles.resultRow}>
          <Text style={styles.resultLabel}>TMB (Taxa Metabólica Basal):</Text>
          <Text style={styles.resultValue}>{result.tmb} kcal/dia</Text>
        </View>
        <View style={styles.resultRow}>
          <Text style={styles.resultLabel}>GET (Gasto Energético Total):</Text>
          <Text style={[styles.resultValue, { color }]}>{result.get} kcal/dia</Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Perfil</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Profile Section */}
        <View style={styles.profileSection}>
          <View style={styles.avatar}>
            <User size={32} color="#0F0F1A" />
          </View>
          <Text style={styles.userName}>{userProfile.name}</Text>
          <Text style={styles.userStats}>
            {userProfile.weight}kg • {userProfile.height}cm • {userProfile.age} anos
          </Text>
        </View>

        {/* TMB Calculators Section */}
        <View style={styles.calculatorsSection}>
          <Text style={styles.sectionTitle}>Calculadoras de Taxa Metabólica Basal</Text>
          <Text style={styles.sectionSubtitle}>
            Escolha a equação mais adequada para seu perfil
          </Text>

          {/* Calculator Icons Grid */}
          <View style={styles.calculatorIconsGrid}>
            {/* Harris-Benedict Icon */}
            <TouchableOpacity
              style={[styles.calculatorIcon, { backgroundColor: '#F3E8FF' }]}
              onPress={() => setShowHarrisBenedictModal(true)}
            >
              <Calculator size={32} color="#8B5CF6" />
              <Text style={styles.calculatorIconTitle}>Harris-Benedict</Text>
              <Text style={styles.calculatorIconSubtitle}>População Geral</Text>
            </TouchableOpacity>

            {/* Mifflin-St Jeor Icon */}
            <TouchableOpacity
              style={[styles.calculatorIcon, { backgroundColor: '#ECFDF5' }]}
              onPress={() => setShowMifflinModal(true)}
            >
              <Calculator size={32} color="#10B981" />
              <Text style={styles.calculatorIconTitle}>Mifflin-St Jeor</Text>
              <Text style={styles.calculatorIconSubtitle}>Mais Precisa</Text>
            </TouchableOpacity>

            {/* Owen Icon */}
            <TouchableOpacity
              style={[styles.calculatorIcon, { backgroundColor: '#FEF3C7' }]}
              onPress={() => setShowOwenModal(true)}
            >
              <Calculator size={32} color="#F59E0B" />
              <Text style={styles.calculatorIconTitle}>Owen</Text>
              <Text style={styles.calculatorIconSubtitle}>Estimativa Rápida</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Other Profile Options */}
        <View style={styles.optionsSection}>
          <Text style={styles.sectionTitle}>Outras Opções</Text>
          {profileOptions.map((option) => {
            const IconComponent = option.icon;
            return (
              <TouchableOpacity 
                key={option.id} 
                style={styles.optionItem}
                onPress={() => handleOptionPress(option.id)}
              >
                <View style={styles.optionIcon}>
                  <IconComponent size={24} color="#6B7280" />
                </View>
                <View style={styles.optionInfo}>
                  <Text style={styles.optionTitle}>{option.title}</Text>
                  <Text style={styles.optionDescription}>{option.description}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>

      {/* Harris-Benedict Modal */}
      <Modal
        visible={showHarrisBenedictModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowHarrisBenedictModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View style={styles.modalTitleContainer}>
                <View style={[styles.modalIcon, { backgroundColor: '#F3E8FF' }]}>
                  <Calculator size={24} color="#8B5CF6" />
                </View>
                <View>
                  <Text style={styles.modalTitle}>Harris-Benedict (Revisada)</Text>
                  <Text style={styles.modalSubtitle}>Ideal para população geral adulta</Text>
                </View>
              </View>
              <TouchableOpacity 
                onPress={() => {
                  setShowHarrisBenedictModal(false);
                  setHbResult(null);
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.explanationCard}>
                <Text style={styles.explanationText}>
                  Esta calculadora estima sua Taxa Metabólica Basal usando a equação Harris-Benedict revisada de 1984. 
                  É amplamente utilizada em ambientes clínicos e fornece uma estimativa confiável das calorias que seu corpo 
                  precisa em repouso para manter as funções fisiológicas básicas.
                </Text>
              </View>

              <View style={styles.formulaCard}>
                <Text style={styles.formulaTitle}>Fórmulas:</Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Homens:</Text> TMB = 88,362 + (13,397 × peso) + (4,799 × altura) - (5,677 × idade)
                </Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Mulheres:</Text> TMB = 447,593 + (9,247 × peso) + (3,098 × altura) - (4,330 × idade)
                </Text>
              </View>

              <View style={styles.inputsContainer}>
                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Peso (kg)</Text>
                    <TextInput
                      style={styles.input}
                      value={hbWeight}
                      onChangeText={setHbWeight}
                      keyboardType="numeric"
                      placeholder="75"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Altura (cm)</Text>
                    <TextInput
                      style={styles.input}
                      value={hbHeight}
                      onChangeText={setHbHeight}
                      keyboardType="numeric"
                      placeholder="175"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                </View>

                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Idade (anos)</Text>
                    <TextInput
                      style={styles.input}
                      value={hbAge}
                      onChangeText={setHbAge}
                      keyboardType="numeric"
                      placeholder="30"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Sexo</Text>
                    {renderGenderSelector(hbGender, setHbGender)}
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Nível de Atividade Física</Text>
                  {renderActivitySelector(hbActivityLevel, setHbActivityLevel)}
                </View>

                <TouchableOpacity 
                  style={[styles.calculateButton, { backgroundColor: '#8B5CF6' }]}
                  onPress={calculateHarrisBenedict}
                >
                  <Calculator size={20} color="#FFFFFF" />
                  <Text style={styles.calculateButtonText}>Calcular Harris-Benedict</Text>
                </TouchableOpacity>

                {renderResultCard(hbResult, 'Harris-Benedict', '#8B5CF6')}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Mifflin-St Jeor Modal */}
      <Modal
        visible={showMifflinModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowMifflinModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View style={styles.modalTitleContainer}>
                <View style={[styles.modalIcon, { backgroundColor: '#ECFDF5' }]}>
                  <Calculator size={24} color="#10B981" />
                </View>
                <View>
                  <Text style={styles.modalTitle}>Mifflin-St Jeor</Text>
                  <Text style={styles.modalSubtitle}>Mais precisa para sobrepeso e obesidade</Text>
                </View>
              </View>
              <TouchableOpacity 
                onPress={() => {
                  setShowMifflinModal(false);
                  setMjResult(null);
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.explanationCard}>
                <Text style={styles.explanationText}>
                  Esta calculadora usa a equação Mifflin-St Jeor, considerada a mais precisa para indivíduos saudáveis. 
                  Foi desenvolvida em 1990 e é preferida por muitos nutricionistas e dietistas para planejamento de 
                  refeições e programas de controle de peso.
                </Text>
              </View>

              <View style={styles.formulaCard}>
                <Text style={styles.formulaTitle}>Fórmulas:</Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Homens:</Text> TMB = (10 × peso) + (6,25 × altura) - (5 × idade) + 5
                </Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Mulheres:</Text> TMB = (10 × peso) + (6,25 × altura) - (5 × idade) - 161
                </Text>
              </View>

              <View style={styles.inputsContainer}>
                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Peso (kg)</Text>
                    <TextInput
                      style={styles.input}
                      value={mjWeight}
                      onChangeText={setMjWeight}
                      keyboardType="numeric"
                      placeholder="75"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Altura (cm)</Text>
                    <TextInput
                      style={styles.input}
                      value={mjHeight}
                      onChangeText={setMjHeight}
                      keyboardType="numeric"
                      placeholder="175"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                </View>

                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Idade (anos)</Text>
                    <TextInput
                      style={styles.input}
                      value={mjAge}
                      onChangeText={setMjAge}
                      keyboardType="numeric"
                      placeholder="30"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Sexo</Text>
                    {renderGenderSelector(mjGender, setMjGender)}
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Nível de Atividade Física</Text>
                  {renderActivitySelector(mjActivityLevel, setMjActivityLevel)}
                </View>

                <TouchableOpacity 
                  style={[styles.calculateButton, { backgroundColor: '#10B981' }]}
                  onPress={calculateMifflinStJeor}
                >
                  <Calculator size={20} color="#FFFFFF" />
                  <Text style={styles.calculateButtonText}>Calcular Mifflin-St Jeor</Text>
                </TouchableOpacity>

                {renderResultCard(mjResult, 'Mifflin-St Jeor', '#10B981')}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Owen Modal */}
      <Modal
        visible={showOwenModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowOwenModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View style={styles.modalTitleContainer}>
                <View style={[styles.modalIcon, { backgroundColor: '#FEF3C7' }]}>
                  <Calculator size={24} color="#F59E0B" />
                </View>
                <View>
                  <Text style={styles.modalTitle}>Owen</Text>
                  <Text style={styles.modalSubtitle}>Estimativas rápidas e práticas</Text>
                </View>
              </View>
              <TouchableOpacity 
                onPress={() => {
                  setShowOwenModal(false);
                  setOwResult(null);
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.explanationCard}>
                <Text style={styles.explanationText}>
                  Esta calculadora aplica a equação Owen, que é particularmente útil para populações clínicas e 
                  indivíduos com obesidade. Fornece fórmulas diferentes para homens e mulheres e é frequentemente 
                  usada em ambientes médicos para avaliação nutricional.
                </Text>
              </View>

              <View style={styles.formulaCard}>
                <Text style={styles.formulaTitle}>Fórmulas:</Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Homens:</Text> TMB = 879 + (10,2 × peso)
                </Text>
                <Text style={styles.formulaText}>
                  <Text style={styles.formulaBold}>Mulheres:</Text> TMB = 795 + (7,18 × peso)
                </Text>
              </View>

              <View style={styles.inputsContainer}>
                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Peso (kg)</Text>
                    <TextInput
                      style={styles.input}
                      value={owWeight}
                      onChangeText={setOwWeight}
                      keyboardType="numeric"
                      placeholder="75"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Altura (cm)</Text>
                    <TextInput
                      style={styles.input}
                      value={owHeight}
                      onChangeText={setOwHeight}
                      keyboardType="numeric"
                      placeholder="175"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                </View>

                <View style={styles.inputRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Idade (anos)</Text>
                    <TextInput
                      style={styles.input}
                      value={owAge}
                      onChangeText={setOwAge}
                      keyboardType="numeric"
                      placeholder="30"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Sexo</Text>
                    {renderGenderSelector(owGender, setOwGender)}
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Nível de Atividade Física</Text>
                  {renderActivitySelector(owActivityLevel, setOwActivityLevel)}
                </View>

                <TouchableOpacity 
                  style={[styles.calculateButton, { backgroundColor: '#F59E0B' }]}
                  onPress={calculateOwen}
                >
                  <Calculator size={20} color="#FFFFFF" />
                  <Text style={styles.calculateButtonText}>Calcular Owen</Text>
                </TouchableOpacity>

                {renderResultCard(owResult, 'Owen', '#F59E0B')}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#000',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
    backgroundColor: '#FFFFFF',
    marginBottom: 20,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#F0FDF4',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  userStats: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 4,
  },
  calculatorsSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 20,
    lineHeight: 20,
  },
  calculatorIconsGrid: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'space-between',
  },
  calculatorIcon: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  calculatorIconTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#000',
    marginTop: 8,
    textAlign: 'center',
  },
  calculatorIconSubtitle: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    textAlign: 'center',
  },
  optionsSection: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#F3F4F6',
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#F9FAFB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  optionInfo: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  optionDescription: {
    fontSize: 14,
    color: '#6B7280',
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#FEF3C7',
    borderRadius: 12,
    padding: 16,
    gap: 12,
    borderWidth: 1,
    borderColor: '#FDE68A',
    marginHorizontal: 20,
    marginBottom: 20,
  },
  disclaimerText: {
    flex: 1,
    fontSize: 14,
    color: '#92400E',
    lineHeight: 20,
  },
  bottomPadding: {
    height: 40,
  },
  
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
    minHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  modalTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  modalIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginBottom: 4,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#6B7280',
  },
  closeButton: {
    padding: 4,
  },
  explanationCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    margin: 24,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#E5E7EB',
  },
  explanationText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  formulaCard: {
    backgroundColor: '#F0F9FF',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 24,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#E0F2FE',
  },
  formulaTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
    marginBottom: 12,
  },
  formulaText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
    marginBottom: 8,
    fontFamily: 'monospace',
  },
  formulaBold: {
    fontWeight: '700',
    color: '#000',
  },
  inputsContainer: {
    paddingHorizontal: 24,
    gap: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',
    backgroundColor: '#F9FAFB',
  },
  genderContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  genderButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  genderButtonSelected: {
    backgroundColor: '#0F0F1A',
    borderColor: '#0F0F1A',
  },
  genderText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
  genderTextSelected: {
    color: '#FFFFFF',
  },
  activityContainer: {
    flexDirection: 'row',
    gap: 12,
    paddingRight: 20,
  },
  activityButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minWidth: 140,
  },
  activityButtonSelected: {
    backgroundColor: '#0F0F1A',
    borderColor: '#0F0F1A',
  },
  activityText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
    marginBottom: 2,
  },
  activityTextSelected: {
    color: '#FFFFFF',
  },
  activityDescription: {
    fontSize: 11,
    color: '#9CA3AF',
    lineHeight: 14,
  },
  activityDescriptionSelected: {
    color: '#D1D5DB',
  },
  calculateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    paddingVertical: 16,
    gap: 8,
    marginTop: 8,
    marginBottom: 20,
  },
  calculateButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  resultCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    borderLeftWidth: 4,
    marginBottom: 20,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
    marginBottom: 12,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  resultLabel: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  resultValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
  },
  calculatorDisclaimer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#FEF3C7',
    borderRadius: 12,
    padding: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: '#FDE68A',
    marginTop: 16,
    marginBottom: 20,
  },
  calculatorDisclaimerText: {
    flex: 1,
    fontSize: 12,
    color: '#92400E',
    lineHeight: 16,
  },
});