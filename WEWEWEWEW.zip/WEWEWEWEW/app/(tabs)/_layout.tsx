import { Tabs } from 'expo-router';
import React from 'react';
import { Platform } from 'react-native';
import { Scale, Calendar, Utensils, User, Home } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#F59E0B',
        tabBarInactiveTintColor: '#9CA3AF',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#F3F4F6',
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Home size={size || 24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="diaria"
        options={{
          title: 'Diária',
          tabBarIcon: ({ color, size }) => <Calendar size={size || 24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="weight"
        options={{
          title: 'Peso',
          tabBarIcon: ({ color, size }) => <Scale size={size || 24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="diets"
        options={{
          title: 'Dietas',
          tabBarIcon: ({ color, size }) => <Utensils size={size || 24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Perfil',
          tabBarIcon: ({ color, size }) => <User size={size || 24} color={color} />,
        }}
      />
    </Tabs>
  );
}