import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  Image,
} from 'react-native';
import { 
  X,
  Calculator,
} from 'lucide-react-native';

interface DietProtocol {
  id: string;
  name: string;
  duration: string;
  color: string;
  description: string;
}

const dietProtocols: DietProtocol[] = [
  {
    id: 'protocol-7',
    name: 'Protocolo 7 Dias',
    duration: '7 dias',
    color: '#B3A1FF',
    description: 'Protocolo intensivo de curta duração para quebra de platô',
  },
  {
    id: 'protocol-30',
    name: 'Protocolo 30 Dias',
    duration: '30 dias',
    color: '#FEC775',
    description: 'Protocolo estruturado para perda de peso sustentável',
  },
  {
    id: 'protocol-60',
    name: 'Protocolo 60 Dias',
    duration: '60 dias',
    color: '#B8ECF4',
    description: 'Protocolo com ciclagem de carboidratos e refeeds estratégicos',
  },
  {
    id: 'protocol-120',
    name: 'Protocolo 120 Dias',
    duration: '120 dias',
    color: '#B2EAB8',
    description: 'Protocolo completo para transformação corporal em fases',
  },
  {
    id: 'lowcarb-brasil',
    name: 'Low Carb Brasileiro',
    duration: 'Contínuo',
    color: '#A855F7',
    description: 'Low carb adaptado aos alimentos e cultura brasileira',
  },
  {
    id: 'jejum-16-8',
    name: 'Jejum Intermitente 16:8',
    duration: 'Contínuo',
    color: '#F87171',
    description: 'Jejum intermitente adaptado ao horário brasileiro',
  }
];

export default function DietsScreen() {
  const [selectedProtocol, setSelectedProtocol] = useState<DietProtocol | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);
  
  // Dados do usuário
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [activityLevel, setActivityLevel] = useState('1.55');
  const [targetWeight, setTargetWeight] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const [bodyFat, setBodyFat] = useState(''); // Para Cunningham

  const activityLevels = [
    { value: '1.2', label: 'Sedentário' },
    { value: '1.375', label: 'Leve' },
    { value: '1.55', label: 'Moderado' },
    { value: '1.725', label: 'Alto' },
    { value: '1.9', label: 'Extremo' }
  ];

  const openProtocolCalculator = (protocol: DietProtocol) => {
    setSelectedProtocol(protocol);
    setShowCalculator(true);
  };

  const calculateProtocol = () => {
    if (!selectedProtocol) return;

    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);
    const tw = parseFloat(targetWeight);
    const tf = parseFloat(timeframe);
    const al = parseFloat(activityLevel);
    const bf = parseFloat(bodyFat);

    if (!w || !h || !a || !tw || !tf) {
      Alert.alert('Erro', 'Preencha todos os campos obrigatórios');
      return;
    }

    // TMB Mifflin-St Jeor (padrão clínico)
    const tmb = gender === 'male' 
      ? (10 * w) + (6.25 * h) - (5 * a) + 5
      : (10 * w) + (6.25 * h) - (5 * a) - 161;

    const get = tmb * al;
    const weightDiff = w - tw;
    const weeklyLoss = Math.abs(weightDiff) / tf;
    
    // Déficit seguro baseado no IMC
    const imc = w / Math.pow(h / 100, 2);
    let maxDeficit = 500; // Padrão
    if (imc >= 30) maxDeficit = 1000;
    else if (imc >= 25) maxDeficit = 750;
    
    const dailyDeficit = Math.min((weeklyLoss * 7700) / 7, maxDeficit);
    const targetCalories = Math.max(get - dailyDeficit, tmb * 1.2); // Nunca abaixo de 1.2x TMB

    let macros = { carbs: 0, protein: 0, fat: 0 };
    let protocolDetails = '';

    // Cálculos específicos por protocolo
    switch (selectedProtocol.id) {
      case 'protocol-7':
        // Protocolo 7 dias - Intensivo
        macros = {
          carbs: Math.round((targetCalories * 0.25) / 4),
          protein: Math.round((targetCalories * 0.45) / 4),
          fat: Math.round((targetCalories * 0.30) / 9)
        };
        protocolDetails = `PROTOCOLO INTENSIVO 7 DIAS
        
🎯 CARACTERÍSTICAS:
• Déficit agressivo controlado
• Alta proteína para preservar massa magra
• Carboidratos reduzidos estrategicamente
• Duração limitada para segurança

⚠️ IMPORTANTE:
• Máximo 7 dias consecutivos
• Intervalo mínimo 2 semanas entre ciclos
• Hidratação reforçada (3L+ água/dia)
• Monitoramento diário recomendado`;
        break;

      case 'protocol-30':
        // Protocolo 30 dias - Sustentável
        macros = {
          carbs: Math.round((targetCalories * 0.35) / 4),
          protein: Math.round((targetCalories * 0.35) / 4),
          fat: Math.round((targetCalories * 0.30) / 9)
        };
        protocolDetails = `PROTOCOLO 30 DIAS SUSTENTÁVEL
        
🎯 CARACTERÍSTICAS:
• Déficit moderado e sustentável
• Distribuição equilibrada de macros
• Educação alimentar progressiva
• Resultados consistentes

📅 ESTRUTURA:
• Semana 1-2: Adaptação
• Semana 3-4: Consolidação
• Avaliação semanal obrigatória`;
        break;

      case 'protocol-60':
        // Protocolo 60 dias - Ciclagem
        const highCarbDays = Math.round((get * 0.45) / 4);
        const lowCarbDays = Math.round((targetCalories * 0.25) / 4);
        macros = {
          carbs: Math.round((highCarbDays + lowCarbDays) / 2),
          protein: Math.round(w * 1.8), // 1.8g/kg
          fat: Math.round((targetCalories - (macros.carbs * 4) - (w * 1.8 * 4)) / 9)
        };
        protocolDetails = `PROTOCOLO 60 DIAS COM CICLAGEM
        
🎯 CICLAGEM DE CARBOIDRATOS:
• Dias TREINO: ${highCarbDays}g CHO (alto)
• Dias OFF: ${lowCarbDays}g CHO (baixo)
• REFEED: 1x/semana (+500 kcal)

📅 CRONOGRAMA SEMANAL:
• 3-4 dias baixo CHO
• 2-3 dias alto CHO  
• 1 dia refeed (sábado/domingo)

⚡ BENEFÍCIOS:
• Preserva metabolismo
• Flexibilidade psicológica
• Performance mantida`;
        break;

      case 'protocol-120':
        // Protocolo 120 dias - Fases
        macros = {
          carbs: Math.round((targetCalories * 0.40) / 4),
          protein: Math.round(w * 1.6),
          fat: Math.round((targetCalories - (macros.carbs * 4) - (w * 1.6 * 4)) / 9)
        };
        protocolDetails = `PROTOCOLO 120 DIAS EM FASES
        
📅 ESTRUTURA EM FASES:
• FASE 1 (30 dias): Déficit ${Math.round(dailyDeficit)} kcal
• FASE 2 (15 dias): Manutenção ${Math.round(get)} kcal
• FASE 3 (30 dias): Déficit ${Math.round(dailyDeficit)} kcal
• FASE 4 (15 dias): Manutenção ${Math.round(get)} kcal
• FASE 5 (30 dias): Déficit final

🎯 OBJETIVOS POR FASE:
• Perda gradual e sustentável
• Reset metabólico periódico
• Educação alimentar completa
• Manutenção longo prazo`;
        break;

      case 'lowcarb-brasil':
        // Low Carb Brasileiro
        const maxCarbs = Math.min(100, w * 1.0);
        const proteinGrams = w * 1.6;
        const remainingCalories = targetCalories - (maxCarbs * 4) - (proteinGrams * 4);
        macros = {
          carbs: Math.round(maxCarbs),
          protein: Math.round(proteinGrams),
          fat: Math.round(Math.max(remainingCalories / 9, w * 0.8)) // Mín 0.8g/kg
        };
        protocolDetails = `LOW CARB BRASILEIRO
        
🥑 CARACTERÍSTICAS:
• Carboidratos: Máx ${maxCarbs}g/dia
• Proteína: ${proteinGrams}g (1.6g/kg)
• Gordura: ${macros.fat}g (restante)

🇧🇷 ALIMENTOS PERMITIDOS:
• Carnes, ovos, peixes
• Queijos e laticínios integrais
• Abacate, coco, castanhas
• Verduras e legumes baixo CHO
• Azeite, óleo de coco

⚠️ EVITAR:
• Arroz, feijão, pão, massas
• Frutas doces (banana, manga)
• Açúcar e doces em geral`;
        break;

      case 'jejum-16-8':
        // Jejum Intermitente 16:8
        macros = {
          carbs: Math.round((targetCalories * 0.40) / 4),
          protein: Math.round((targetCalories * 0.30) / 4),
          fat: Math.round((targetCalories * 0.30) / 9)
        };
        protocolDetails = `JEJUM INTERMITENTE 16:8
        
⏰ HORÁRIO BRASILEIRO:
• JEJUM: 20h - 12h (16 horas)
• JANELA: 12h - 20h (8 horas)

🍽️ DISTRIBUIÇÃO REFEIÇÕES:
• 12h: Almoço (40% calorias)
• 16h: Lanche (20% calorias)  
• 19h: Jantar (40% calorias)

💧 DURANTE O JEJUM:
• Água à vontade
• Café sem açúcar
• Chá sem açúcar
• Água com limão

✅ BENEFÍCIOS:
• Praticidade no dia a dia
• Melhora sensibilidade insulina
• Flexibilidade social`;
        break;

      default:
        return;
    }

    // Calcular percentuais reais
    const carbsPercent = Math.round((macros.carbs * 4 / targetCalories) * 100);
    const proteinPercent = Math.round((macros.protein * 4 / targetCalories) * 100);
    const fatPercent = Math.round((macros.fat * 9 / targetCalories) * 100);

    // Mostrar resultados completos
    Alert.alert(
      `${selectedProtocol.name} - Calculado`,
      `${protocolDetails}\n\n` +
      `📊 VALORES CALCULADOS:\n\n` +
      `🔥 CALORIAS: ${Math.round(targetCalories)} kcal/dia\n\n` +
      `🍞 CARBOIDRATOS: ${macros.carbs}g (${carbsPercent}%)\n` +
      `🥩 PROTEÍNAS: ${macros.protein}g (${proteinPercent}%)\n` +
      `🥑 GORDURAS: ${macros.fat}g (${fatPercent}%)\n\n` +
      `⚡ TMB: ${Math.round(tmb)} kcal\n` +
      `🔥 GET: ${Math.round(get)} kcal\n` +
      `📉 DÉFICIT: ${Math.round(dailyDeficit)} kcal/dia\n` +
      `⏱️ PERDA SEMANAL: ${weeklyLoss.toFixed(1)}kg`,
      [{ text: 'OK' }]
    );
  };

  const resetForm = () => {
    setWeight('');
    setHeight('');
    setAge('');
    setGender('male');
    setActivityLevel('1.55');
    setTargetWeight('');
    setTimeframe('');
    setBodyFat('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Protocolos de Dieta</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Protocol Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Protocolos Populares</Text>
          
          <View style={styles.protocolGrid}>
            {dietProtocols.map((protocol) => {
              // Define image URLs for each protocol
              const getProtocolImage = (protocolId: string) => {
                switch (protocolId) {
                  case 'protocol-7':
                    return 'https://i.postimg.cc/3RB5Gfz1/vista-lateral-homem-sorridente-no-ginasio.png';
                  case 'protocol-30':
                    return 'https://i.postimg.cc/kXDQk6MX/mulher-forte-posando-em-trajes-de-fitness.png';
                  case 'protocol-60':
                    return 'https://i.postimg.cc/DwLXT19F/treinamento-esportivo-bonito-da-mulher.png';
                  case 'protocol-120':
                    return 'https://i.postimg.cc/7PRGJBDw/bela-jovem-incrivel-esportes-fortes-fitness-mulher-posando-isolado-sobre-o-fundo-da-parede-branca.png';
                  case 'lowcarb-brasil':
                    return 'https://i.postimg.cc/jjvCxcZV/homem-levantando-pesos.png';
                  case 'jejum-16-8':
                    return 'https://i.postimg.cc/cHr3PPZk/retrato-de-uma-jovem-desportista-sorridente.png';
                  default:
                    return null;
                }
              };
              
              const protocolImage = getProtocolImage(protocol.id);
              
              return (
                <TouchableOpacity
                  key={protocol.id}
                  style={[
                    styles.protocolCard, 
                    { backgroundColor: protocol.color }
                  ]}
                  onPress={() => openProtocolCalculator(protocol)}
                >
                  <View style={styles.cardContent}>
                    <Text style={styles.protocolName}>{protocol.name}</Text>
                    <Text style={styles.protocolDuration}>{protocol.duration}</Text>
                    
                    <TouchableOpacity style={styles.startButton}>
                      <Text style={styles.startButtonText}>Começar Agora</Text>
                    </TouchableOpacity>
                  </View>
                  
                  {protocolImage && (
                    <View style={styles.fitnessImageContainer}>
                      <Image
                        source={{ uri: protocolImage }}
                        style={styles.fitnessImage}
                        resizeMode="cover"
                      />
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>

      {/* Protocol Calculator Modal */}
      <Modal
        visible={showCalculator}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowCalculator(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.calculatorModal}>
            {/* Modal Header */}
            <View style={styles.modalHeader}>
              <View style={styles.modalTitleContainer}>
                <Text style={styles.modalTitle}>
                  {selectedProtocol?.name}
                </Text>
                <Text style={styles.modalSubtitle}>
                  Calculadora Personalizada
                </Text>
              </View>
              <TouchableOpacity 
                onPress={() => {
                  setShowCalculator(false);
                  resetForm();
                }}
                style={styles.closeButton}
              >
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalScrollView} showsVerticalScrollIndicator={false}>
              {/* Protocol Info */}
              {selectedProtocol && (
                <View style={styles.protocolInfo}>
                  <Text style={styles.protocolInfoDescription}>
                    {selectedProtocol.description}
                  </Text>
                </View>
              )}

              {/* Calculator Form */}
              <View style={styles.calculatorForm}>
                <Text style={styles.formTitle}>Dados Pessoais</Text>
                
                {/* Basic Data Row 1 */}
                <View style={styles.formRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Peso Atual (kg)</Text>
                    <TextInput
                      style={styles.input}
                      value={weight}
                      onChangeText={setWeight}
                      keyboardType="numeric"
                      placeholder="70"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Altura (cm)</Text>
                    <TextInput
                      style={styles.input}
                      value={height}
                      onChangeText={setHeight}
                      keyboardType="numeric"
                      placeholder="170"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                </View>

                {/* Basic Data Row 2 */}
                <View style={styles.formRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Idade</Text>
                    <TextInput
                      style={styles.input}
                      value={age}
                      onChangeText={setAge}
                      keyboardType="numeric"
                      placeholder="30"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Sexo</Text>
                    <View style={styles.genderContainer}>
                      <TouchableOpacity
                        style={[
                          styles.genderButton,
                          gender === 'male' && styles.genderButtonSelected
                        ]}
                        onPress={() => setGender('male')}
                      >
                        <Text style={[
                          styles.genderText,
                          gender === 'male' && styles.genderTextSelected
                        ]}>
                          M
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[
                          styles.genderButton,
                          gender === 'female' && styles.genderButtonSelected
                        ]}
                        onPress={() => setGender('female')}
                      >
                        <Text style={[
                          styles.genderText,
                          gender === 'female' && styles.genderTextSelected
                        ]}>
                          F
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>

                {/* Activity Level */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Nível de Atividade</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    <View style={styles.activityContainer}>
                      {activityLevels.map((level) => (
                        <TouchableOpacity
                          key={level.value}
                          style={[
                            styles.activityButton,
                            activityLevel === level.value && styles.activityButtonSelected
                          ]}
                          onPress={() => setActivityLevel(level.value)}
                        >
                          <Text style={[
                            styles.activityText,
                            activityLevel === level.value && styles.activityTextSelected
                          ]}>
                            {level.label}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </ScrollView>
                </View>

                {/* Goals */}
                <Text style={styles.formTitle}>Objetivos</Text>
                <View style={styles.formRow}>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Peso Meta (kg)</Text>
                    <TextInput
                      style={styles.input}
                      value={targetWeight}
                      onChangeText={setTargetWeight}
                      keyboardType="numeric"
                      placeholder="65"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Prazo (semanas)</Text>
                    <TextInput
                      style={styles.input}
                      value={timeframe}
                      onChangeText={setTimeframe}
                      keyboardType="numeric"
                      placeholder="12"
                      placeholderTextColor="#9CA3AF"
                    />
                  </View>
                </View>

                {/* Calculate Button */}
                <TouchableOpacity 
                  style={styles.calculateButton}
                  onPress={calculateProtocol}
                >
                  <Calculator size={20} color="#FFFFFF" />
                  <Text style={styles.calculateButtonText}>
                    Calcular {selectedProtocol?.name}
                  </Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#000',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 20,
    lineHeight: 20,
  },
  protocolGrid: {
    gap: 16,
  },
  protocolCard: {
    borderRadius: 16,
    padding: 24,
    height: 180,
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
    position: 'relative',
    overflow: 'hidden',
  },
  cardContent: {
    flex: 1,
    justifyContent: 'space-between',
    zIndex: 2,
  },
  protocolDuration: {
    fontSize: 14,
    fontWeight: '500',
    color: '#000',
    opacity: 0.8,
    marginTop: 4,
  },
  protocolName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  startButton: {
    backgroundColor: '#000',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  startButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  fitnessImageContainer: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: '45%',
    opacity: 1.0,
  },
  fitnessImage: {
    width: '100%',
    height: '100%',
  },
  bottomPadding: {
    height: 40,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  calculatorModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
    minHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginBottom: 4,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#6B7280',
  },
  closeButton: {
    padding: 4,
  },
  modalScrollView: {
    flex: 1,
  },
  protocolInfo: {
    paddingHorizontal: 24,
    paddingVertical: 20,
    backgroundColor: '#F7F5FF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  protocolInfoDescription: {
    fontSize: 16,
    color: '#374151',
    lineHeight: 24,
    marginBottom: 16,
  },
  benefitsList: {
    gap: 8,
  },
  benefitItem: {
    fontSize: 14,
    color: '#059669',
    lineHeight: 20,
  },
  calculatorForm: {
    paddingHorizontal: 24,
    paddingVertical: 20,
  },
  formTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
    marginBottom: 16,
  },
  formRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',
    backgroundColor: '#F9FAFB',
  },
  genderContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  genderButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  genderButtonSelected: {
    backgroundColor: '#0F0F1A',
    borderColor: '#0F0F1A',
  },
  genderText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B7280',
  },
  genderTextSelected: {
    color: '#FFFFFF',
  },
  activityContainer: {
    flexDirection: 'row',
    gap: 8,
    paddingRight: 20,
  },
  activityButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activityButtonSelected: {
    backgroundColor: '#0F0F1A',
    borderColor: '#0F0F1A',
  },
  activityText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  activityTextSelected: {
    color: '#FFFFFF',
  },
  calculateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0F0F1A',
    borderRadius: 12,
    paddingVertical: 16,
    gap: 8,
    marginTop: 24,
    marginBottom: 20,
  },
  calculateButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});